# Публикация на GitHub

Эта папка подготовлена как самостоятельный корень репозитория. Не копируйте в неё содержимое рабочей установки, data/, .runtime/, signing/, .venv/, архивы, EXE, журналы и реальные проекты. В папке нет истории Git исходной установки.

1. Выберите лицензию, добавьте соответствующий LICENSE и исправьте раздел лицензии README.
2. Выполните проверки из README; при изменении зависимостей повторите проверку запуска.
3. Просмотрите .gitignore и git diff --cached. Не добавляйте runtime-файлы с -f.
4. Создайте свой репозиторий GitHub и отправьте только содержимое этой папки.

Пример локальной подготовки (публикация выполняется владельцем):
```powershell
git init -b main
git add .
git diff --cached --stat
git commit -m "Initial clean source release"
git remote add origin https://github.com/YOUR_ACCOUNT/YOUR_REPOSITORY.git
git push -u origin main
```

Ни git init, ни создание репозитория, ни push при подготовке папки не выполнялись. Архив исходников находится рядом с папкой; результаты проверки и контрольные суммы входят в RELEASE-CHECKS.txt и SHA256SUMS.txt.
