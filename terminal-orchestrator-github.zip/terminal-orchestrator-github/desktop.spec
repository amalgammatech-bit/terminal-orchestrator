a = Analysis(['desktop.py'], pathex=[], binaries=[], datas=[('web', 'web'),('orchestrator/services/agent_entry.py','.')], hiddenimports=['sqlite3','tkinter','tkinter.filedialog'], hookspath=[], hooksconfig={}, runtime_hooks=[], excludes=['textual','numpy','PIL','PyQt5','PySide6'], noarchive=False, optimize=0)
pyz = PYZ(a.pure)
exe = EXE(pyz, a.scripts, [], exclude_binaries=True, name='orchestrator', debug=False, bootloader_ignore_signals=False, strip=False, upx=False, console=False)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False, name='orchestrator')

# A direct EXE launch must find the same configuration as START.cmd.
from pathlib import Path
import shutil
shutil.copy2(Path(SPECPATH) / 'config.toml', Path(DISTPATH) / 'orchestrator' / 'config.toml')
