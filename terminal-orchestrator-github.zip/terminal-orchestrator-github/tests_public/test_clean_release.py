"""Offline acceptance check: empty startup, API auth and adding first profile."""
import json
import os
from pathlib import Path
import sys
import tempfile
import threading
import unittest
from unittest.mock import patch
from urllib.request import Request, urlopen
from urllib.error import HTTPError

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
TEMP=tempfile.TemporaryDirectory(dir=ROOT/'tests_public',prefix='check-')
CONFIG=Path(TEMP.name)/'config.toml'
CONFIG.write_text((ROOT/'config.example.toml').read_text(encoding='utf-8'),encoding='utf-8')
(Path(TEMP.name)/'projects').mkdir()
os.environ['ORCHESTRATOR_CONFIG']=str(CONFIG)
from orchestrator.config import SETTINGS
from orchestrator.services import desktop, model_registry, access
from orchestrator.models.session import init_db

class CleanReleaseTests(unittest.TestCase):
    def test_empty_startup_and_first_connection(self):
        self.assertEqual(SETTINGS.models(),[])
        self.assertEqual(SETTINGS.section('llm')['providers'],[])
        self.assertEqual(access.state()['mode'],'none')
        init_db()
        with patch.object(desktop,'ResourceMonitor'),patch.object(desktop.executors,'catalog',return_value=[]):
            service=desktop.DesktopService()
        try:
            boot=service.bootstrap()
            self.assertEqual(boot['models'],[])
            self.assertEqual(boot['agents'],[])
            self.assertEqual(boot['warnings'],[])
            with self.assertRaises(desktop.ApiError):service.start(1,'test',0)
            server=desktop.make_server(service,ROOT/'web',0)
            thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
            try:
                url='http://127.0.0.1:'+str(server.server_port)+'/api/bootstrap'
                with self.assertRaises(HTTPError) as rejected:urlopen(url)
                self.assertIn(rejected.exception.code,(401,403))
                with urlopen(Request(url,headers={'Authorization':'Bearer '+server.token})) as response:
                    self.assertEqual(json.load(response)['models'],[])
                endpoint='http://127.0.0.1:'+str(server.server_port)+'/api/custom-agents'
                headers={'Authorization':'Bearer '+server.token,'Content-Type':'application/json'}
                for operation in ('delete','restore'):
                    with urlopen(Request(endpoint+'/'+operation,data=json.dumps({'id':'kimi'}).encode(),headers=headers)) as response:json.load(response)
                    with urlopen(Request(endpoint,headers=headers)) as response:
                        entry=next(r for r in json.load(response)['catalog'] if r['id']=='kimi')
                        self.assertEqual(entry['removed'],operation=='delete')
                payload=dict(label='Example CLI',command=sys.executable,args=[],stdin=True)
                with urlopen(Request(endpoint+'/save',data=json.dumps(payload).encode(),headers=headers)) as response:
                    saved=json.load(response)['agents'][0]
                self.assertIn(saved['id'],desktop.executors.SPECS)
                with urlopen(Request(endpoint,headers=headers)) as response:self.assertEqual(json.load(response)['agents'][0]['label'],'Example CLI')
                with urlopen(Request(endpoint+'/delete',data=json.dumps({'id':saved['id']}).encode(),headers=headers)) as response:self.assertEqual(json.load(response)['agents'],[])
            finally:server.shutdown();server.server_close();thread.join(3)
            model_registry.save_profile(dict(label='My local API',url='http://127.0.0.1:11434/v1',model='example-model',context=8192,input_budget=4096,max_output_tokens=1024,api_key='',enabled=True,brain_only=False))
            service._reload_connections()
            self.assertEqual(len(service.bootstrap()['models']),1)
        finally:service.close()

if __name__=='__main__':unittest.main()
