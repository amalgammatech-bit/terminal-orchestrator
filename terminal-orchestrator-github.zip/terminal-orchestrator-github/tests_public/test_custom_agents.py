import unittest,tempfile,threading,sys,json
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from orchestrator.services import custom_agents,executors,access
from orchestrator.services.executor import ExecutionResult
class CustomTests(unittest.TestCase):
 def test_registry_launch_and_delete(self):
  with tempfile.TemporaryDirectory() as d,patch.object(custom_agents,'path',return_value=Path(d)/'agents.json'):
   row=custom_agents.save(dict(label='Example',command=sys.executable,args=['--model','{model}','--prompt','{task}','{project}'],stdin=False,instructions='Check output'))
   executors.refresh_custom()
   try:
    self.assertIn(row['id'],executors.SPECS)
    self.assertTrue(next(r for r in executors.catalog() if r['id']==row['id'])['available'])
    self.assertFalse(next(r for r in executors.catalog() if r['id']==row['id'])['can_update'])
    with patch('orchestrator.services.executor.resolve_project',return_value=Path(d)),patch('orchestrator.services.executor._run',return_value=ExecutionResult(returncode=0)) as run:
     r=executors.run_agent('Task {model} & x',d,threading.Event(),kind=row['id'],native_model='test-model')
     self.assertTrue(r.ok)
     cmd=run.call_args.args[0]
     self.assertEqual(cmd[2],'test-model');self.assertEqual(cmd[4],'Check output\n\nTask {model} & x')
     self.assertEqual(cmd[5],d);self.assertIsNone(run.call_args.kwargs['input_text'])
    custom_agents.delete(row['id']);self.assertEqual(custom_agents.rows(),[])
   finally:executors.refresh_custom()
 def test_invalid_config(self):
  for change in [dict(args='--task'),dict(stdin=False,args=[]),dict(command='bad\ncommand'),dict(id='opencode')]:
   with self.assertRaises(ValueError):custom_agents.validate(dict(label='Test',command='test',**{k:v for k,v in change.items() if k!='command'}) if 'command' not in change else dict(label='Test',**change))
 def test_no_access_blocks_custom_program(self):
  row=custom_agents.validate(dict(label='Test',command=sys.executable,args=['-c','raise Exception()']))
  with patch.object(access,'state',return_value={'mode':'none','folder':''}),patch('orchestrator.services.executor._save_result',side_effect=lambda r:r):
   result=custom_agents.run(row,'task','',threading.Event(),'',30)
  self.assertFalse(result.ok)

 def test_builtin_remove_restore_persists_and_blocks_execution(self):
  with tempfile.TemporaryDirectory() as d,patch.object(custom_agents,'hidden_path',return_value=Path(d)/'catalog.json'):
   custom_agents.set_builtin('opencode',True)
   self.assertIn('opencode',custom_agents.hidden())
   self.assertIsNone(executors.executable('opencode'))
   self.assertNotIn('opencode',[r['id'] for r in executors.catalog()])
   self.assertTrue(next(r for r in custom_agents.listing() if r['id']=='opencode')['removed'])
   custom_agents.set_builtin('opencode',False)
   self.assertNotIn('opencode',custom_agents.hidden())
   self.assertIn('opencode',[r['id'] for r in executors.catalog()])
   with self.assertRaises(ValueError):custom_agents.set_builtin('none',True)
