import asyncio,json,tempfile,threading,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch,Mock
from orchestrator.services import routing
from orchestrator.services.executor import ExecutionResult
class RecoveryTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
  helper=dict(id='helper',kind='kimi',model='',device='gpu',enabled=True,fallback=False,category='simple',categories=['simple'],priority=1,timeout=60,label='Helper')
  brain=dict(id='brain-self',kind='harness',model='brain-model',device='api',enabled=True,fallback=False,category='general',priority=50,timeout=60,label='Brain')
  self.task=SimpleNamespace(project=str(self.root),cancelled=threading.Event(),routing_config={'mode':'auto','manager':'brain','allow_cloud':True,'profiles':[helper,brain],'recover_with_brain':True,'max_brain_recoveries':2},brain_self_agent={'model':'brain-model','actual_model':'test','provider':'api'},brain_self_connection={'provider':'api'},brain_self_kind='harness',brain_self_timeout=60)
  self.calls=[];self.service=SimpleNamespace(agent_models=[],emit=Mock(),progress=Mock())
  self.guards=[patch.object(routing.executors,'executable',return_value='test'),patch('orchestrator.services.routing.resolve_project',side_effect=lambda p:Path(p)),patch('orchestrator.services.access.check_read',side_effect=lambda p:p),patch('orchestrator.services.executor._save_result',side_effect=lambda r:r)]
  for g in self.guards:g.start()
 def tearDown(self):
  for g in reversed(self.guards):g.stop()
  self.tmp.cleanup()
 def command(self,name='out.json'):
  return ('delegate',json.dumps({'task':'create '+name,'profile':'helper','category':'simple','expected_artifacts':[{'path':name,'format':'json','required_keys':['done'],'equals':{'done':True}}]}),str(self.root))
 def run_case(self,repair=True,name='out.json'):
  async def execute(cmd,task):
   self.calls.append(task.executor_kind)
   if task.executor_kind=='harness' and repair:(self.root/name).write_text('{"done":true}')
   return ExecutionResult(returncode=0)
  self.service._execute_manual=execute
  return asyncio.run(routing.execute(self.service,self.command(name),self.task))
 def test_missing_file_recovers_even_process_zero(self):
  result=self.run_case();self.assertTrue(result.ok);self.assertEqual(self.calls,['kimi','harness']);self.assertEqual(self.task.brain_recoveries,1)
 def test_repair_failure_does_not_recurse(self):
  result=self.run_case(False);self.assertFalse(result.ok);self.assertEqual(self.calls,['kimi','harness'])
 def test_same_output_failure_not_repeated_on_helper(self):
  self.run_case(False);self.calls=[];r=self.run_case(False);self.assertFalse(r.ok);self.assertEqual(self.calls,[])
 def test_other_small_task_can_still_use_helper(self):
  self.run_case();self.calls=[];self.assertTrue(self.run_case(name='other.json').ok);self.assertEqual(self.calls,['kimi','harness'])
 def test_recovery_budget_stops(self):
  self.task.brain_recoveries=2;r=self.run_case();self.assertFalse(r.ok);self.assertEqual(self.calls,['kimi'])
 def test_no_allowed_brain_does_not_invent_one(self):
  self.task.routing_config['profiles']=self.task.routing_config['profiles'][:1];r=self.run_case();self.assertFalse(r.ok);self.assertEqual(self.calls,['kimi'])
 def test_cancelled_result_does_not_recover(self):
  async def execute(*a):self.calls.append('helper');return ExecutionResult(cancelled=True)
  self.service._execute_manual=execute;r=asyncio.run(routing.execute(self.service,self.command(),self.task));self.assertTrue(r.cancelled);self.assertEqual(self.calls,['helper'])
 def test_simple_helper_not_general_or_complex(self):
  p=self.task.routing_config['profiles'][0];self.assertFalse(routing.matches(p,'complex'));self.assertFalse(routing.matches(p,'general'))
 def test_overall_invocation_budget_blocks_recovery(self):
  self.task.routing_invocations=100;r=self.run_case();self.assertFalse(r.ok);self.assertEqual(self.calls,[])
