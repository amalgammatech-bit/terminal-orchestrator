import unittest
from unittest.mock import patch
from orchestrator.services import agent,routing
class DeepseekCatalogTests(unittest.TestCase):
 def test_text_coder_in_common_catalog_without_agent_binding(self):
  row={'provider':'ollama','model':'deepseek-coder-v2:16b','label':'Local','capabilities':['completion','insert']}
  with patch.object(agent.SETTINGS,'section',return_value={'models':[row]}):
   self.assertEqual(agent.catalog(),[row]);self.assertNotIn('compatible_kinds',agent.catalog()[0])
 def test_model_can_be_selected_with_different_agents(self):
  model={'model':'deepseek-coder-v2:16b','provider':'ollama'}
  for kind in ('aider','opencode','harness','hermes'):
   row={'id':'local','kind':kind,'model':model['model'],'enabled':True}
   self.assertEqual(routing.validate({'profiles':[row]},[model])['profiles'][0]['kind'],kind)
