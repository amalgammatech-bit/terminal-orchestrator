import unittest,tempfile
from pathlib import Path
from unittest.mock import patch
from orchestrator.services import verified_skills as s
class SkillTests(unittest.TestCase):
 def test_mismatch_never_promotes(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d);f=p/'x';f.write_bytes(b'\xef\xbb\xbfx\r\n')
   with patch.object(s.SETTINGS,'path',return_value=p/'data/sessions.db'):
    with self.assertRaises(ValueError):s.learn_exact(p,f,b'x\n')
    self.assertEqual(s.catalog(p),[])
 def test_only_fixed_recipe_and_project_scope(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d);a=p/'a';a.mkdir();b=p/'b';b.mkdir();f=a/'x';f.write_bytes(b'x\n')
   with patch.object(s.SETTINGS,'path',return_value=p/'data/sessions.db'):
    s.learn_exact(a,f,b'x\n');self.assertIn('write_bytes',s.instructions(a));self.assertEqual(s.catalog(b),[])
    with self.assertRaises(ValueError):s.learn_exact(b,f,b'x\n')
