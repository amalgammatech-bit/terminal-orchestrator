import unittest,json,threading,urllib.request
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from unittest.mock import patch
from orchestrator.services import harness_brain,provider_observer
from orchestrator.services.executor import ExecutionResult
class BudgetTests(unittest.TestCase):
 def test_output_reserve_bounded_by_context(self):
  self.assertEqual(harness_brain.output_budget({'context':32768,'harness_max_output_tokens':8192}),8192)
  self.assertEqual(harness_brain.output_budget({'context':8192}),4096)
  with self.assertRaises(ValueError):harness_brain.output_budget({'harness_max_output_tokens':-1})
 def test_length_is_explicit_failure_and_metadata_preserved(self):
  from contextlib import contextmanager
  @contextmanager
  def observer(p, **kwargs):yield p,[{'max_tokens':2048,'finish_reasons':['length'],'usage':{'completion_tokens':2048}}]
  with patch.object(provider_observer,'observe',observer),patch.object(harness_brain,'_run_harness',return_value=ExecutionResult(returncode=1)),patch('orchestrator.services.executor._save_result',side_effect=lambda r:r):
   r=harness_brain.run('test','project',{'provider':'api'},None)
   self.assertIn('finish_reason=length',r.error);self.assertEqual(r.provider_diagnostics[0]['usage']['completion_tokens'],2048)
 def test_observer_sse_collects_metadata_without_content(self):
  class Upstream(BaseHTTPRequestHandler):
   def log_message(self,*args):pass
   def do_POST(self):
    self.rfile.read(int(self.headers['Content-Length']));self.send_response(200);self.end_headers()
    self.wfile.write(b'data: {"choices":[{"delta":{"content":"PRIVATE"},"finish_reason":"length"}],"usage":{"completion_tokens":16}}\n\ndata: [DONE]\n\n')
  server=ThreadingHTTPServer(('127.0.0.1',0),Upstream);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
  try:
   with provider_observer.observe({'url':f'http://127.0.0.1:{server.server_port}/v1','api_key':'SECRET'}) as (p,rows):
    req=urllib.request.Request(p['url']+'/chat/completions',data=json.dumps({'stream':True,'max_tokens':16}).encode(),headers={'Authorization':'Bearer '+p['api_key']})
    with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(req) as resp:self.assertIn(b'PRIVATE',resp.read())
   self.assertEqual(rows[0]['finish_reasons'],['length']);self.assertNotIn('PRIVATE',str(rows));self.assertNotIn('SECRET',str(rows))
  finally:server.shutdown();server.server_close();thread.join(2)
 def test_one_token_bookkeeping_is_not_output_failure(self):
  from contextlib import contextmanager
  @contextmanager
  def observer(p, **kwargs):yield p,[{'max_tokens':1,'finish_reasons':['length']}]
  with patch.object(provider_observer,'observe',observer),patch.object(harness_brain,'_run_harness',return_value=ExecutionResult(returncode=1)),patch('orchestrator.services.executor._save_result',side_effect=lambda r:r):
   r=harness_brain.run('test','project',{'provider':'api'},None)
   self.assertNotIn('finish_reason=length',r.error)
