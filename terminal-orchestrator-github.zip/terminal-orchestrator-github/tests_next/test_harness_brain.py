import asyncio
import threading
import unittest
from types import SimpleNamespace
from unittest.mock import patch
from orchestrator.services import brain_chain, harness_brain
from orchestrator.services.executor import ExecutionResult


class HarnessTests(unittest.TestCase):
    def test_validation_preserves_old_hermes_and_selects_harness(self):
        models=[('Test','api','test',32768)]
        with patch.object(harness_brain,'executable',return_value='dsh.cmd'):
            result=brain_chain.validate({'primary':'api:test','engine':'harness'},models)
        self.assertEqual(result['engine'],'harness')
        self.assertFalse(result['hermes'])
        with patch.object(harness_brain,'executable',return_value=None):
            with self.assertRaises(ValueError):brain_chain.validate({'primary':'api:test','engine':'harness'},models)

    def test_patch_has_no_credentials_and_disables_direct_execution(self):
        rows=harness_brain.planner_patch({'model':'test','api_key':'SECRET'},'http://localhost/v1')
        self.assertNotIn('SECRET',str(rows))
        self.assertTrue(next(r for r in rows if r['id']=='tool-bash')['disabled'])
        self.assertTrue(next(r for r in rows if r['id']=='tool-subagent')['disabled'])

    def test_brain_command_reaches_existing_router_and_next_turn(self):
        from orchestrator.services import routing
        profile=dict(id='helper',kind='kimi',model='',device='cpu',enabled=True,fallback=False,category='general',priority=1,timeout=60,label='Helper')
        task=SimpleNamespace(project='',cancelled=threading.Event(),routing_config=dict(mode='auto',manager='brain',allow_cloud=True,profiles=[profile]))
        from unittest.mock import AsyncMock, Mock
        service=SimpleNamespace(agent_models=[],_execute_manual=AsyncMock(return_value=ExecutionResult(returncode=0,stdout='checked')),emit=Mock())
        import json
        from pathlib import Path
        task.project=str(Path.cwd())
        command=('delegate',json.dumps(dict(profile='helper',category='general',task='Check result')),task.project)
        with patch('orchestrator.services.executors.executable',return_value='kimi.cmd'), patch('orchestrator.services.routing.resolve_project',side_effect=lambda p:Path(p)):
            result=asyncio.run(routing.execute(service,command,task))
        self.assertTrue(result.ok)
        self.assertEqual(task.executor_kind,'kimi')
        service._execute_manual.assert_awaited_once()

    def test_harness_chat_without_project_uses_selected_model(self):
        from unittest.mock import Mock
        client=Mock(model='test',max_output_tokens=128,input_budget=16000)
        client.chat.return_value='OK'
        service=SimpleNamespace(models=[('Test','api','test',32768)],model_factory=lambda i:client,progress=Mock(),emit=Mock())
        task=SimpleNamespace(brain_settings={'engine':'harness'},brain_index=0,cancelled=threading.Event(),project='')
        with patch.object(harness_brain,'run') as runner:
            answer=asyncio.run(brain_chain.ask(service,task,[{'role':'user','content':'Hi'}],'System'))
        self.assertEqual(answer,'OK')
        runner.assert_not_called()
        client.chat.assert_called_once()
        self.assertIn('Проект не выбран',client.chat.call_args.args[1])
        self.assertIn('Можно поручать задачи',client.chat.call_args.args[1])
        self.assertNotIn('Сейчас доступен только текстовый разговор',client.chat.call_args.args[1])

    def test_real_provider_adapter_accepts_brain_profile(self):
        from orchestrator.services import executors
        client=SimpleNamespace(model='test',url='https://example.com/v1',api_key='synthetic',input_budget=16000,max_output_tokens=2048)
        profile=brain_chain.hermes_connection(client,('Test API','registry','id',32768),'cpu')
        with executors.connection(profile) as (url,key):
            self.assertEqual(url,'https://example.com/v1')
            self.assertEqual(key,'synthetic')
        profile=brain_chain.hermes_connection(client,('Local','ollama','test',32768),'cpu')
        with executors.connection(profile) as (url,key):
            self.assertTrue(url.startswith('http://127.0.0.1:'))
