import unittest
from orchestrator.services import roles,routing
class RoleTests(unittest.TestCase):
 def row(self,**changes):return dict(id='test',kind='opencode',model='',enabled=False,**changes)
 def test_legacy_defaults(self):
  p=routing.validate({'profiles':[self.row()]},[])['profiles'][0]
  self.assertEqual(p['role'],'general');self.assertEqual(p['role_instructions'],'')
 def test_roles_and_custom_survive_validation(self):
  for role in roles.ROLES:
   p=routing.validate({'profiles':[self.row(role=role,role_instructions='CUSTOM')]},[])['profiles'][0]
   self.assertEqual(p['role'],role);self.assertIn('CUSTOM',roles.prompt(p));self.assertIn('не расширяет права',roles.prompt(p))
 def test_invalid_roles_and_oversized_instructions_rejected(self):
  for changes in ({'role':'unknown'},{'role':[]},{'role_instructions':'x'*4001}):
   with self.assertRaises(ValueError):routing.validate({'profiles':[self.row(**changes)]},[])
