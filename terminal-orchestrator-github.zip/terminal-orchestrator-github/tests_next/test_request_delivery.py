import asyncio,json,threading,unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock,Mock
from orchestrator.services.provider_observer import request_fingerprint
from orchestrator.services.runner import run_turn

class RequestDeliveryTests(unittest.TestCase):
 def test_prompt_is_present_without_logging_content(self):
  prompt='Private task with unicode: задача'
  evidence=request_fingerprint({'messages':[{'role':'user','content':'prefix '+prompt}]},prompt)
  self.assertTrue(evidence['expected_prompt_present'])
  self.assertEqual(evidence['expected_prompt_chars'],len(prompt))
  self.assertNotIn(prompt,json.dumps(evidence))
 def test_missing_prompt_and_changed_payload_distinguished(self):
  a=request_fingerprint({'messages':[{'role':'system','content':'system'}]},'task')
  b=request_fingerprint({'messages':[{'role':'user','content':'task'}]},'task')
  self.assertFalse(a['expected_prompt_present']);self.assertTrue(b['expected_prompt_present'])
  self.assertNotEqual(a['messages'][0]['sha256'],b['messages'][0]['sha256'])
 def test_multimodal_content_extracts_text_only(self):
  evidence=request_fingerprint({'messages':[{'role':'user','content':[{'type':'text','text':'task'},{'type':'image_url','image_url':{'url':'PRIVATE_URL'}}]}]},'task')
  self.assertTrue(evidence['expected_prompt_present']);self.assertNotIn('PRIVATE_URL',json.dumps(evidence))
 def test_no_contract_warns_next_planner_and_greeting_stays_unverified(self):
  command=json.dumps({'action':'delegate','profile':'helper','category':'simple','task':'Create file'})
  ask=AsyncMock(side_effect=[command,'Hello! How can I help you today?'])
  execute=AsyncMock(return_value=SimpleNamespace(ok=True,cancelled=False,summary=lambda n:'Created file'))
  emit=Mock()
  outcome=asyncio.run(run_turn([], '',SimpleNamespace(project='',cancelled=threading.Event()),ask,execute,emit,Mock(),options=dict(max_steps=2,history_messages=20,max_consecutive_errors=2,result_chars=1000)))
  self.assertEqual(outcome,'unverified');self.assertEqual(execute.await_count,1)
  self.assertIn('без expected_artifacts',ask.await_args.args[1][-1]['content'])
  self.assertTrue(any('action finish' in c.args[2] for c in emit.call_args_list))
