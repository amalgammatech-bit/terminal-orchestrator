import asyncio,threading,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock,patch
from orchestrator.services import executors,brain_chain,harness_brain
from orchestrator.services.executor import ExecutionResult
class AgentChoices(unittest.TestCase):
 def test_harness_uses_selected_profile_and_write_mode(self):
  profile={'provider':'api','model':'test'}
  with patch.object(executors,'resolve_project',return_value=Path.cwd()),patch.object(executors,'executable',return_value='dsh'),patch.object(harness_brain,'run',return_value=ExecutionResult(returncode=0)) as run:
   executors.run_agent('work',str(Path.cwd()),threading.Event(),agent=profile,kind='harness',memory=False)
  self.assertIs(run.call_args.args[2],profile);self.assertTrue(run.call_args.kwargs['direct'])
 def test_claude_planner_disables_tools_and_uses_stdin(self):
  with patch.object(executors,'resolve_project',return_value=Path.cwd()),patch.object(executors,'executable',return_value='claude'),patch.object(executors,'_run',return_value=ExecutionResult(returncode=0)) as run:
   executors.run_agent('plan',str(Path.cwd()),threading.Event(),kind='claude',planner=True)
  args=run.call_args.args[0];self.assertEqual(args[args.index('--tools')+1],'');self.assertIn('--strict-mcp-config',args);self.assertNotIn('--dangerously-skip-permissions',args);self.assertEqual(run.call_args.kwargs['input_text'],'plan')
 def test_claude_selected_api_is_scoped_to_child(self):
  env=executors.claude_api_environment({'provider':'api','url':'https://llm-router.org/v1','model':'deepseek-v4-pro','api_key':'synthetic'})
  self.assertEqual(env['ANTHROPIC_MODEL'],'deepseek-v4-pro');self.assertEqual(env['ANTHROPIC_BASE_URL'],'https://llm-router.org')
  with self.assertRaises(ValueError):executors.claude_api_environment({'provider':'api','url':'https://unrelated.example/v1'})
 def test_claude_validation(self):
  with patch.object(executors,'executable',return_value='claude'):
   result=brain_chain.validate({'engine':'claude','primary':'api:test'},[('Test','api','test',32768)])
  self.assertEqual(result['engine'],'claude')
