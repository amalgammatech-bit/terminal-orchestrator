import unittest
from unittest.mock import patch
from orchestrator.services import routing


class RoutingCategories(unittest.TestCase):
    def profile(self,**changes):
        return dict(id='worker',kind='kimi',model='',enabled=True,category='general',**changes)

    def test_two_categories_roundtrip(self):
        profile=self.profile(categories=['simple','complex'])
        config=routing.validate({'mode':'manual','profiles':[profile]},[])
        result=config['profiles'][0]
        self.assertEqual(result['categories'],['simple','complex'])
        self.assertTrue(routing.matches(result,'simple'))
        self.assertTrue(routing.matches(result,'complex'))

    def test_legacy_category_preserved(self):
        profile=self.profile();profile['category']='review'
        result=routing.validate({'profiles':[profile]},[])['profiles'][0]
        self.assertEqual(result['categories'],['review'])
        self.assertFalse(routing.matches(result,'simple'))

    def test_complex_task_excludes_simple_only(self):
        self.assertFalse(routing.matches(self.profile(categories=['simple']),'complex'))
        self.assertTrue(routing.matches(self.profile(categories=['complex']),'review'))

    def test_auto_disabled_remains_ineligible(self):
        profile=self.profile(categories=['simple','complex']);profile['enabled']=False
        with patch.object(routing.executors,'executable',return_value='test'):
            self.assertEqual(routing.eligible({'profiles':[profile],'allow_cloud':True},[]),[])

    def test_invalid_categories_rejected(self):
        for categories in ([],['simple','simple'],['unknown'],'simple'):
            with self.assertRaises(ValueError):routing.validate({'profiles':[self.profile(categories=categories)]},[])
