import json
from pathlib import Path
import sys
import uuid
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from orchestrator.services import model_registry as registry


class RegistryTests(unittest.TestCase):
    def setUp(self):
        temporary = Path(__file__).resolve().parent / ('registry-fixture-' + uuid.uuid4().hex)
        temporary.mkdir()
        self.file = temporary / 'registry.json'
        self.patch = patch.object(registry, 'path', return_value=self.file)
        self.patch.start()
        self.addCleanup(self.patch.stop)
        self.crypto = patch.object(registry, 'protect', side_effect=lambda text, decrypt=False: text[10:] if decrypt else 'encrypted:' + text)
        self.crypto.start()
        self.addCleanup(self.crypto.stop)
        self.data = dict(label='Test brain', url='https://api.example/v1', model='model-a',
                         context=64000, input_budget=30000, max_output_tokens=2000,
                         api_key='test-secret', enabled=True, brain_only=False)

    def test_saved_secret_is_never_public(self):
        row = registry.save_profile(self.data)
        self.assertTrue(row['has_key'])
        self.assertNotIn('api_key', row)
        self.assertNotIn('protected_key', row)
        self.assertNotIn('test-secret', json.dumps(registry.public_list()))
        self.assertEqual(registry.private_profile(row['id'])['api_key'], 'test-secret')

    def test_blank_key_preserves_and_clear_removes(self):
        row = registry.save_profile(self.data)
        updated = registry.save_profile({**self.data, 'id': row['id'], 'api_key': '', 'label': 'Renamed'})
        self.assertEqual(updated['id'], row['id'])
        self.assertEqual(registry.private_profile(row['id'])['api_key'], 'test-secret')
        registry.save_profile({**self.data, 'id': row['id'], 'api_key': '', 'clear_key': True})
        self.assertFalse(registry.public_list()[0]['has_key'])

    def test_cross_host_key_not_reused(self):
        row = registry.save_profile(self.data)
        with self.assertRaises(ValueError):
            registry.save_profile({**self.data, 'id': row['id'], 'api_key': '', 'url': 'https://other.example/v1'})
        self.assertEqual(registry.private_profile(row['id'])['url'], self.data['url'])

    def test_brain_only_not_exposed_to_agents(self):
        row = registry.save_profile({**self.data, 'brain_only': True})
        self.assertEqual(registry.brain_rows()[0][2], row['id'])
        self.assertEqual(registry.agent_rows(), [])

    def test_agent_row_keeps_actual_model_and_no_key(self):
        row = registry.save_profile(self.data)
        agent = registry.agent_rows()[0]
        self.assertEqual(agent['model'], 'registry:' + row['id'])
        self.assertEqual(agent['actual_model'], self.data['model'])
        self.assertEqual(agent['registry_id'], row['id'])
        self.assertNotIn('api_key', agent)

    def test_disabled_profile_not_available(self):
        row = registry.save_profile({**self.data, 'enabled': False})
        self.assertEqual(registry.brain_rows(), [])
        with self.assertRaises(ValueError):
            registry.private_profile(row['id'])

    def test_candidate_does_not_save(self):
        candidate = registry.candidate(self.data)
        self.assertEqual(candidate['api_key'], 'test-secret')
        self.assertFalse(self.file.exists())

    def test_profile_limit_and_update_at_limit(self):
        for n in range(30):
            registry.save_profile({**self.data, 'id': str(n)})
        with self.assertRaises(ValueError):
            registry.save_profile(self.data)
        registry.save_profile({**self.data, 'id': '0', 'label': 'Updated'})
        self.assertEqual(len(registry.public_list()), 30)

    def test_delete_and_missing(self):
        row = registry.save_profile(self.data)
        registry.delete_profile(row['id'])
        self.assertEqual(registry.public_list(), [])
        with self.assertRaises(ValueError):
            registry.delete_profile(row['id'])

    def test_invalid_limits_urls_flags_rejected(self):
        for changes in ({'context': True}, {'context': 100}, {'url': 'https://user:pass@api.example'},
                        {'url': 'http://api.example'}, {'url': 'https://api.example:wrong'},
                        {'url': 'https://api.example/v1?key=abc'}, {'brain_only': 1}, {'enabled': 1},
                        {'label': ''}, {'label': 'bad\nlabel'}, {'model': ''}, {'id': '../bad'},
                        {'id': 0}, {'id': False}):
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                registry.save_profile({**self.data, **changes})

    def test_factory_resolves_registry_identifier(self):
        row = registry.save_profile(self.data)
        from orchestrator.services.llm.factory import create_model
        model = create_model((row['label'], 'registry', row['id'], row['context']))
        self.assertEqual(model.model, self.data['model'])
        self.assertEqual(model.api_key, 'test-secret')


if __name__ == '__main__':
    unittest.main()
