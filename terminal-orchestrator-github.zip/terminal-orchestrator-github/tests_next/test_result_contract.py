import asyncio,json,tempfile,threading,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch,AsyncMock,Mock
from orchestrator.services import artifacts,agent,runner
from orchestrator.services.executor import ExecutionResult
from orchestrator.utils.parser import parse_command
class ContractTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
  self.guard=patch('orchestrator.services.access.check_read',side_effect=lambda p:p);self.guard.start()
 def tearDown(self):self.guard.stop();self.tmp.cleanup()
 def test_missing_and_unchanged_fail(self):
  spec=[{'path':'r.json','format':'json','required_keys':['operations'],'equals':{'approved':False}}]
  before=artifacts.snapshot(self.root,spec)
  with self.assertRaises(ValueError):artifacts.verify(self.root,spec,before)
  (self.root/'r.json').write_text('{"operations":[],"approved":false}')
  self.assertEqual(len(artifacts.verify(self.root,spec,before)),1)
  before=artifacts.snapshot(self.root,spec)
  with self.assertRaises(ValueError):artifacts.verify(self.root,spec,before)
 def test_null_or_wrong_flag_fail(self):
  for body in ['{"operations":null,"approved":false}','{"operations":[],"approved":true}']:
   (self.root/'r.json').write_text(body)
   with self.assertRaises(ValueError):artifacts.verify(self.root,[{'path':'r.json','format':'json','required_keys':['operations'],'equals':{'approved':False}}])
 def test_outside_rejected(self):
  for name in ['../secret',str(self.root/'absolute')]:
   with self.assertRaises(ValueError):artifacts.snapshot(self.root,[{'path':name}])
 def loop(self,write,final='completed'):
  task=SimpleNamespace(cancelled=threading.Event(),project=str(self.root))
  command=json.dumps({'action':'delegate','task':'create','expected_artifacts':[{'path':'a.json','format':'json','required_keys':['ok']}]})
  async def execute(*a):
   if write:(self.root/'a.json').write_text('{"ok":true}')
   return ExecutionResult(returncode=0)
  return asyncio.run(runner.run_turn([], '',task,AsyncMock(side_effect=[command,json.dumps({'action':'finish','status':final,'summary':'result'})]),execute,Mock(),Mock(),options={'max_steps':2,'max_consecutive_errors':1,'history_messages':10,'result_chars':1000}))
 def test_false_success_rejected(self):self.assertEqual(self.loop(False),'error')
 def test_verified_contract_and_explicit_finish(self):self.assertEqual(self.loop(True),'checked')
 def test_explicit_incomplete_stays_incomplete(self):self.assertEqual(self.loop(True,'incomplete'),'incomplete')
 def test_parser_preserves_contract(self):
  c=parse_command('{"action":"delegate","task":"x","expected_artifacts":[{"path":"x"}]}');self.assertEqual(json.loads(c[1])['expected_artifacts'][0]['path'],'x')
class BudgetContractTests(unittest.TestCase):
 def profile(self):return {'provider':'ollama','context':64000,'device':'cpu','model':'test','label':'test','url':'http://localhost:1'}
 def test_local_announced_matches_request(self):
  p=self.profile();payload=agent.native_payload({'messages':[]},p)
  with agent.agent_provider(p) as raw:cfg=json.loads(raw)
  lim=cfg['provider']['orchestrator-agent']['models']['test']['limit']
  self.assertEqual(lim['context'],payload['options']['num_ctx']);self.assertEqual(lim['output'],payload['options']['num_predict']);self.assertEqual(lim['context'],64000)
 def test_api_output_separate_from_chat(self):
  p={**self.profile(),'provider':'api','max_output_tokens':2048,'executor_max_output_tokens':8192}
  with agent.agent_provider(p) as raw:cfg=json.loads(raw)
  self.assertEqual(cfg['provider']['orchestrator-agent']['models']['test']['limit']['output'],8192)
 def test_local_length_preserved(self):
  class Response:
   def __enter__(self):return self
   def __exit__(self,*a):pass
   def read(self):return b'{"message":{"content":"partial"},"done_reason":"length","eval_count":4096}'
  with patch('urllib.request.build_opener') as opener:
   opener.return_value.open.return_value=Response()
   self.assertEqual(agent.completion({'messages':[]},self.profile())['choices'][0]['finish_reason'],'length')
