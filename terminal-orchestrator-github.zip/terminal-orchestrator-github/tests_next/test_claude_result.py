import json,unittest
from unittest.mock import patch
from orchestrator.services.claude_result import normalize
from orchestrator.services.executor import ExecutionResult
from orchestrator.services.harness_brain import planner_result
class ClaudeResultTests(unittest.TestCase):
 def check(self,**fields):
  payload={'type':'result','subtype':'success','is_error':False,'result':'answer',**fields}
  with patch('orchestrator.services.claude_result._save_result',side_effect=lambda r:r):return normalize(ExecutionResult(returncode=0,stdout=json.dumps(payload)))
 def test_success_unwraps_and_preserves_protocol(self):
  r=self.check(usage={'input_tokens':123},stop_reason='end_turn');self.assertTrue(r.ok);self.assertEqual(r.stdout,'answer');self.assertEqual(r.claude_diagnostics['usage']['input_tokens'],123);self.assertIn('type',r.protocol_stdout)
 def test_empty_success_is_not_accepted(self):
  r=self.check(result='',stop_reason='end_turn');self.assertFalse(r.ok);self.assertIn('end_turn',r.error)
 def test_is_error_overrides_process_zero(self):self.assertFalse(self.check(is_error=True).ok)
 def test_truncated_text_is_not_accepted(self):self.assertFalse(self.check(stop_reason='max_tokens').ok)
 def test_no_valid_envelope_is_not_accepted(self):
  for body in ['\n','not json','[]','{"result":"answer"}']:
   with patch('orchestrator.services.claude_result._save_result',side_effect=lambda r:r):r=normalize(ExecutionResult(returncode=0,stdout=body))
   self.assertFalse(r.ok);self.assertEqual(r.stdout,'');self.assertEqual(r.protocol_stdout,body)
 def test_cancel_and_timeout_stay_distinct(self):
  for field in ['cancelled','timed_out']:
   with patch('orchestrator.services.claude_result._save_result',side_effect=lambda r:r):r=normalize(ExecutionResult(returncode=1,stdout='partial',**{field:True}))
   self.assertTrue(getattr(r,field));self.assertNotIn('JSON',r.error)
 def test_error_label_is_claude(self):self.assertTrue(planner_result(ExecutionResult(error='empty'),label='Claude Code').startswith('[ERR] Claude Code:'))
