"""Isolated HTTP and task integration: no personal DB, keys or model requests."""
import importlib
import json
import sys
import threading
import unittest
import urllib.request
import urllib.error
import uuid
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch, Mock
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from orchestrator.config import SETTINGS

class IntegrationTests(unittest.TestCase):
    def setUp(self):
        self.fixture=Path(__file__).resolve().parent / ('integration-fixture-'+uuid.uuid4().hex)
        self.fixture.mkdir()
        self.project=self.fixture/'project';self.project.mkdir()
        self.outside=self.fixture/'outside';self.outside.mkdir()
        paths={'sessions_db':self.fixture/'sessions.db','memory_dir':self.fixture/'memory','logs_dir':self.fixture/'logs','projects_root':self.project}
        self.patches=[]
        self.patch(SETTINGS,'path',side_effect=lambda name:paths[name])
        from orchestrator.services import access
        access.save({'mode':'folder','folder':str(self.project)})
        # These imports happen with the isolated SETTINGS paths already applied.
        self.d=importlib.import_module('orchestrator.services.desktop')
        self.session=importlib.import_module('orchestrator.models.session')
        self.patch(self.session,'DB_PATH',new=self.fixture/'sessions.db');self.session.init_db()
        self.patch(self.d,'load_memory',return_value='')
        self.patch(self.d.executors,'catalog',return_value=[])
        self.patch(self.d.model_registry,'protect',side_effect=lambda value,decrypt=False:value[4:] if decrypt else 'enc:'+value)
        self.service=self.d.DesktopService()
        self.server=self.d.make_server(self.service,Path(__file__).resolve().parents[1]/'web')
        self.worker=threading.Thread(target=self.server.serve_forever,daemon=True);self.worker.start()
        self.addCleanup(self.cleanup)
    def patch(self,obj,name,**kw):
        p=patch.object(obj,name,**kw);self.patches.append(p);return p.start()
    def cleanup(self):
        self.server.shutdown();self.server.server_close();self.service.close();self.worker.join(2)
        for p in reversed(self.patches):p.stop()
    def request(self,route,data=None,auth=True):
        headers={'Content-Type':'application/json'}
        if auth:headers['Authorization']='Bearer '+self.server.token
        body=json.dumps(data).encode() if data is not None else None
        req=urllib.request.Request('http://127.0.0.1:'+str(self.server.server_port)+'/api/'+route,data=body,headers=headers)
        try:
            with urllib.request.urlopen(req,timeout=5) as r:return r.status,json.load(r)
        except urllib.error.HTTPError as e:return e.code,json.load(e)
    def profile(self,**changes):
        return dict(label='Synthetic API',url='https://example.invalid/v1',model='test-model',context=64000,input_budget=30000,max_output_tokens=2000,api_key='synthetic-secret',enabled=True,brain_only=False,**changes)
    def test_registry_http_roundtrip_bootstrap_no_secret(self):
        status,value=self.request('model-registry/save',self.profile())
        self.assertEqual(status,200,value)
        row=value['profiles'][0];ident=row['id']
        self.assertNotIn('synthetic-secret',json.dumps(value))
        status,boot=self.request('bootstrap');self.assertEqual(status,200)
        self.assertTrue(any(x['provider']=='registry' and x['model']==ident for x in boot['models']))
        self.assertTrue(any(x.get('registry_id')==ident for x in boot['agents']))
        self.assertNotIn('synthetic-secret',json.dumps(boot))
        self.assertEqual(self.request('model-registry/delete',{'id':ident})[0],200)
        self.assertEqual(self.request('model-registry')[1]['profiles'],[])
    def test_registry_requires_auth_and_idle(self):
        self.assertEqual(self.request('model-registry',auth=False)[0],401)
        self.service.active=SimpleNamespace(cancelled=threading.Event())
        self.assertEqual(self.request('model-registry/save',self.profile())[0],409)
        self.service.active=None
        self.service.update_status['active']=True
        self.assertEqual(self.request('model-registry/save',self.profile())[0],409)
    def test_folder_read_boundary_and_execution_fail_closed(self):
        self.assertEqual(self.request('access',{'mode':'folder','folder':str(self.project)})[0],200)
        from orchestrator.services.executor import resolve_project,_run
        self.assertEqual(resolve_project(str(self.project)),self.project)
        with patch('orchestrator.services.access.request',side_effect=ValueError('Denied')):
            with self.assertRaises(ValueError):resolve_project(str(self.outside))
        with patch('subprocess.Popen') as process, patch('orchestrator.services.access.request',side_effect=ValueError('Denied')):
            result=_run(['not-run'],2)
            self.assertFalse(result.ok);process.assert_not_called()
    def test_computer_accepts_project_outside_config_root(self):
        self.assertEqual(self.request('access',{'mode':'computer','folder':''})[0],200)
        from orchestrator.services.executor import resolve_project
        with patch('orchestrator.services.access.request') as approval:
            self.assertEqual(resolve_project(str(self.outside)),self.outside)
            approval.assert_called_once()
    def test_access_change_requires_idle(self):
        self.service.active=SimpleNamespace(cancelled=threading.Event())
        self.assertEqual(self.request('access',{'mode':'folder','folder':str(self.project)})[0],409)
    def test_registry_task_self_execute_never_exposes_secret(self):
        saved=self.request('model-registry/save',self.profile())[1]['profiles'][0]
        index=next(i for i,r in enumerate(self.service.models) if r[1]=='registry')
        self.service.preferences.update(brain_execute=True,brain_executor_kind='opencode',executor_kind='none',hermes_memory=False,routing={'mode':'manual','profiles':[]})
        self.patch(self.d.executors,'executable',return_value='synthetic.exe')
        run=self.patch(self.service,'_run',return_value=None)
        sid=self.session.Session.create('Synthetic',str(self.project))
        result=self.service.start(sid,'Synthetic task',index)
        self.service.thread.join(2)
        self.assertNotIn('synthetic-secret',json.dumps(result))
        self.assertEqual(self.service.active.executor_kind,'opencode')
        self.assertEqual(self.service.active.agent_connection['api_key'],'synthetic-secret')
        self.assertEqual(self.service.active.agent['model'],'test-model')
        from orchestrator.services.agent import agent_provider
        with agent_provider(self.service.active.agent_connection) as encoded:
            provider=json.loads(encoded)
            self.assertIn('test-model',provider['model'])
        run.assert_called_once()

    def test_brain_only_profile_cannot_execute(self):
        data=self.profile();data['brain_only']=True
        self.request('model-registry/save',data)
        index=next(i for i,r in enumerate(self.service.models) if r[1]=='registry')
        self.service.preferences.update(brain_execute=True,brain_executor_kind='opencode',executor_kind='none',hermes_memory=False,routing={'mode':'manual','profiles':[]})
        self.patch(self.d.executors,'executable',return_value='synthetic.exe')
        sid=self.session.Session.create('Synthetic',str(self.project))
        with self.assertRaises(ValueError):self.service.start(sid,'Synthetic task',index)
        self.assertIsNone(self.service.active)
        self.assertEqual(self.session.Message.get_by_session(sid),[])

    def test_auto_brain_self_instructions_and_snapshot(self):
        self.request('model-registry/save',self.profile())
        index=next(i for i,r in enumerate(self.service.models) if r[1]=='registry')
        helper=dict(id='helper',kind='kimi',model='',device='cpu',enabled=True,fallback=False,category='general',priority=50,timeout=60,label='Helper')
        self.service.preferences.update(brain_execute=True,brain_executor_kind='opencode',executor_kind='none',agent_timeout=300,hermes_memory=False,routing={'mode':'auto','allow_cloud':True,'profiles':[helper]})
        self.patch(self.d.executors,'executable',return_value='synthetic.exe')
        run=self.patch(self.service,'_run',return_value=None)
        sid=self.session.Session.create('Synthetic',str(self.project))
        result=self.service.start(sid,'Synthetic task',index)
        self.service.thread.join(2)
        task=self.service.active
        instruction=run.call_args.args[2]
        self.assertIn('brain-self',instruction)
        self.assertNotIn('synthetic-secret',instruction)
        own=next(p for p in task.routing_config['profiles'] if p['id']=='brain-self')
        self.d.routing.apply_profile(task,helper,self.service.agent_models)
        self.assertEqual(task.executor_timeout,60)
        self.d.routing.apply_profile(task,own,self.service.agent_models+[task.brain_self_agent])
        self.assertEqual(task.executor_kind,'opencode')
        self.assertEqual(task.executor_timeout,300)
        self.assertEqual(task.agent['model'],'test-model')
        self.assertEqual(task.agent_connection['api_key'],'synthetic-secret')
        self.assertNotIn('synthetic-secret',json.dumps(task.public()))

    def test_auto_only_brain_self_can_start(self):
        self.request('model-registry/save',self.profile())
        index=next(i for i,r in enumerate(self.service.models) if r[1]=='registry')
        self.service.preferences.update(brain_execute=True,brain_executor_kind='opencode',executor_kind='none',hermes_memory=False,routing={'mode':'auto','allow_cloud':True,'profiles':[]})
        self.patch(self.d.executors,'executable',return_value='synthetic.exe')
        self.patch(self.service,'_run',return_value=None)
        sid=self.session.Session.create('Synthetic',str(self.project))
        self.service.start(sid,'Synthetic task',index)
        self.service.thread.join(2)
        self.assertEqual(len(self.service.active.routing_config['profiles']),1)

    def test_bootstrap_registry_budget_and_model_factory(self):
        saved=self.request('model-registry/save',self.profile())[1]['profiles'][0]
        boot=self.request('bootstrap')[1]
        row=next(row for row in boot['models'] if row['provider']=='registry')
        self.assertEqual(row['input_budget'],61360)
        self.assertEqual(row['context'],64000)
        index=next(i for i,r in enumerate(self.service.models) if r[1]=='registry')
        model=self.service._model(index)
        self.assertEqual(model.input_budget,61360)
        self.assertEqual(model.max_output_tokens,2000)
        self.assertEqual(model.model,'test-model')

    def test_executor_updates_refused_during_android_build(self):
        self.patch(self.service.android_builder,'state',return_value={'active':True})
        self.patch(self.d.executors,'catalog',return_value=[dict(id='kimi',can_update=True)])
        worker=self.patch(self.service,'_update_worker',return_value=None)
        with self.assertRaises(self.d.ApiError) as error:self.service.update_executors('all')
        self.assertEqual(error.exception.status,409)
        worker.assert_not_called()




    def test_access_request_roundtrip_http(self):
        from orchestrator.services import access
        done=[]
        def worker():
            access.request('Synthetic request','Synthetic path')
            done.append(True)
        thread=threading.Thread(target=worker);thread.start()
        try:
            status,data=self.request('access/requests')
            self.assertEqual(status,200)
            ident=data['requests'][0]['id']
            self.assertEqual(self.request('access/decision',{'id':ident,'allowed':True},auth=False)[0],401)
            self.assertEqual(self.request('access/decision',{'id':ident,'allowed':True})[0],200)
            thread.join(2)
            self.assertEqual(done,[True])
        finally:
            access.deny_pending();thread.join(2)

if __name__=='__main__':unittest.main()
