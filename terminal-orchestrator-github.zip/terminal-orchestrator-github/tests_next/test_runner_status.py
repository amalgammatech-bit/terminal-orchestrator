import asyncio,threading,unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock,Mock,patch
from orchestrator.services.runner import run_turn
class RunnerStatusTests(unittest.TestCase):
 def run_case(self,replies,results):
  execute=AsyncMock(side_effect=results);emit=Mock()
  with patch('orchestrator.services.runner.parse_command',side_effect=lambda s: None if s=='finished' else ('opencode',s,'project')):
   outcome=asyncio.run(run_turn([], '',SimpleNamespace(cancelled=threading.Event()),AsyncMock(side_effect=replies),execute,emit,Mock(),options=dict(max_steps=1,history_messages=20,max_consecutive_errors=1,result_chars=1000)))
  return outcome,execute,emit
 def test_limit_does_not_execute_pending_command_or_report_done(self):
  result=SimpleNamespace(ok=True,cancelled=False,summary=lambda n:'checked')
  outcome,execute,emit=self.run_case(['first','second'],[result])
  self.assertEqual(outcome,'error');self.assertEqual(execute.await_count,1)
  self.assertIn('Следующая команда не выполнена',emit.call_args.args[2])
 def test_final_answer_after_last_allowed_step_is_done(self):
  result=SimpleNamespace(ok=True,cancelled=False,summary=lambda n:'checked')
  outcome,execute,_=self.run_case(['first','finished'],[result]);self.assertEqual(outcome,'unverified')
 def test_model_error_is_not_done(self):
  outcome,execute,_=self.run_case(['[ERR] provider failed'],[]);self.assertEqual(outcome,'error');execute.assert_not_awaited()
 def test_executor_error_limit_is_not_done(self):
  result=SimpleNamespace(ok=False,cancelled=False)
  outcome,_,_=self.run_case(['first'],[result]);self.assertEqual(outcome,'error')
