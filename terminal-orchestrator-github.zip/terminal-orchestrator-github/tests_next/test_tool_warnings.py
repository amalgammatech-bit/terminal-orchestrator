import unittest
from unittest.mock import patch
from orchestrator.services.executor import ExecutionResult,annotate_tool_warnings
class ToolWarningTests(unittest.TestCase):
 def test_zero_exit_with_powershell_error_is_visible_even_in_short_summary(self):
  r=ExecutionResult(returncode=0,stderr='x'*5000+'\n    + FullyQualifiedErrorId : MissingFileSpecification\n'+'y'*5000)
  with patch('orchestrator.services.executor._save_result',side_effect=lambda r:r):annotate_tool_warnings(r)
  self.assertTrue(r.ok);self.assertEqual(len(r.tool_warnings),1);self.assertIn('ВНИМАНИЕ',r.summary(200));self.assertIn('независимая проверка',r.summary(200))
 def test_ordinary_stderr_is_not_a_tool_failure(self):
  r=ExecutionResult(returncode=0,stderr='model progress ParserError example')
  annotate_tool_warnings(r);self.assertFalse(r.tool_warnings);self.assertTrue(r.ok)
