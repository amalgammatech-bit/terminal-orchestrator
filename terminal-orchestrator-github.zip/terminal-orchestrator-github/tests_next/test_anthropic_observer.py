import json,threading,unittest,urllib.request,urllib.error
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from orchestrator.services.anthropic_observer import observe,Meter
class RelayTests(unittest.TestCase):
 def call(self,body,ctype='text/event-stream',status=200,bad_auth=False,suffix=''):
  seen=[]
  class Upstream(BaseHTTPRequestHandler):
   def log_message(self,*a):pass
   def do_POST(self):
    raw=self.rfile.read(int(self.headers['Content-Length']));seen.append((raw,self.headers.get('x-api-key')))
    self.send_response(status);self.send_header('Content-Type',ctype);self.send_header('request-id','synthetic-id');self.end_headers()
    self.wfile.write(body)
  server=ThreadingHTTPServer(('127.0.0.1',0),Upstream);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
  try:
   with observe(f'http://127.0.0.1:{server.server_port}','UPSTREAM_SECRET') as (env,rows):
    payload=json.dumps({'model':'synthetic','messages':[{'role':'user','content':'PRIVATE_PROMPT'}],'stream':ctype=='text/event-stream','max_tokens':42}).encode()
    req=urllib.request.Request(env['ANTHROPIC_BASE_URL']+'/v1/messages'+suffix,data=payload,headers={'x-api-key':'wrong' if bad_auth else env['ANTHROPIC_API_KEY'],'Content-Type':'application/json'})
    try:
     with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(req,timeout=5) as res:actual=res.read();code=res.status
    except urllib.error.HTTPError as e:actual=e.read();code=e.code
   return actual,code,rows,seen
  finally:server.shutdown();server.server_close();thread.join(2)
 def stream(self,text=True,stop=True):
  events=[{'type':'message_start','message':{'usage':{'input_tokens':12}}},{'type':'content_block_start','content_block':{'type':'text' if text else 'thinking','text':''}}]
  if text:events.append({'type':'content_block_delta','delta':{'type':'text_delta','text':'PRIVATE_ANSWER'}})
  events.append({'type':'message_delta','delta':{'stop_reason':'end_turn'},'usage':{'output_tokens':3}})
  if stop:events.append({'type':'message_stop'})
  return b''.join(b'data: '+json.dumps(e).encode()+b'\n\n' for e in events)
 def test_text_passes_unchanged_and_metadata_private(self):
  body=self.stream();actual,code,rows,seen=self.call(body)
  self.assertEqual(actual,body);self.assertEqual(code,200);self.assertEqual(rows[0]['text_bytes'],len('PRIVATE_ANSWER'));self.assertFalse(rows[0]['incomplete_sse']);self.assertEqual(rows[0]['usage']['input_tokens'],12);self.assertEqual(seen[0][1],'UPSTREAM_SECRET')
  for secret in ('PRIVATE_PROMPT','PRIVATE_ANSWER','UPSTREAM_SECRET'):self.assertNotIn(secret,str(rows))
 def test_thinking_only_has_no_text(self):
  _,_,rows,_=self.call(self.stream(text=False));self.assertEqual(rows[0]['text_bytes'],0);self.assertEqual(rows[0]['blocks']['thinking'],1)
 def test_incomplete_sse_marked(self):
  _,_,rows,_=self.call(self.stream(stop=False));self.assertTrue(rows[0]['incomplete_sse'])
 def test_http_error_preserved_without_error_body_in_metadata(self):
  body=b'{"error":{"message":"PRIVATE_ERROR"}}';actual,code,rows,_=self.call(body,'application/json',429)
  self.assertEqual(code,429);self.assertEqual(actual,body);self.assertEqual(rows[0]['http_status'],429);self.assertNotIn('PRIVATE_ERROR',str(rows))
 def test_bad_auth_does_not_contact_upstream(self):
  _,code,rows,seen=self.call(self.stream(),bad_auth=True);self.assertEqual(code,403);self.assertEqual(rows,[]);self.assertEqual(seen,[])
 def test_json_message_metered(self):
  body=json.dumps({'type':'message','content':[{'type':'text','text':'PRIVATE'}],'stop_reason':'end_turn','usage':{'input_tokens':1,'output_tokens':2}}).encode()
  actual,_,rows,_=self.call(body,'application/json');self.assertEqual(actual,body);self.assertEqual(rows[0]['text_bytes'],7);self.assertEqual(rows[0]['stop_reason'],'end_turn')
 def test_fragmented_crlf_multiline_event(self):
  row={'events':{},'blocks':{},'usage':{},'text_bytes':0,'message_stop':False,'parse_errors':0};m=Meter(row)
  body=b'data: {"type":"message_delta",\r\ndata: "delta":{"stop_reason":"end_turn"}}\r\n\r\ndata: {"type":"message_stop"}\r\n\r\n'
  for byte in body:m.feed(bytes([byte]))
  m.finish();self.assertEqual(row['parse_errors'],0);self.assertTrue(row['message_stop']);self.assertEqual(row['stop_reason'],'end_turn')

class ClassificationTests(unittest.TestCase):
 def test_empty_cli_classified_by_upstream_evidence(self):
  from contextlib import contextmanager
  from unittest.mock import patch
  from orchestrator.services.executors import run_claude_observed
  from orchestrator.services.executor import ExecutionResult
  for row,expected in [({'text_bytes':12},'текст от шлюза дошёл'),({'text_bytes':0,'message_stop':True},'текстовые блоки Anthropic не обнаружены'),({'incomplete_sse':True},'поток шлюза неполный')]:
   @contextmanager
   def observe(*a):yield {},[{'endpoint':'messages',**row}]
   fake=ExecutionResult(returncode=0,stdout='{"type":"result","subtype":"success","is_error":false,"result":"","stop_reason":"end_turn"}')
   with patch('orchestrator.services.anthropic_observer.observe',observe),patch('orchestrator.services.executors._run',return_value=fake),patch('orchestrator.services.executors._save_result',side_effect=lambda r:r),patch('orchestrator.services.claude_result._save_result',side_effect=lambda r:r):
    result=run_claude_observed([],10,None,None,{'ANTHROPIC_BASE_URL':'local','ANTHROPIC_API_KEY':'synthetic'},'synthetic')
   self.assertIn(expected,result.error);self.assertFalse(result.ok)

class BetaQueryTests(RelayTests):
 def test_beta_query_reaches_upstream(self):
  body=self.stream();actual,code,rows,seen=self.call(body,suffix='?beta=true')
  self.assertEqual(code,200);self.assertEqual(actual,body);self.assertEqual(len(seen),1);self.assertEqual(rows[0]['endpoint'],'messages')
 def test_unknown_query_rejected_locally(self):
  _,code,rows,seen=self.call(self.stream(),suffix='?unsupported=true')
  self.assertEqual(code,400);self.assertEqual(seen,[]);self.assertEqual(rows[0]['origin'],'relay')
