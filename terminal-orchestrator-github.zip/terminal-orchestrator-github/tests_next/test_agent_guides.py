import asyncio,json,threading,unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock,Mock
from orchestrator.services import agent_guides,executors
from orchestrator.services.runner import run_turn
from orchestrator.utils.parser import parse_command
class GuideTests(unittest.TestCase):
 def test_every_executor_has_local_guide(self):
  self.assertEqual(set(agent_guides.GUIDES),set(executors.SPECS)-{'none'})
  for key in agent_guides.GUIDES:
   g=agent_guides.read(key);self.assertEqual(len(g['sha256']),64);self.assertTrue(g['official_source'].startswith('https://'))
 def test_paths_unknown_and_project_rejected(self):
  for value in ({'agent':'../../keys'},{'agent':[]},{'agent':'opencode','project':'C:/other'}):
   with self.assertRaises(ValueError):parse_command(json.dumps({'action':'agent_help',**value}))
 def run_case(self,replies):
  ask=AsyncMock(side_effect=replies);execute=AsyncMock();emit=Mock()
  status=asyncio.run(run_turn([{'role':'user','content':'Original task'}],'',SimpleNamespace(cancelled=threading.Event()),ask,execute,emit,Mock(),options=dict(max_steps=1,history_messages=20,max_consecutive_errors=2,result_chars=1000)))
  execute.assert_not_awaited();return status,ask
 def test_help_returns_to_brain_without_execution(self):
  status,ask=self.run_case(['{"action":"agent_help","agent":"aider"}','Explanation'])
  self.assertEqual(status,'done');history=ask.await_args.args[1]
  self.assertEqual(history[0]['content'],'Original task');self.assertIn('official_source',history[-1]['content'])
 def test_repeated_help_stops_without_paid_loop(self):
  status,_=self.run_case(['{"action":"agent_help","agent":"aider"}']*2);self.assertEqual(status,'incomplete')
 def test_limit_is_separate_from_execution_budget(self):
  status,_=self.run_case([json.dumps({'action':'agent_help','agent':k}) for k in list(agent_guides.GUIDES)[:5]])
  self.assertEqual(status,'incomplete')
