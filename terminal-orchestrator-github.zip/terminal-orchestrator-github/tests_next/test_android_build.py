import threading
import subprocess
import unittest
from pathlib import Path
import uuid
from unittest.mock import patch,Mock
from orchestrator.services.android_build import AndroidBuilder

class AndroidBuildTests(unittest.TestCase):
 def setUp(self):
  self.base=Path(__file__).resolve().parent/('fixture-'+uuid.uuid4().hex);self.base.mkdir()
  self.project=self.base/'project';self.project.mkdir();(self.project/'build.ps1').write_text('# synthetic')
  self.builder=AndroidBuilder(lambda p:self.project,self.base/'logs')
 def wait(self,builder=None):
  b=builder or self.builder;b._thread.join(3);self.assertFalse(b.state()['active']);return b.state()
 def apk(self,content='new'):
  p=self.project/'app/build/outputs/apk/debug/app-debug.apk';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(content);return p
 def test_success_requires_new_artifact(self):
  with patch.object(self.builder,'_command',side_effect=lambda *args:self.apk() and 0):
   self.builder.start('project');state=self.wait()
  self.assertEqual(state['status'],'success');self.assertEqual(len(state['artifacts']),1)
 def test_stale_artifact_rejected(self):
  self.apk()
  with patch.object(self.builder,'_command',return_value=0):self.builder.start('project');state=self.wait()
  self.assertEqual(state['status'],'error');self.assertEqual(state['artifacts'],[])
 def test_changed_artifact_accepted(self):
  self.apk('old')
  with patch.object(self.builder,'_command',side_effect=lambda *args:self.apk('changed') and 0):self.builder.start('project');state=self.wait()
  self.assertEqual(state['status'],'success')
 def test_failed_build_does_not_publish_apk(self):
  with patch.object(self.builder,'_command',side_effect=lambda *args:self.apk() and 1):self.builder.start('project');state=self.wait()
  self.assertEqual(state['status'],'error');self.assertEqual(state['artifacts'],[])
 def test_validation_rejects_release_custom_script_and_install(self):
  with self.assertRaises(ValueError):self.builder.start('project','release')
  with self.assertRaises(ValueError):self.builder.start('project',install=True)
  with self.assertRaises(ValueError):self.builder.start('project',install=1)
  with self.assertRaises(ValueError):self.builder.start('project',variant='debug & whoami')
 def test_cancellation_only_owned_process(self):
  ready=threading.Event();release=threading.Event();process=Mock()
  def work(*args):
   self.builder._process=process;ready.set();release.wait(2);return -1
  with patch.object(self.builder,'_command',side_effect=work),patch.object(self.builder,'_terminate_owned_process') as terminate:
   self.builder.start('project');self.assertTrue(ready.wait(1));self.builder.stop();release.set();state=self.wait();terminate.assert_called_once_with(process)
  self.assertEqual(state['status'],'cancelled')
 def test_timeout_reported_without_success_artifacts(self):
  with patch.object(self.builder,'_command',side_effect=subprocess.TimeoutExpired('synthetic',900)):
   self.builder.start('project');state=self.wait()
  self.assertEqual(state['status'],'error');self.assertEqual(state['artifacts'],[])
 def test_second_start_during_build_refused(self):
  ready=threading.Event();release=threading.Event()
  def work(*args):ready.set();release.wait(2);return 1
  with patch.object(self.builder,'_command',side_effect=work):
   self.builder.start('project');self.assertTrue(ready.wait(1))
   with self.assertRaises(ValueError):self.builder.start('project')
   release.set();self.wait()
 def install_builder(self):return AndroidBuilder(lambda p:self.project,self.base/'install','adb.exe','apksigner.exe')
 def test_explicit_install_verifies_signature_and_keeps_data(self):
  b=self.install_builder();commands=[]
  def command(cmd,cwd,log,timeout):
   commands.append(cmd)
   if cmd[0]=='powershell.exe':self.apk()
   if cmd==['adb.exe','devices']:log.write('List of devices attached\nSERIAL\tdevice\n');log.flush()
   return 0
  with patch.object(b,'_command',side_effect=command):b.start('project',install=True);state=self.wait(b)
  self.assertEqual(state['status'],'success')
  self.assertEqual(commands[-2][:2],['apksigner.exe','verify'])
  self.assertEqual(commands[-1][:5],['adb.exe','-s','SERIAL','install','-r'])
  self.assertFalse(any('uninstall' in cmd for cmd in commands))
 def test_multiple_devices_rejected_before_install(self):
  b=self.install_builder();commands=[]
  def command(cmd,cwd,log,timeout):
   commands.append(cmd)
   if cmd[0]=='powershell.exe':self.apk()
   if cmd==['adb.exe','devices']:log.write('List of devices attached\nONE\tdevice\nTWO\tdevice\n');log.flush()
   return 0
  with patch.object(b,'_command',side_effect=command):b.start('project',install=True);state=self.wait(b)
  self.assertEqual(state['status'],'error');self.assertFalse(any('install' in cmd for cmd in commands))
 def test_bad_signature_rejected(self):
  b=self.install_builder();commands=[]
  def command(cmd,cwd,log,timeout):
   commands.append(cmd)
   if cmd[0]=='powershell.exe':self.apk()
   if cmd==['adb.exe','devices']:log.write('List of devices attached\nONE\tdevice\n');log.flush()
   return 1 if cmd[0]=='apksigner.exe' else 0
  with patch.object(b,'_command',side_effect=command):b.start('project',install=True);state=self.wait(b)
  self.assertEqual(state['status'],'error');self.assertFalse(any('install' in cmd for cmd in commands))
 def test_gradle_selects_fixed_release_task(self):
  (self.project/'gradlew.bat').write_text('@echo off')
  commands=[]
  def command(cmd,*args):commands.append(cmd);self.apk();return 0
  with patch.object(self.builder,'_command',side_effect=command):self.builder.start('project','release');state=self.wait()
  self.assertEqual(state['status'],'success');self.assertIn('assembleRelease',commands[0])

 def test_real_windows_wrapper_path_with_spaces(self):
  import os
  if os.name!='nt':self.skipTest('Windows command quoting')
  (self.project/'gradlew.bat').write_text('@echo off\r\nif not "%1"=="assembleDebug" exit /b 9\r\nif not exist dist mkdir dist\r\necho SYNTHETIC_APK>dist\\test.apk\r\nexit /b 0\r\n',encoding='ascii')
  self.builder.start('project');state=self.wait()
  self.assertEqual(state['status'],'success',state)

if __name__=='__main__':unittest.main()

class BuildEnvironmentTests(unittest.TestCase):
 def test_explicit_configuration_preserved(self):
  from orchestrator.services.android_build import build_environment
  with patch.dict('os.environ',{'JAVA_HOME':'custom-jdk','ANDROID_HOME':'custom-sdk'},clear=True):
   env=build_environment()
  self.assertEqual(env['JAVA_HOME'],'custom-jdk');self.assertEqual(env['ANDROID_HOME'],'custom-sdk')
 def test_gui_launch_finds_studio_jbr(self):
  from orchestrator.services.android_build import build_environment
  with patch.dict('os.environ',{'PROGRAMFILES':'C:/Programs','PATH':''},clear=True),patch('shutil.which',return_value=None),patch('pathlib.Path.is_file',return_value=True),patch('pathlib.Path.is_dir',return_value=False):
   env=build_environment()
  self.assertTrue(env['JAVA_HOME'].replace('\\','/').endswith('/Android/Android Studio/jbr'))
  self.assertIn('jbr',env['PATH'])
