import json,unittest
from orchestrator.services.agent import agent_provider
class ProviderBudgetTest(unittest.TestCase):
 def test_small_window_has_room_for_tools_and_compaction(self):
  p=dict(provider='api',model='test',label='test',url='http://localhost/v1',context=32768,input_budget=16000,max_output_tokens=2048)
  with agent_provider(p) as raw: c=json.loads(raw)
  self.assertEqual(c['provider']['orchestrator-agent']['models']['test']['limit']['context'],32768)
  self.assertLessEqual(c['compaction']['reserved'],2048)
  self.assertTrue(c['compaction']['reserved']+16000+2048<32768)
