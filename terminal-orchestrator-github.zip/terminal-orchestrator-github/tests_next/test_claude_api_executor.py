import os,threading,unittest
from pathlib import Path
from unittest.mock import patch
from orchestrator.services import executors
from orchestrator.services.executor import ExecutionResult
class ClaudeApiExecutorTests(unittest.TestCase):
 def run_agent(self,kind,agent=None,planner=False):
  with patch.object(executors,'resolve_project',return_value=Path.cwd()),patch.object(executors,'executable',return_value='claude.exe'),patch.object(executors,'_save_result',side_effect=lambda r:r),patch.object(executors,'_run',return_value=ExecutionResult(returncode=0,stdout='{"type":"result","subtype":"success","is_error":false,"result":"answer"}')) as run:
   result=executors.run_agent('synthetic task',str(Path.cwd()),threading.Event(),kind=kind,agent=agent,memory=False,planner=planner)
  return result,run
 def profile(self):return {'provider':'api','url':'https://llm-router.org/v1','model':'deepseek-v4-pro','api_key':'TEST_PRIVATE_KEY'}
 def test_api_executor_uses_selected_model_and_stdin(self):
  old=os.environ.get('ANTHROPIC_API_KEY');result,run=self.run_agent('claude-api',self.profile())
  args=run.call_args.args[0];env=run.call_args.kwargs['env']
  self.assertTrue(result.ok);self.assertEqual(env['ANTHROPIC_MODEL'],'deepseek-v4-pro');self.assertNotEqual(env['ANTHROPIC_API_KEY'],'TEST_PRIVATE_KEY');self.assertTrue(env['ANTHROPIC_BASE_URL'].startswith('http://127.0.0.1:'))
  self.assertNotIn('TEST_PRIVATE_KEY',str(args));self.assertNotIn('--dangerously-skip-permissions',args);self.assertEqual(run.call_args.kwargs['input_text'],'synthetic task');self.assertEqual(os.environ.get('ANTHROPIC_API_KEY'),old)
 def test_native_does_not_interpret_metadata_as_api(self):
  with patch.dict(os.environ,{'ANTHROPIC_API_KEY':'native-sentinel'}):
   result,run=self.run_agent('claude',{'model':'Собственные настройки CLI'})
  self.assertTrue(result.ok);self.assertEqual(run.call_args.kwargs['env']['ANTHROPIC_API_KEY'],'native-sentinel')
 def test_missing_api_fails_without_native_fallback(self):
  result,run=self.run_agent('claude-api');self.assertFalse(result.ok);run.assert_not_called()
 def test_local_model_fails_without_native_fallback(self):
  result,run=self.run_agent('claude-api',{'provider':'ollama','model':'local'});self.assertFalse(result.ok);run.assert_not_called()
 def test_shared_model_and_executable_alias(self):
  self.assertTrue(executors.SPECS['claude-api'][1]);self.assertFalse(executors.SPECS['claude'][1])
  with patch('shutil.which',side_effect=lambda name:'claude.exe' if name=='claude.exe' else None):self.assertEqual(executors.executable('claude-api'),'claude.exe')
 def test_planner_has_no_tools_executor_does_not_disable_tools(self):
  _,run=self.run_agent('claude-api',self.profile(),planner=True)
  args=run.call_args.args[0];self.assertEqual(args[args.index('--tools')+1],'')
