import threading
import time
import unittest
from unittest.mock import patch
from orchestrator.services import access


class AccessApprovals(unittest.TestCase):
    def tearDown(self):
        access.deny_pending()

    def test_none_denies_read_and_process_without_request(self):
        with patch.object(access,'state',return_value={'mode':'none'}), patch.object(access,'request') as request:
            with self.assertRaises(ValueError):access.check_read('.')
            with self.assertRaises(ValueError):access.approve_execution(['python'],'.')
            request.assert_not_called()

    def test_folder_read_inside_is_free_outside_requires_request(self):
        from pathlib import Path
        folder=Path.cwd().resolve()
        with patch.object(access,'state',return_value={'mode':'folder','folder':str(folder)}), patch.object(access,'request') as request:
            access.check_read(folder/'child')
            request.assert_not_called()
            access.check_read(folder.parent)
            request.assert_called_once()

    def test_folder_process_requires_explicit_broad_launch_consent(self):
        with patch.object(access,'state',return_value={'mode':'folder'}), patch.object(access,'request') as request:
            access.approve_execution(['agent','secret argument'],'.')
            self.assertIn('не изолирован',request.call_args.args[1])
            self.assertNotIn('secret argument',request.call_args.args[1])

    def test_decision_is_one_shot_and_rejection_blocks(self):
        for allowed in (True,False):
            errors=[]
            def worker():
                try:access.request('Test','Test')
                except ValueError as e:errors.append(str(e))
            thread=threading.Thread(target=worker);thread.start()
            for _ in range(100):
                pending=access.requests()
                if pending:break
                time.sleep(.01)
            ident=pending[0]['id'];access.decide(ident,allowed);thread.join(2)
            self.assertFalse(thread.is_alive())
            self.assertEqual(bool(errors),not allowed)
            with self.assertRaises(ValueError):access.decide(ident,True)

    def test_cancellation_closes_request(self):
        cancelled=threading.Event();cancelled.set()
        with self.assertRaises(ValueError):access.request('Test','Test',cancelled)
        self.assertEqual(access.requests(),[])

    def test_full_access_skips_repeated_prompts(self):
        with patch.object(access,'state',return_value={'mode':'full'}),patch.object(access,'request') as request:
            access.check_read('.')
            access.check_execution()
            access.approve_execution(['agent'],'.')
            request.assert_not_called()

    def test_full_requires_confirmation(self):
        with self.assertRaises(ValueError):access.save({'mode':'full'})

    def test_opencode_adapter_reaches_runner(self):
        import sys
        from pathlib import Path
        from contextlib import contextmanager
        from orchestrator.services import executor
        @contextmanager
        def provider(profile):yield '{"provider":{"orchestrator-agent":{"options":{"baseURL":"http://127.0.0.1:1/v1","apiKey":"synthetic"}}}}'
        with patch.object(executor,'resolve_project',return_value=Path.cwd()),patch('shutil.which',side_effect=lambda name:None if name=='opencode.cmd' else sys.executable),patch('orchestrator.services.agent.agent_provider',provider),patch.object(executor,'_run',return_value=executor.ExecutionResult(returncode=0)) as run:
            result=executor.run_opencode('Synthetic test',agent={'model':'test'})
        self.assertTrue(result.ok)
        run.assert_called_once()
