import asyncio,json,threading,unittest,tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch,AsyncMock,Mock
from orchestrator.services import routing,access
from orchestrator.services.executor import ExecutionResult,resolve_project

class NoProjectTests(unittest.TestCase):
 def test_auto_without_project_uses_resolved_workdir_and_checks_artifacts(self):
  with tempfile.TemporaryDirectory() as folder:
   profile=dict(id='helper',kind='kimi',model='',device='cpu',enabled=True,fallback=False,category='general',priority=1,timeout=60,label='Helper')
   task=SimpleNamespace(project='',cancelled=threading.Event(),routing_config=dict(mode='auto',manager='brain',allow_cloud=True,profiles=[profile]))
   async def execute(command,task):
    self.assertEqual(command[2],folder)
    (Path(folder)/'out.txt').write_text('ok')
    return ExecutionResult(returncode=0)
   service=SimpleNamespace(agent_models=[],_execute_manual=AsyncMock(side_effect=execute),emit=Mock())
   command=('delegate',json.dumps(dict(profile='helper',category='general',task='write',expected_artifacts=[{'path':'out.txt'}])), '')
   with patch.object(routing,'resolve_project',return_value=Path(folder)),patch.object(routing.executors,'executable',return_value='kimi'),patch.object(access,'check_read',side_effect=lambda p:p),patch('orchestrator.services.executor._save_result',side_effect=lambda r:r):
    result=asyncio.run(routing.execute(service,command,task))
   self.assertTrue(result.ok,result.error)
   self.assertEqual(result.artifact_checks['status'],'passed')
   self.assertEqual(task.project,'')
 def test_no_access_still_rejected(self):
  with patch.object(access,'state',return_value={'mode':'none','folder':''}):
   with self.assertRaises(ValueError):resolve_project('')
 def test_sandbox_full_only_when_permanently_authorized(self):
  for mode in ['none','folder','ask','full']:
   with patch.object(access,'state',return_value={'mode':mode}):
    self.assertEqual(access.executor_sandbox(),'danger-full-access' if mode=='full' else 'workspace-write')
