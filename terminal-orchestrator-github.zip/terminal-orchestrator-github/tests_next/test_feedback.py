import unittest,threading,json,sys
from pathlib import Path
from unittest.mock import patch
from orchestrator.services import harness_brain,executors
from orchestrator.services.executor import ExecutionResult
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
import orchestra_client
class FeedbackTests(unittest.TestCase):
 def test_planner_failure_has_log_not_reasoning(self):
  r=ExecutionResult(returncode=1,stderr='dsh: reasoning: PRIVATE_REASONING',log_path='logs/example.json')
  text=harness_brain.planner_result(r)
  self.assertIn('example.json',text);self.assertIn('returncode=1',text);self.assertNotIn('PRIVATE_REASONING',text)
 def test_truncated_json_is_not_success(self):
  r=ExecutionResult(returncode=0,stdout='```json\n{"action":"delegate","task":"cut')
  with patch('orchestrator.services.executor._save_result'):
   self.assertTrue(harness_brain.planner_result(r).startswith('[ERR]'))
 def test_codex_task_is_stdin(self):
  with patch.object(executors,'resolve_project',return_value=Path.cwd()),patch.object(executors,'executable',return_value='codex.exe'),patch.object(executors,'_run',return_value=ExecutionResult(returncode=0)) as run:
   executors.run_agent('task with "quotes"',str(Path.cwd()),threading.Event(),kind='codex')
   cmd=run.call_args.args[0];self.assertLess(cmd.index('-a'),cmd.index('exec'));self.assertEqual(run.call_args.kwargs['input_text'],'task with "quotes"');self.assertEqual(cmd[-1],'-')
 def test_wait_does_not_accept_other_task(self):
  with patch.object(orchestra_client,'state',return_value={'task':{'id':'different','status':'done'}}),patch.object(orchestra_client,'emit'):
   self.assertEqual(orchestra_client.watch(1,'mine',1),3)
 def test_submit_uses_configured_brain_and_persists_task(self):
  import tempfile
  with tempfile.TemporaryDirectory() as folder:
   root=Path(folder);(root/'task.txt').write_text('test',encoding='utf8')
   boot={'models':[{'provider':'api','model':'a'},{'provider':'registry','model':'b'}],'default_model':0,'preferences':{'brain_settings':{'primary':'registry:b'}}}
   argv=['client','submit','--project',folder,'--task-file',str(root/'task.txt'),'--receipt',str(root/'receipt.json')]
   with patch.object(sys,'argv',argv),patch.object(orchestra_client,'request',side_effect=[{'id':9},boot,{'id':'task-9'}]) as call,patch.object(orchestra_client,'emit'):
    self.assertEqual(orchestra_client.main(),0)
    self.assertEqual(call.call_args.args[1]['model'],1)
    self.assertEqual(json.loads((root/'receipt.json').read_text())['task_id'],'task-9')
