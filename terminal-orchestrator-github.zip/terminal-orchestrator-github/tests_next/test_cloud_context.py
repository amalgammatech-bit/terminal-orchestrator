import unittest
from unittest.mock import patch
from orchestrator.services.connections import effective_input_budget
class FullContextTests(unittest.TestCase):
 def test_cloud_uses_window_not_legacy_budget(self):
  with patch('orchestrator.services.connections.SETTINGS.section',return_value={'cloud_full_context':True}):
   self.assertEqual(effective_input_budget({'context':1000000,'max_output_tokens':8192,'input_budget':16000}),987712)
 def test_manual_legacy_mode(self):
  with patch('orchestrator.services.connections.SETTINGS.section',return_value={'cloud_full_context':False}):
   self.assertEqual(effective_input_budget({'context':1000000,'max_output_tokens':8192,'input_budget':16000}),16000)
