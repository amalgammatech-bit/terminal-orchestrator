"""Project read policy and one-shot user approvals for external processes."""
import ctypes,json,os,threading,uuid
from pathlib import Path
from orchestrator.config import SETTINGS
_lock=threading.RLock()
_pending={}
def path():return SETTINGS.path('sessions_db').parent/'access.json'
def elevated():return bool(os.name=='nt' and ctypes.windll.shell32.IsUserAnAdmin())
def state():
 try:data=json.loads(path().read_text(encoding='utf-8'))
 except FileNotFoundError:data={'mode':'none','folder':''}
 if data.get('mode')=='computer':data['mode']='ask'
 if data.get('mode') not in ('none','ask','folder','full'):raise ValueError('Повреждена политика доступа')
 return {**data,'elevated':elevated(),'strict_execution_supported':False}
def save(data):
 mode=data.get('mode');folder=data.get('folder','')
 if mode=='computer':mode='ask'
 if mode not in ('none','ask','folder','full') or not isinstance(folder,str):raise ValueError('Некорректные права')
 if mode=='full' and data.get('confirmed') is not True:raise ValueError('Подтвердите постоянный доступ ко всему компьютеру')
 if mode=='folder':
  p=Path(folder)
  if not p.is_absolute() or not p.is_dir():raise ValueError('Выберите существующую абсолютную папку')
  folder=str(p.resolve())
 else:folder=''
 with _lock:
  target=path();target.parent.mkdir(parents=True,exist_ok=True);tmp=target.with_name(target.name+'.'+uuid.uuid4().hex+'.tmp')
  tmp.write_text(json.dumps({'mode':mode,'folder':folder}),encoding='utf-8');tmp.replace(target)
 return state()
def check_read(project):
 p=Path(project).resolve();s=state()
 if s['mode']=='none':raise ValueError('Доступ к проектам отключён. Выберите уровень доступа в чате.')
 if s['mode']=='ask':request('Чтение проекта',str(p))
 if s['mode']=='folder' and not p.is_relative_to(Path(s['folder']).resolve()):request('Чтение вне выбранной папки',str(p))
 return p
def check_execution():
 s=state()
 if s['mode']=='full':return
 if s['mode']=='none':raise ValueError('Доступ к компьютеру отключён')
 if s['mode']=='folder':raise ValueError('В режиме папки эта операция требует отдельного подтверждения запуска')
 request('Операция на компьютере','Действие получит права текущего пользователя Windows.')


def requests():
 with _lock:return [{k:v for k,v in row.items() if k not in ('event','allowed')} for row in _pending.values() if not row['event'].is_set()]


def decide(ident,allowed,always=False):
 if type(always) is not bool:raise ValueError('Некорректное постоянное разрешение')
 if always and not allowed:raise ValueError('Нельзя сохранить отклонённое разрешение')
 if type(allowed) is not bool:raise ValueError('Некорректное решение')
 with _lock:
  row=_pending.get(ident)
  if not row or row['event'].is_set():raise ValueError('Запрос уже закрыт')
  if always:save({'mode':'full','confirmed':True})
  row['allowed']=allowed;row['event'].set()
 return {'ok':True}


def request(title,detail,cancelled=None):
 ident=uuid.uuid4().hex
 row=dict(id=ident,title=title,detail=detail,event=threading.Event(),allowed=False)
 with _lock:_pending[ident]=row
 try:
  import time
  deadline=time.monotonic()+120
  while not row['event'].wait(.2):
   if cancelled and cancelled.is_set():raise ValueError('Действие остановлено')
   if time.monotonic()>=deadline:raise ValueError('Время ожидания разрешения истекло')
  if not row['allowed']:raise ValueError('Доступ отклонён пользователем')
 finally:
  with _lock:_pending.pop(ident,None)


def approve_execution(command,cwd,cancelled=None):
 s=state()
 if s['mode']=='full':return
 if s['mode']=='none':raise ValueError('Доступ к компьютеру отключён')
 program=Path(str(command[0])).name
 detail='Программа: '+program+'\nРабочая папка: '+str(cwd or '')+'\nВнешний процесс не изолирован папкой и может обращаться к другим файлам с правами текущего пользователя. Разрешение действует только на этот запуск, включая его дочерние процессы.'
 request('Разрешить запуск агента или команды?',detail,cancelled)


def deny_pending():
 with _lock:
  for row in _pending.values():
   row['allowed']=False;row['event'].set()


def executor_sandbox():
 return "danger-full-access" if state()["mode"]=="full" else "workspace-write"
