"""Bounded, read-only artifact checks. No model-authored code is executed."""
import hashlib,json
from pathlib import Path

def validate(specs):
    if not isinstance(specs,list) or len(specs)>20:raise ValueError('Ожидается до20 артефактов')
    for s in specs:
        if not isinstance(s,dict) or set(s)-{'path','format','required_keys','equals','changed','nonempty_keys'}:raise ValueError('Некорректный контракт артефакта')
        p=s.get('path')
        if not isinstance(p,str) or not p or Path(p).is_absolute() or '..' in Path(p).parts:raise ValueError('Артефакт должен быть относительным путём внутри проекта')
        if s.get('format','file') not in ('file','json'):raise ValueError('Неизвестный формат артефакта')
        if type(s.get('changed',True)) is not bool:raise ValueError('changed должен быть boolean')
        keys=s.get('required_keys',[]);eq=s.get('equals',{})
        nonempty=s.get('nonempty_keys',[])
        if not isinstance(nonempty,list) or len(nonempty)>100 or any(not isinstance(k,str) for k in nonempty):raise ValueError('Некорректные непустые поля')
        if not isinstance(keys,list) or len(keys)>100 or any(not isinstance(k,str) for k in keys) or not isinstance(eq,dict) or len(eq)>100:raise ValueError('Некорректная схема артефакта')
    return specs

def read(root,s):
    root=Path(root).resolve();path=(root/s['path']).resolve()
    if not path.is_relative_to(root):raise ValueError('Артефакт вышел за пределы проекта')
    if not path.is_file():raise ValueError('Файл отсутствует: '+s['path'])
    if not 0<path.stat().st_size<=10000000:raise ValueError('Файл пуст или превышает10MB: '+s['path'])
    from orchestrator.services.access import check_read
    check_read(path)
    with path.open('rb') as stream: raw=stream.read(10000001)
    if len(raw)>10000000:raise ValueError('Артефакт превышает10MB')
    return raw

def snapshot(root,specs):
    validate(specs);out={}
    for s in specs:
        # Validate containment even for absent files before the executor runs.
        if not (Path(root).resolve()/s['path']).resolve().is_relative_to(Path(root).resolve()):raise ValueError('Артефакт вне проекта')
        try:out[s['path']]=hashlib.sha256(read(root,s)).hexdigest()
        except (ValueError,OSError):out[s['path']]=None
    return out

def verify(root,specs,before=None):
    validate(specs);rows=[]
    for s in specs:
        raw=read(root,s);digest=hashlib.sha256(raw).hexdigest()
        if before is not None and s.get('changed',True) and before.get(s['path'])==digest:raise ValueError('Артефакт не изменился: '+s['path'])
        if s.get('format')=='json':
            obj=json.loads(raw.decode('utf-8-sig'))
            if not isinstance(obj,dict):raise ValueError('Ожидается JSON-объект: '+s['path'])
            for key in s.get('required_keys',[]):
                if key not in obj or obj[key] is None:raise ValueError('Отсутствует поле: '+key)
            for key in s.get('nonempty_keys',[]):
                if key not in obj or not obj[key]:raise ValueError('Пустое поле: '+key)
            for key,value in s.get('equals',{}).items():
                if key not in obj or type(obj[key]) is not type(value) or obj[key]!=value:raise ValueError('Не совпадает поле: '+key)
        rows.append({'path':s['path'],'bytes':len(raw),'sha256':digest})
    return rows
