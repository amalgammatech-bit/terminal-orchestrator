"""Owner-configured CLI adapters. argv and stdin only; never shell templates."""
import json,os,re,shutil,threading,uuid
from pathlib import Path
from orchestrator.config import SETTINGS
_lock=threading.RLock()

def path():return SETTINGS.path('sessions_db').parent/'custom-agents.json'
def validate(row):
 if not isinstance(row,dict):raise ValueError('Ожидаются настройки агента')
 result={k:row.get(k,'') for k in ('id','label','command','instructions')}
 if not result['id']:result['id']='custom-'+uuid.uuid4().hex
 if not isinstance(result['id'],str) or not re.fullmatch(r'custom-[a-f0-9]{32}',result['id']):raise ValueError('Некорректный ID агента')
 for key,limit in [('label',100),('command',2000),('instructions',4000)]:
  value=result[key]
  if not isinstance(value,str) or len(value)>limit or (key!='instructions' and (not value.strip() or any(ord(c)<32 for c in value))):raise ValueError('Проверьте название, программу и инструкцию')
 result['label']=result['label'].strip();result['command']=result['command'].strip()
 args=row.get('args',[]);stdin=row.get('stdin',True)
 if type(stdin) is not bool or not isinstance(args,list) or len(args)>100 or any(not isinstance(a,str) or len(a)>4000 or '\x00' in a for a in args):raise ValueError('Аргументы должны быть JSON-массивом строк')
 if not stdin and not any('{task}' in a for a in args):raise ValueError('Добавьте {task} в аргументы или включите передачу через stdin')
 result.update(args=args,stdin=stdin)
 return result

def rows():
 try:data=json.loads(path().read_text(encoding='utf-8'))
 except FileNotFoundError:return []
 if not isinstance(data,list) or len(data)>30:raise ValueError('Повреждён список агентов')
 result=[validate(r) for r in data]
 if len({r['id'] for r in result})!=len(result):raise ValueError('Повторные ID агентов')
 return result

def get(ident):return next((r for r in rows() if r['id']==ident),None)
def executable(row):
 command=row['command'];p=Path(command)
 return str(p) if p.is_absolute() and p.is_file() else shutil.which(command)

def save(data):
 row=validate(data)
 with _lock:
  items=rows();old=next((i for i,r in enumerate(items) if r['id']==row['id']),None)
  if old is None:items.append(row)
  else:items[old]=row
  if len(items)>30:raise ValueError('Можно добавить до 30 агентов')
  write(items)
 return row

def write(items):
 target=path();target.parent.mkdir(parents=True,exist_ok=True)
 temp=target.with_name(target.name+'.'+uuid.uuid4().hex+'.tmp')
 temp.write_text(json.dumps(items,ensure_ascii=False,indent=2),encoding='utf-8');temp.replace(target)

def delete(ident):
 with _lock:
  items=rows()
  if not any(r['id']==ident for r in items):raise ValueError('Агент не найден')
  write([r for r in items if r['id']!=ident])

def run(row,task,project,cancelled,model,timeout):
 from orchestrator.services.executor import resolve_project,_run,_save_result,ExecutionResult
 try:
  if not isinstance(task,str) or not task.strip():raise ValueError('Не указана задача')
  if not isinstance(model,str) or len(model)>200 or any(ord(c)<32 for c in model):raise ValueError('Некорректная модель')
  cwd=resolve_project(project);command=executable(row)
  if not command:raise ValueError('Программа агента не найдена: '+row['command'])
  prompt=(row['instructions']+'\n\n' if row['instructions'] else '')+task
  values={'{task}':prompt,'{model}':model,'{project}':str(cwd)}
  # Single substitution: user text containing placeholders is never re-expanded.
  args=[re.sub(r'\{(?:task|model|project)\}',lambda m:values[m.group()],a) for a in row['args']]
  return _run([command,*args],timeout or 300,cancelled,cwd=cwd,input_text=prompt if row['stdin'] else None)
 except (ValueError,OSError) as exc:return _save_result(ExecutionResult(error=str(exc)))


def hidden_path():return SETTINGS.path('sessions_db').parent/'agent-catalog.json'
def hidden():
 try:items=json.loads(hidden_path().read_text(encoding='utf-8'))
 except FileNotFoundError:return []
 if not isinstance(items,list) or any(not isinstance(i,str) for i in items):raise ValueError('Повреждены настройки каталога агентов')
 return items

def set_builtin(ident,removed):
 from orchestrator.services.executors import SPECS
 if not isinstance(ident,str) or ident not in SPECS or ident=='none' or ident.startswith('custom-'):raise ValueError('Неизвестный встроенный адаптер')
 with _lock:
  items=set(hidden())
  if removed:items.add(ident)
  else:items.discard(ident)
  target=hidden_path();target.parent.mkdir(parents=True,exist_ok=True);temp=target.with_name(target.name+'.'+uuid.uuid4().hex+'.tmp')
  temp.write_text(json.dumps(sorted(items)),encoding='utf-8');temp.replace(target)

def listing():
 from orchestrator.services import executors
 removed=hidden();builtins=[]
 for ident,(label,shared,note) in executors.SPECS.items():
  if ident=='none' or ident.startswith('custom-'):continue
  command=executors.executable(ident,include_removed=True)
  builtins.append(dict(id=ident,label=label,command=command or '',available=bool(command),builtin=True,removed=ident in removed,note=note))
 return builtins+[dict(row,available=bool(executable(row)),builtin=False,removed=False) for row in rows()]
