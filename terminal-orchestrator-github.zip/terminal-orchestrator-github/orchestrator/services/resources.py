"""Cached hardware samples; collection never blocks chat requests."""
import base64
import copy
import json
import os
import subprocess
import threading
import time
import urllib.request
from pathlib import Path
import psutil

from orchestrator.config import SETTINGS

REMOTE = SETTINGS.data.get('resources', {})
DESKTOP_URL = REMOTE.get('remote_url', '')
REMOTE_SCRIPT = r"""
$ErrorActionPreference = 'Stop'
$cpu = (Get-CimInstance Win32_Processor | Measure-Object LoadPercentage -Average).Average
$mem = Get-CimInstance Win32_OperatingSystem
$gpu = @()
try {
    $lines = & nvidia-smi --query-gpu=name,utilization.gpu,memory.used,memory.total --format=csv,noheader,nounits 2>$null
    foreach ($line in $lines) {
        $p = $line -split ','
        if ($p.Length -eq 4) {
            $gpu += @{name=$p[0].Trim();percent=[double]$p[1];used_bytes=[double]$p[2]*1MB;total_bytes=[double]$p[3]*1MB}
        }
    }
} catch {}
@{cpu_percent=$cpu;ram_used_bytes=([double]$mem.TotalVisibleMemorySize-[double]$mem.FreePhysicalMemory)*1KB;ram_total_bytes=[double]$mem.TotalVisibleMemorySize*1KB;gpus=@($gpu)} | ConvertTo-Json -Compress -Depth 4
"""

def run(command, timeout):
    return subprocess.run(command, capture_output=True, text=True, encoding='utf-8', errors='replace',
                          timeout=timeout, check=True,
                          creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0)).stdout


def gpu_rows(output):
    result=[]
    for line in output.splitlines():
        parts=[v.strip() for v in line.split(',')]
        if len(parts)!=4:
            continue
        try:
            result.append({'name':parts[0], 'percent':float(parts[1]),
                           'used_bytes':float(parts[2])*1024**2, 'total_bytes':float(parts[3])*1024**2})
        except ValueError:
            continue
    return result


def local_sample():
    memory=psutil.virtual_memory()
    result={'cpu_percent':psutil.cpu_percent(interval=.25), 'ram_used_bytes':memory.total-memory.available,
            'ram_total_bytes':memory.total, 'gpus':[]}
    try:
        result['gpus']=gpu_rows(run(['nvidia-smi','--query-gpu=name,utilization.gpu,memory.used,memory.total',
                                    '--format=csv,noheader,nounits'],3))
    except (OSError,subprocess.SubprocessError):
        pass
    return result


def desktop_sample():
    ssh=Path(os.environ.get('WINDIR','C:/Windows'))/'System32/OpenSSH/ssh.exe'
    encoded=base64.b64encode(REMOTE_SCRIPT.encode('utf-16-le')).decode('ascii')
    command=[str(ssh)]
    if REMOTE.get('ssh_config'):
        command += ['-F', REMOTE['ssh_config']]
    command += ['-o','BatchMode=yes','-o','ConnectTimeout=4',REMOTE.get('ssh_host','desktop'),
                'powershell -NoProfile -NonInteractive -EncodedCommand '+encoded]
    output=run(command,10)
    result=json.loads(output.strip().lstrip('\ufeff'))
    if not isinstance(result,dict) or 'ram_total_bytes' not in result:
        raise ValueError('Invalid hardware sample')
    return result


def loaded_models(url):
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(url+'/api/ps',timeout=3) as response:
        data=json.load(response)
    return [{'name':m.get('name',''), 'size_bytes':m.get('size',0), 'vram_bytes':m.get('size_vram'),
             'device':'cpu' if m.get('size_vram')==0 else 'gpu' if m.get('size_vram') is not None else 'unknown'}
            for m in data.get('models',[])]


class ResourceMonitor:
    def __init__(self, collectors=None, model_reader=loaded_models):
        self.collectors=collectors if collectors is not None else [('local','Этот компьютер',SETTINGS.provider('ollama')['url'],local_sample)]
        if collectors is None and DESKTOP_URL:
            self.collectors.append(('desktop',REMOTE.get('remote_name','Удалённый компьютер'),DESKTOP_URL,desktop_sample))
        self.model_reader=model_reader
        self.lock=threading.Lock()
        self.stopped=threading.Event()
        self.thread=None
        self.values=[{'id':key,'name':name,'status':'loading'} for key,name,url,collector in self.collectors]

    def snapshot(self):
        with self.lock:
            if self.thread is None and not self.stopped.is_set():
                self.thread=threading.Thread(target=self._loop,daemon=True)
                self.thread.start()
            return copy.deepcopy(self.values)

    def _loop(self):
        while not self.stopped.is_set():
            for index,(key,name,url,collector) in enumerate(self.collectors):
                if self.stopped.is_set():
                    return
                value={'id':key,'name':name,'status':'ok','sampled_at':time.time()}
                try:
                    value.update(collector())
                except Exception:
                    value.update(status='unavailable',error='Нет связи или недоступны датчики')
                try:
                    value['models']=self.model_reader(url)
                    value['ollama_online']=True
                except Exception:
                    value.update(models=[],ollama_online=False)
                with self.lock:
                    self.values[index]=value
            if self.stopped.wait(5):
                return

    def close(self):
        self.stopped.set()
