"""Project-scoped verified recipes. Model output never promotes arbitrary instructions."""
import hashlib,json,os,threading,time,uuid
from pathlib import Path
from orchestrator.config import SETTINGS
_LOCK=threading.RLock()
RECIPE="For exact UTF-8 bytes: use Python pathlib.Path.write_bytes(expected), then assert read_bytes()==expected. Do not use PowerShell Set-Content/echo/redirection for exact BOM/newline requirements. Compute size and SHA256 in code; never guess them. Follow the current task's permitted paths."
def folder(project):
 identity=str(Path(project).resolve());identity=identity.casefold() if os.name=='nt' else identity
 return SETTINGS.path('sessions_db').parent/'skills'/hashlib.sha256(identity.encode()).hexdigest()[:24]
def catalog(project):
 try:
  rows=json.loads((folder(project)/'catalog.json').read_text(encoding='utf-8'))
  if not isinstance(rows,list) or any(not isinstance(row,dict) for row in rows):raise ValueError('Invalid project skill catalog')
  return rows
 except FileNotFoundError:return []
def learn_exact(project,artifact,expected):
 root=Path(project).resolve();p=Path(artifact).resolve()
 if not p.is_relative_to(root):raise ValueError('Evidence must be inside the project')
 if not isinstance(expected,bytes) or p.read_bytes()!=expected:raise ValueError('Independent byte verification failed; skill not saved')
 record={'id':'exact-utf8-bytes','status':'verified','recipe':RECIPE,'verified_at':time.time(),'evidence':{'file':str(p.relative_to(root)),'sha256':hashlib.sha256(expected).hexdigest(),'bytes':len(expected)},'scope':'recipe only; not proof of general agent reliability'}
 with _LOCK:
  rows=[x for x in catalog(project) if x.get('id')!=record['id']]+[record]
  dest=folder(project);dest.mkdir(parents=True,exist_ok=True)
  tmp=dest/(uuid.uuid4().hex+'.tmp');tmp.write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8');tmp.replace(dest/'catalog.json')
 return record
def instructions(project):
 rows=catalog(project)
 return '\n\nProject verified recipes (use only when relevant; current task restrictions take precedence):\n'+'\n'.join(r['recipe'] for r in rows if r.get('status')=='verified' and r.get('recipe')==RECIPE) if rows else ''
