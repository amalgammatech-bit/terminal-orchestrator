"""Harness headless planner; terminal retains history, delegation and access policy."""
import json
import os
import shutil
import uuid
from pathlib import Path
from orchestrator.services import executors
from orchestrator.services.executor import _run, ExecutionResult, resolve_project


def executable():
    command = shutil.which('dsh.cmd') or shutil.which('dsh')
    desktop = Path(os.environ.get('LOCALAPPDATA', '')) / 'Programs/DeepSeek Harness/resources/runtime/cli/bin/dsh.cmd'
    return command or (str(desktop) if desktop.is_file() else None)


def output_budget(profile):
    from orchestrator.config import SETTINGS
    value=profile.get("harness_max_output_tokens",SETTINGS.section("orchestration").get("harness_output_tokens",8192))
    if type(value) is not int or value<256:raise ValueError("Harness output budget must be an integer >=256")
    return min(value,max(256,profile.get("context",32768)//2))


def planner_patch(profile, url):
    route = dict(api='openai-completions', baseURL=url, apiKeyEnv='ORCHESTRA_HARNESS_KEY',
                 models=[dict(id=profile['model'], contextWindow=profile.get('context', 32768),
                              maxTokens=output_budget(profile))])
    rows = [dict(id='sandbox-policy',config=dict(mode='read-only')),
            dict(id='approval',config=dict(policy='never')),
            dict(id='permission',config=dict(defaultPreset='orchestra-planner', presets={'orchestra-planner':dict(sandbox='read-only',approval='never',name='Planner',description='Delegation through terminal only')})),
            dict(id='llm-pi-ai', config=dict(providers={'orchestra': route})),
            dict(id='agent-default-model', config=dict(provider='orchestra', model=profile['model']))]
    # Planning has no direct project execution. Commands pass through routing.py.
    for ident in ('tool-plugin-manager', 'tool-bash', 'tool-pwsh', 'tool-jobs', 'tool-fs',
                  'tool-fs-search', 'tool-skill', 'tool-subagent-control', 'tool-subagent',
                  'tool-subagent-fork', 'tool-workflow', 'tool-web', 'tool-todo', 'tool-goal'):
        rows.append(dict(id=ident, disabled=True))
    return rows


def _run_harness(prompt, project, profile, cancelled, timeout=900, direct=False):
    command = executable()
    if not command:
        return ExecutionResult(error='Harness не найден. Установите DeepSeek Harness или dsh в PATH.')
    path = resolve_project(project)
    home = executors.runtime() / ('harness-direct' if direct else 'harness-brain') / uuid.uuid4().hex
    home.mkdir(parents=True, exist_ok=True)
    patch = home / ('planner-' + uuid.uuid4().hex + '.json')
    try:
        with executors.connection(profile) as (url, key):
            rows=planner_patch(profile,url)
            if direct:
                rows=[r for r in rows if r['id'] in ('llm-pi-ai','agent-default-model')]
                from orchestrator.services.access import executor_sandbox
                rows.append(dict(id='sandbox-policy',config=dict(mode=executor_sandbox(),workspaceRoot=str(path))))
            patch.write_text(json.dumps(rows, ensure_ascii=False), encoding='utf-8')
            env = os.environ.copy()
            # Separate from the interactive Harness account/profile and personal sessions.
            env.update(DSH_HOME=str(home.resolve()), ORCHESTRA_HARNESS_KEY=key or 'local',
                       DSH_TELEMETRY_DISABLED='1', NO_PROXY='*')
            return _run([command, '--profile', 'headless', '--patch', str(patch.resolve()),
                         '-'],
                        timeout, cancelled, cwd=path, env=env, input_text=prompt+('\nIf a tool reports SetNamedSecurityInfoW/grantWrite/Win32 5, stop and report the exact failure. Do not change permissions, switch sandbox, delegate further, or repeatedly retry that failure.' if direct else ''))
    finally:
        patch.unlink(missing_ok=True)


def planner_result(result, label="Harness"):
    """Return validated planner output or actionable diagnostics without reasoning leakage."""
    from orchestrator.utils.parser import parse_command
    from orchestrator.services.executor import _save_result
    if result.ok:
        try:
            command = parse_command(result.stdout)
            if command is None and ('```json' in result.stdout.lower() or '"action"' in result.stdout):
                raise ValueError("Незавершённая JSON-команда планировщика; исполнение не запускалось")
            if not result.stdout.strip():
                raise ValueError('Пустой ответ планировщика')
            return result.stdout.strip()
        except ValueError as exc:
            result.error = str(exc)
            _save_result(result)
    reason = result.error or ('Истекло время ожидания' if result.timed_out else
                             'CLI завершился с ненулевым кодом; точная причина в полном журнале')
    return ('[ERR] '+label+': ' + reason + '; returncode=' + str(result.returncode) +
            '; timed_out=' + str(result.timed_out) + '; cancelled=' + str(result.cancelled) +
            '; журнал=' + (str(result.log_path) or 'не сохранён: ' + result.log_error))


def run(prompt, project, profile, cancelled, timeout=900, direct=False):
    from orchestrator.services.executor import _save_result
    if profile.get('provider') not in ('api','ollama'):
        return _save_result(ExecutionResult(error='Harness: явно укажите provider=api или provider=ollama'))
    if profile.get('provider')!='api':
        return _run_harness(prompt,project,profile,cancelled,timeout,direct)
    from orchestrator.services.provider_observer import observe
    with observe(profile, expected_prompt=prompt) as (routed,records):
        result=_run_harness(prompt,project,routed,cancelled,timeout,direct)
    result.provider_diagnostics=records
    if not result.ok and any('length' in row.get('finish_reasons',[]) and (row.get('max_tokens') or 0)>1 for row in records):
        result.error='Провайдер исчерпал выходной бюджет Harness; ответ или вызов инструмента оборван (finish_reason=length). Проверьте частичные файлы перед повтором.'
    if not result.ok and not result.error and 'SetNamedSecurityInfoW' in result.stderr:
        result.error='Harness сообщил об ошибке подготовки Windows-песочницы (SetNamedSecurityInfoW). Не повторяйте задачу до проверки прав папки; полный журнал сохранён.'
    return _save_result(result)

