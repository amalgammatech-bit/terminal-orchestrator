"""Bounded OpenAI-compatible relay for Hermes; upstream key stays in this process."""
import hmac
import json
import secrets
import threading
import urllib.request
from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from orchestrator.services.context import tokens
from orchestrator.services.llm.compatible import NoRedirect

@contextmanager
def api_connection(profile):
    token=secrets.token_urlsafe(24)
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def reply(self,status,value):
            body=json.dumps(value,ensure_ascii=False).encode('utf-8')
            self.send_response(status);self.send_header('Content-Type','application/json')
            self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
        def authorized(self):
            return hmac.compare_digest(self.headers.get('Authorization',''),'Bearer '+token)
        def do_GET(self):
            if not self.authorized():self.reply(403,{'error':{'message':'Нет доступа'}});return
            if self.path=='/v1/models':
                self.reply(200,{'object':'list','data':[{'id':profile['model'],'object':'model','context_length':profile['context']}]})
            else:self.reply(404,{'error':{'message':'Не найдено'}})
        def do_POST(self):
            try:
                self.connection.settimeout(15)
                if not self.authorized() or self.path!='/v1/chat/completions':
                    self.reply(403,{'error':{'message':'Нет доступа'}});return
                length=int(self.headers.get('Content-Length','0'))
                if not 0<length<=2000000:self.reply(413,{'error':{'message':'Слишком большой запрос'}});return
                data=json.loads(self.rfile.read(length))
                if data.get('model')!=profile['model']:self.reply(400,{'error':{'message':'Модель не совпадает с настройками'}});return
                if tokens(json.dumps({'messages':data.get('messages',[]),'tools':data.get('tools',[])},ensure_ascii=False))>profile['input_budget']:
                    self.reply(413,{'error':{'message':'Превышен бюджет входа API агента. Сожмите историю или увеличьте бюджет.'}});return
                data.pop('max_completion_tokens',None)
                data['max_tokens']=min(data.get('max_tokens') or profile['max_output_tokens'],profile['max_output_tokens'])
                headers={'Content-Type':'application/json'}
                if profile.get('api_key'):headers['Authorization']='Bearer '+profile['api_key']
                request=urllib.request.Request(profile['url'].rstrip('/')+'/chat/completions',data=json.dumps(data,ensure_ascii=False).encode('utf-8'),headers=headers)
                with urllib.request.build_opener(NoRedirect(),urllib.request.ProxyHandler({})).open(request,timeout=180) as response:
                    body=response.read(12000001)
                    if len(body)>12000000:raise ValueError('Слишком большой ответ')
                    self.send_response(200);self.send_header('Content-Type',response.headers.get('Content-Type','application/json'))
                    self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
            except Exception:
                self.reply(502,{'error':{'message':'Ошибка подключения API агента. Проверьте ключ, модель и лимиты.'}})
    server=ThreadingHTTPServer(('127.0.0.1',0),Handler);server.daemon_threads=True
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    try:yield f'http://127.0.0.1:{server.server_port}/v1',token
    finally:server.shutdown();server.server_close();thread.join(2)
