"""Per-call OpenAI relay recording only usage and finish metadata, never prompts/keys."""
import json,secrets,hmac,threading,urllib.request,urllib.error,hashlib
from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
def request_fingerprint(request, expected_prompt=None):
 """Lengths and digests only; no user text, tools, keys or reasoning are stored.
 Exact containment is evidence of delivery; false alone does not prove loss
 because a CLI may transform or compact the prompt.
 """
 messages=request.get('messages',[])
 if not isinstance(messages,list):messages=[]
 rows=[];texts=[]
 for message in messages:
  if not isinstance(message,dict):continue
  content=message.get('content','')
  if isinstance(content,list):
   content='\n'.join(p.get('text','') for p in content if isinstance(p,dict) and isinstance(p.get('text'),str))
  if not isinstance(content,str):content=''
  texts.append(content)
  role=message.get('role')
  rows.append({'role':role if role in ('system','developer','user','assistant','tool') else 'other',
               'chars':len(content),'sha256':hashlib.sha256(content.encode('utf-8')).hexdigest()})
 result={'messages':rows,'message_count':len(rows),'text_chars':sum(len(t) for t in texts)}
 if expected_prompt is not None:
  result.update(expected_prompt_chars=len(expected_prompt),
   expected_prompt_sha256=hashlib.sha256(expected_prompt.encode('utf-8')).hexdigest(),
   expected_prompt_present=bool(expected_prompt) and any(expected_prompt in t for t in texts))
 return result

@contextmanager
def observe(profile, expected_prompt=None):
 records=[];token=secrets.token_urlsafe(32)
 class Handler(BaseHTTPRequestHandler):
  def log_message(self,*args):pass
  def do_POST(self):
   if self.path!='/v1/chat/completions' or not hmac.compare_digest(self.headers.get('Authorization',''),'Bearer '+token):self.send_error(403);return
   length=int(self.headers.get('Content-Length','0'))
   if not 0<length<=8000000:self.send_error(413);return
   data=self.rfile.read(length);request=json.loads(data)
   row={'max_tokens':request.get('max_tokens',request.get('max_completion_tokens')),'finish_reasons':[],'usage':{}};row['request_fingerprint']=request_fingerprint(request,expected_prompt);records.append(row)
   req=urllib.request.Request(profile['url'].rstrip('/')+'/chat/completions',data=data,headers={'Authorization':'Bearer '+profile.get('api_key',''),'Content-Type':'application/json'})
   try:
    with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(req,timeout=900) as response:
     row['http_status']=response.status;self.send_response(response.status);self.send_header('Content-Type',response.headers.get('Content-Type','application/json'));self.end_headers()
     def note(value):
      if value.get('usage'):row['usage']=value['usage']
      for choice in value.get('choices',[]):
       reason=choice.get('finish_reason')
       if reason and reason not in row['finish_reasons']:row['finish_reasons'].append(reason)
     if request.get('stream'):
      for line in response:
       if line.startswith(b'data: '):
        try:note(json.loads(line[6:]))
        except (ValueError,TypeError):pass
       self.wfile.write(line);self.wfile.flush()
     else:
      body=response.read();note(json.loads(body));self.wfile.write(body)
   except urllib.error.HTTPError as exc:
    row['http_status']=exc.code;self.send_error(exc.code,'Upstream API rejected request')
   except (OSError,ValueError) as exc:
    row['transport_error']=type(exc).__name__
 server=ThreadingHTTPServer(('127.0.0.1',0),Handler);server.daemon_threads=True
 thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
 try:yield {**profile,'url':f'http://127.0.0.1:{server.server_port}/v1','api_key':token},records
 finally:server.shutdown();server.server_close();thread.join(2)
