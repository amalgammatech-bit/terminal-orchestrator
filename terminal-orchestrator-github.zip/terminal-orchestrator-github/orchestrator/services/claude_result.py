"""Normalize Claude print JSON without treating CLI exit0 as an answer."""
import json
from orchestrator.services.executor import _save_result

def normalize(result):
    result.protocol_stdout=result.stdout
    result.stdout=''
    if result.cancelled or result.timed_out:return _save_result(result)
    try:
        data=json.loads(result.protocol_stdout)
        if not isinstance(data,dict) or data.get('type')!='result':raise ValueError('Missing result envelope')
    except (ValueError,TypeError):
        result.error=result.error or 'Claude Code: отсутствует корректный JSON result; полный протокол в журнале'
        return _save_result(result)
    result.claude_diagnostics={k:data[k] for k in ('type','subtype','is_error','stop_reason','terminal_reason','api_error_status','usage','modelUsage','num_turns','duration_ms','duration_api_ms','total_cost_usd') if k in data}
    text=data.get('result')
    if isinstance(text,str):result.stdout=text
    if data.get('is_error') is True or data.get('subtype')!='success':
        result.error='Claude Code: result завершён с ошибкой (subtype='+str(data.get('subtype','unknown'))+'; api_error_status='+str(data.get('api_error_status','не передан'))+')'
    elif not isinstance(text,str) or not text.strip():
        result.error='Claude Code: JSON result не содержит итогового текста; stop_reason='+str(data.get('stop_reason','не передан'))+'; расход токенов и полный протокол в журнале'
    elif data.get('stop_reason') in ('max_tokens','model_context_window_exceeded'):
        result.error='Claude Code: ответ прерван, stop_reason='+data['stop_reason']
    return _save_result(result)
