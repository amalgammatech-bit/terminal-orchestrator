import os
import sys
import subprocess
import time
import json
import uuid
from dataclasses import dataclass, field
from pathlib import Path

from orchestrator.config import SETTINGS

KIMI_TO_OPENCODE = SETTINGS.script("executor")
REVIEW_GROQ = SETTINGS.script("reviewer")


@dataclass
class ExecutionResult:
    stdout: str = ""
    stderr: str = ""
    returncode: int | None = None
    timed_out: bool = False
    cancelled: bool = False
    error: str = ""
    log_path: str = ""
    log_error: str = ""
    provider_diagnostics: list = field(default_factory=list)
    tool_warnings: list = field(default_factory=list)
    artifact_checks: dict = field(default_factory=dict)
    claude_diagnostics: dict = field(default_factory=dict)
    protocol_stdout: str = ""
    anthropic_diagnostics: list = field(default_factory=list)

    @property
    def ok(self):
        return self.returncode == 0 and not (self.timed_out or self.cancelled or self.error)

    def summary(self, limit=2000):
        state = "Агент завершился; результат требует проверки" if self.ok else "Ошибка"
        if self.cancelled:
            state = "Остановлено"
        elif self.timed_out:
            state = "Превышено время ожидания"
        warning = ("ВНИМАНИЕ: " + "; ".join(self.tool_warnings) + "\nОшибки могли быть исправлены позже; требуется независимая проверка результата.\n") if self.tool_warnings else ""
        output = self.stdout + ("\n[stderr]\n" + self.stderr if self.stderr else "")
        if len(output)>limit:
            output=output[:limit//3]+"\n[Середина вывода в полном журнале]\n"+output[-(limit-limit//3):]
        return f"{state}; код: {self.returncode}\n{warning}{self.error}\n{output}\nЖурнал: {self.log_path or 'не сохранён'}{(' — ' + self.log_error) if self.log_error else ''}"


def _save_result(result):
    try:
        logs = SETTINGS.path("logs_dir")
        logs.mkdir(parents=True, exist_ok=True)
        path = logs / f"{uuid.uuid4().hex}.json"
        result.log_path = str(path)
        path.write_text(json.dumps(vars(result), ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError as exc:
        result.log_path = ""
        result.log_error = str(exc)
    return result


def _terminate(process):
    if process.poll() is not None:
        return
    if os.name == "nt":
        try:
            subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"],
                           capture_output=True, timeout=15)
        except (OSError, subprocess.TimeoutExpired):
            process.kill()
    else:
        process.kill()
    if process.poll() is None:
        process.kill()


def _run(cmd, timeout, cancel_event=None, cwd=None, env=None, input_text=None):
    from orchestrator.services.access import approve_execution
    try: approve_execution(cmd, cwd, cancel_event)
    except ValueError as exc: return _save_result(ExecutionResult(error=str(exc)))
    if cancel_event and cancel_event.is_set():
        return _save_result(ExecutionResult(cancelled=True))
    process = None
    try:
        process = subprocess.Popen(cmd, creationflags=subprocess.CREATE_NO_WINDOW if os.name=="nt" else 0, stdin=subprocess.PIPE if input_text is not None else subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                   text=True, encoding="utf-8", errors="replace", cwd=str(cwd or SETTINGS.path("projects_root")), env=env)
        stdout = stderr = ""
        deadline = time.monotonic() + timeout
        reason = None
        cancelled = False
        timed_out = False
        while True:
            if cancel_event and cancel_event.is_set():
                reason = "Выполнение остановлено"
                cancelled = True
            elif time.monotonic() >= deadline:
                reason = f"Превышено время ожидания ({timeout} с)"
                timed_out = True
            if reason:
                _terminate(process)
                try:
                    stdout, stderr = process.communicate(timeout=5)
                except subprocess.TimeoutExpired as exc:
                    stdout = exc.output or b""
                    stderr = exc.stderr or b""
                    stdout = stdout.decode("utf-8", errors="replace") if isinstance(stdout, bytes) else stdout
                    stderr = stderr.decode("utf-8", errors="replace") if isinstance(stderr, bytes) else stderr
                    process.stdout.close()
                    process.stderr.close()
                break
            try:
                stdout, stderr = process.communicate(input=input_text, timeout=0.2)
                input_text = None
                break
            except subprocess.TimeoutExpired:
                input_text = None
                continue
        return _save_result(ExecutionResult(stdout=stdout or "", stderr=stderr or "",
                           returncode=process.returncode,
                           cancelled=cancelled, timed_out=timed_out))
    except Exception as exc:
        if process is not None and process.poll() is None:
            _terminate(process)
            try:
                process.communicate(timeout=5)
            except subprocess.TimeoutExpired:
                process.stdout.close()
                process.stderr.close()
        return _save_result(ExecutionResult(error=str(exc)))


def resolve_project(project=""):
    from orchestrator.services.access import check_read, state
    policy=state()
    root=Path(policy['folder']).resolve() if policy['mode']=='folder' else SETTINGS.path('projects_root').resolve()
    path=(root/project).resolve() if project else root
    if not path.is_dir():raise ValueError('Проект должен быть существующей папкой')
    return check_read(path)



def run_opencode(task, project="", cancel_event=None, agent=None, timeout=None, memory=True):
    import shutil
    try:
        if not isinstance(task,str) or not task.strip():raise ValueError('Не указана задача')
        path=resolve_project(project)
        if os.name == 'nt':
            task = ("Среда исполнения: Windows. Команды инструмента выполняются в PowerShell. "
                    "Не используй bash heredoc (python - <<), Bash-синтаксис и вложенные powershell/pwsh -Command. "
                    "Для многострочного Python создай файл штатным инструментом записи OpenCode и выполни python file.py. "
                    "Не подставляй код через несколько оболочек. При ParserError исправь способ запуска, не повторяй ту же команду. "
                    "Если проверка не выполнена, явно сообщи об этом и не заявляй успех.\n\nЗадача:\n" + task)
        if memory:
            from orchestrator.services.verified_skills import instructions
            task += instructions(path)
        shim=shutil.which('opencode.cmd')
        native=Path(shim).parent/'node_modules/opencode-ai/bin/opencode.exe' if shim else None
        if not native or not native.is_file():
            found=shutil.which('opencode.exe');native=Path(found) if found else None
        if not native or not native.is_file():raise ValueError('Не найден OpenCode EXE')
        if not agent:raise ValueError('Выберите модель OpenCode')
        from orchestrator.services.agent import agent_provider
        from orchestrator.services.provider_observer import observe
        with agent_provider(agent) as config, observe(json.loads(config)['provider']['orchestrator-agent']['options'] | {'url':json.loads(config)['provider']['orchestrator-agent']['options']['baseURL'], 'api_key':json.loads(config)['provider']['orchestrator-agent']['options']['apiKey']}) as (observed, records):
            config_data=json.loads(config)
            config_data['provider']['orchestrator-agent']['options'].update(baseURL=observed['url'],apiKey=observed['api_key'])
            config=json.dumps(config_data,ensure_ascii=False)
            env=os.environ.copy();env.update(OPENCODE_CONFIG_CONTENT=config,NO_PROXY='*',PYTHONIOENCODING='utf-8')
            result = _run([str(native),'run','--dir',str(path),'-m','orchestrator-agent/'+agent['model'],task],timeout or 900,cancel_event,cwd=path,env=env)
            result.provider_diagnostics=records
            if any('length' in r.get('finish_reasons',[]) and (r.get('max_tokens') or 0)>1 for r in records):
                result.tool_warnings.append('Исполнитель достиг лимита выхода; проверьте полноту результата')
            return annotate_tool_warnings(_save_result(result))
    except (ValueError,OSError,KeyError) as exc:return _save_result(ExecutionResult(error=str(exc)))


def run_review(files, cancel_event=None, project=""):
    try:
        path = resolve_project(project)
        if not REVIEW_GROQ.is_file():
            raise ValueError(f"Не найден скрипт проверки: {REVIEW_GROQ}")
        if not files:
            raise ValueError("Не указаны файлы для проверки")
        resolved = []
        for name in files:
            candidate = (path / name).resolve()
            if name.startswith('-') or not candidate.is_relative_to(path) or not candidate.is_file():
                raise ValueError(f"Файл проверки не найден внутри проекта: {name}")
            resolved.append(str(candidate))
    except (ValueError, OSError) as exc:
        return _save_result(ExecutionResult(error=str(exc)))
    return _run([SETTINGS.section("executor")["python"], str(REVIEW_GROQ)] + resolved,
                SETTINGS.section("reviewer")["timeout"], cancel_event, cwd=path)


def annotate_tool_warnings(result):
    """Preserve process outcome; textual diagnostics cannot prove final artifact failure."""
    import re
    output = result.stdout + '\n' + result.stderr
    output = re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]', '', output)
    if re.search(r'^\s*\+?\s*FullyQualifiedErrorId\s*:\s*(?:MissingFileSpecification|MissingVariableNameAfterForeach|UnexpectedToken|MethodCountCouldNotFindBest|CommandNotFoundException)\b', output, re.M):
        result.tool_warnings.append('В журнале PowerShell обнаружены ошибки команд; код CLI 0 не подтверждает выполнение проверки')
        return _save_result(result)
    return result
