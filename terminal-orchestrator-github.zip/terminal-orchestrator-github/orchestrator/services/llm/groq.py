import json
import os
import urllib.request
import urllib.error
from pathlib import Path
from .base import BaseLLM
from orchestrator.config import SETTINGS, read_api_key
from orchestrator.services.context import estimate

class GroqLLM(BaseLLM):
    def __init__(self, model=None):
        options = SETTINGS.provider("groq")
        self.api_key = read_api_key("groq")
        self.model = model or os.environ.get("GROQ_MODEL") or options["model"]
        self.proxy = os.environ.get("GROQ_PROXY", options["proxy"])
        self.timeout = options["timeout"]
        self.max_output_tokens = options["max_output_tokens"]
        self.url = options["url"]
        from orchestrator.services.connections import effective_input_budget
        self.input_budget = effective_input_budget({"context":options["context"],"max_output_tokens":self.max_output_tokens,"input_budget":options.get("input_budget",4000)})

    def name(self):
        return f"groq/{self.model}"

    def chat(self, messages, system=None):
        if not self.api_key:
            return "[ERR] GROQ_API_KEY не задан. Настройте GROQ_API_KEY или подключение API"

        if estimate(messages, system or '') > self.input_budget:
            return '[ERR] Контекст превышает бюджет тарифа Groq. Выберите Groq напрямую, чтобы история сжалась под его лимит.'
        msgs = []
        if system:
            msgs.append({"role": "system", "content": system})
        msgs.extend(messages)

        payload = {
            "model": self.model,
            "messages": msgs,
            "temperature": 0.7,
            "max_completion_tokens": self.max_output_tokens,
        }
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(
            self.url,
            data=data,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
                "User-Agent": "terminal-orchestrator/1.0",
            },
            method="POST",
        )
        try:
            proxies = {"http": self.proxy, "https": self.proxy} if self.proxy else {}
            opener = urllib.request.build_opener(urllib.request.ProxyHandler(proxies))

            with opener.open(req, timeout=self.timeout) as resp:
                result = json.loads(resp.read().decode("utf-8"))
                return result["choices"][0]["message"]["content"]
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", errors="ignore")
            return f"[ERR] Groq HTTP {e.code}: {body}"
        except Exception as e:
            return f"[ERR] Ошибка связи с Groq: {e}"
