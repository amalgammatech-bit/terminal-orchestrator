"""OpenAI-compatible chat endpoint for a user-configured API brain."""
import json
import urllib.request
import urllib.error
from urllib.parse import urlsplit
from .base import BaseLLM
from ..connections import validate, effective_input_budget

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):
        return None

class CompatibleLLM(BaseLLM):
    def __init__(self,profile):
        validated,key=validate({**profile,'enabled':True})
        profile={**validated,'api_key':key}
        self.model=profile['model']
        self.url=profile['url'].rstrip('/')
        self.api_key=profile.get('api_key','')
        self.input_budget=effective_input_budget(profile)
        self.max_output_tokens=profile['max_output_tokens']
        self.timeout=180
        self.device='api'
        self.last_usage={}
    def name(self):
        return 'API: '+self.model
    def chat(self,messages,system=None):
        history=([{'role':'system','content':system}] if system else [])+messages
        payload={'model':self.model,'messages':history,'stream':False,'max_tokens':self.max_output_tokens}
        headers={'Content-Type':'application/json'}
        if self.api_key:
            headers['Authorization']='Bearer '+self.api_key
        request=urllib.request.Request(self.url+'/chat/completions',data=json.dumps(payload,ensure_ascii=False).encode('utf-8'),headers=headers)
        handlers=[NoRedirect()]
        if urlsplit(self.url).hostname in ('localhost','127.0.0.1','::1'):
            handlers.append(urllib.request.ProxyHandler({}))
        opener=urllib.request.build_opener(*handlers)
        try:
            with opener.open(request,timeout=self.timeout) as response:
                data=json.load(response)
            self.last_usage=data.get('usage',{})
            text=data['choices'][0]['message']['content']
            return text if isinstance(text,str) and text.strip() else '[ERR] API не вернул текст ответа'
        except urllib.error.HTTPError as exc:
            return f'[ERR] API HTTP {exc.code}. Проверьте адрес, ключ, модель и лимиты провайдера.'
        except (OSError,ValueError,KeyError,IndexError,TypeError):
            return '[ERR] Не удалось получить ответ API. Проверьте подключение и формат Chat Completions.'
