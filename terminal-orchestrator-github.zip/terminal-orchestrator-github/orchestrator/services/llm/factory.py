"""Construct providers consistently for graphical and terminal interfaces."""
from orchestrator.config import SETTINGS
from .groq import GroqLLM
from .gemini import GeminiLLM
from .ollama import OllamaLLM


def create_model(row, device=None):
    if row[1]=='registry':
        from orchestrator.services.model_registry import private_profile
        from .compatible import CompatibleLLM
        return CompatibleLLM(private_profile(row[2]))
    if row[1]=='groq':
        return GroqLLM(row[2])
    if row[1]=='gemini':
        return GeminiLLM(row[2])
    if row[1]=='ollama':
        details=next((m for m in SETTINGS.section('llm').get('models',[]) if m['label']==row[0]),{})
        return OllamaLLM(row[2],url=details.get('url'),device=device,context=row[3],capabilities=details.get('capabilities'))
    raise ValueError('Неизвестный провайдер модели')
