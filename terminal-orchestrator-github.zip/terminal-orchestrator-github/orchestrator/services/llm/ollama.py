"""Ollama chat client. Device choice is explicit per request; proxies are bypassed."""
import json
import urllib.error
import urllib.request
from .base import BaseLLM
from orchestrator.config import SETTINGS


class OllamaLLM(BaseLLM):
    def __init__(self, model, url=None, device=None, context=None, capabilities=None):
        options=SETTINGS.provider('ollama')
        self.model=model
        self.url=(url or options['url']).rstrip('/')
        self.device=device or options['device']
        if self.device not in ('cpu','gpu'):
            raise ValueError('Для локального мозга выберите cpu или gpu')
        if context is not None and (type(context) is not int or context <= 0):
            raise ValueError('Контекст локальной модели должен быть положительным целым числом')
        # Cap per-model windows to the configured runtime allocation (RAM/VRAM).
        self.context=min(context if context is not None else options['context'],options['context'])
        self.timeout=options['timeout']
        self.max_output_tokens=options['max_output_tokens']
        self.input_budget=int(self.context*.75)-self.max_output_tokens
        if self.input_budget <= 0:
            raise ValueError('Лимит ответа слишком велик для контекста локальной модели')
        self.capabilities=capabilities or []
        self.last_usage={}
        self.opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))

    def name(self):
        return f'Локальная: {self.model} ({self.device.upper()})'

    def chat(self,messages,system=None):
        history=[]
        if system:
            history.append({'role':'system','content':system})
        history.extend({'role':m['role'],'content':m['content']} for m in messages)
        payload={'model':self.model,'messages':history,'stream':False,'keep_alive':'60s',
                 'options':{'num_gpu':0 if self.device=='cpu' else -1,'num_ctx':self.context,
                            'num_predict':self.max_output_tokens,'temperature':.7}}
        # GPT-OSS defines string thinking levels; preserve model variants there.
        if 'thinking' in self.capabilities and not self.model.startswith('gpt-oss'):
            payload['think']=False
        request=urllib.request.Request(self.url+'/api/chat',data=json.dumps(payload,ensure_ascii=False).encode('utf-8'),
                                       headers={'Content-Type':'application/json'},method='POST')
        try:
            with self.opener.open(request,timeout=self.timeout) as response:
                data=json.load(response)
            text=data.get('message',{}).get('content','')
            self.last_usage={key:data.get(key) for key in ('prompt_eval_count','eval_count','load_duration')}
            if not isinstance(text,str) or not text.strip():
                return '[ERR] Локальная модель не выдала итоговый ответ. Попробуйте другую модель или увеличьте лимит ответа.'
            return text
        except urllib.error.HTTPError as exc:
            try:
                error=json.loads(exc.read().decode('utf-8')).get('error',str(exc))
            except (ValueError,OSError):
                error=str(exc)
            return f'[ERR] Ollama HTTP {exc.code}: {error}'
        except (OSError,ValueError) as exc:
            return f'[ERR] Нет связи с локальной моделью {self.model} на {self.url}: {exc}'
