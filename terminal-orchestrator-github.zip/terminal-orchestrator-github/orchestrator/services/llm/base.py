from abc import ABC, abstractmethod

class BaseLLM(ABC):
    @abstractmethod
    def chat(self, messages, system=None):
        """Отправляет сообщения и возвращает ответ."""
        pass

    @abstractmethod
    def name(self):
        """Имя провайдера."""
        pass
