import json
import os
import time
import urllib.request
import urllib.error
from pathlib import Path
from .base import BaseLLM
from orchestrator.config import SETTINGS, read_api_key

class GeminiLLM(BaseLLM):
    def __init__(self, model=None):
        options = SETTINGS.provider("gemini")
        self.api_key = read_api_key("gemini")
        self.model = model or os.environ.get("GEMINI_MODEL") or options["model"]
        self.proxy = os.environ.get("GEMINI_PROXY", options["proxy"])
        self.timeout = options["timeout"]
        self.max_output_tokens = options["max_output_tokens"]
        from orchestrator.services.connections import effective_input_budget
        self.input_budget = effective_input_budget({"context":options["context"],"max_output_tokens":self.max_output_tokens,"input_budget":options.get("input_budget",32000)})
        self.url = f"{options['url'].rstrip('/')}/{self.model}:generateContent"

    def name(self):
        return f"gemini/{self.model}"

    def chat(self, messages, system=None):
        if not self.api_key:
            return "[ERR] GEMINI_API_KEY не задан."

        # Конвертируем формат OpenAI в Gemini
        contents = []
        if system:
            contents.append({"role": "user", "parts": [{"text": f"System: {system}"}]})
        for msg in messages:
            role = "model" if msg["role"] == "assistant" else "user"
            contents.append({"role": role, "parts": [{"text": msg["content"]}]})

        payload = {"contents": contents, "generationConfig": {"maxOutputTokens": self.max_output_tokens}}
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")

        url = f"{self.url}?key={self.api_key}"
        req = urllib.request.Request(
            url,
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        # До 3 попыток: при перегрузке (503) или лимите (429) ждём и повторяем
        last_err = None
        for attempt in range(3):
            try:
                proxies = {"http": self.proxy, "https": self.proxy} if self.proxy else {}
                opener = urllib.request.build_opener(urllib.request.ProxyHandler(proxies))

                with opener.open(req, timeout=self.timeout) as resp:
                    result = json.loads(resp.read().decode("utf-8"))
                    return result["candidates"][0]["content"]["parts"][0]["text"]
            except urllib.error.HTTPError as e:
                body = e.read().decode("utf-8", errors="ignore")
                last_err = f"[ERR] Gemini HTTP {e.code}: {body}"
                if e.code in (429, 500, 502, 503, 504) and attempt < 2:
                    time.sleep(5 * (attempt + 1))
                    continue
                return last_err
            except Exception as e:
                return f"[ERR] Ошибка связи с Gemini: {e}"
        return last_err
