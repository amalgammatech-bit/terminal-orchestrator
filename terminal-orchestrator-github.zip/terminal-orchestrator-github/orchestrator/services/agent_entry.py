"""Keep existing bridge review flow, run OpenCode with explicit --dir and -m."""
import importlib.util
import os
import shutil
import subprocess
import sys


def main():
    source=os.environ['ORCHESTRATOR_BRIDGE_PATH']
    spec=importlib.util.spec_from_file_location('orchestrator_external_bridge',source)
    bridge=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(bridge)
    codes=[]
    def run(project,task,timeout):
        executable=shutil.which('opencode.cmd') or shutil.which('opencode')
        if not executable:
            codes.append(1)
            return 1,'','OpenCode не найден в PATH'
        env=os.environ.copy()
        env['NO_PROXY']='*'
        try:
            result=subprocess.run([executable,'run','--dir',str(project),'-m',env['ORCHESTRATOR_AGENT_MODEL'],task],
                                  cwd=str(project),env=env,capture_output=True,text=True,
                                  encoding='utf-8',errors='replace',timeout=timeout)
            codes.append(result.returncode)
            return result.returncode,result.stdout,result.stderr
        except subprocess.TimeoutExpired as exc:
            codes.append(1)
            stdout=exc.stdout or b''
            stderr=exc.stderr or b''
            return 1,stdout.decode('utf-8',errors='replace') if isinstance(stdout,bytes) else stdout, str(stderr)+'\nOpenCode timed out'
    bridge.run_opencode=run
    bridge.main()
    if codes and codes[-1]:
        sys.exit(codes[-1])

if __name__=='__main__':
    main()
