"""Ephemeral Anthropic HTTP relay; logs protocol counters, never content or keys."""
import json,secrets,hmac,threading,urllib.request,urllib.error,re
from urllib.parse import urlsplit,parse_qsl
from contextlib import contextmanager
from http.client import HTTPException
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer

class Meter:
 def __init__(self,row):self.row=row;self.buffer=b'';self.data=[]
 def note(self,v):
  if not isinstance(v,dict):return
  kind=v.get('type');allowed={'message_start','message_delta','message_stop','content_block_start','content_block_delta','content_block_stop','ping','error'}
  kind=kind if kind in allowed else 'unknown'
  counts=self.row['events'];counts[kind]=counts.get(kind,0)+1
  if kind=='message_stop':self.row['message_stop']=True
  msg=v.get('message',{}) if isinstance(v.get('message'),dict) else {}
  for usage in (msg.get('usage'),v.get('usage')):
   if isinstance(usage,dict):
    for k in ('input_tokens','output_tokens','cache_read_input_tokens','cache_creation_input_tokens'):
     if type(usage.get(k)) is int:self.row['usage'][k]=usage[k]
  delta=v.get('delta',{})
  if isinstance(delta,dict):
   reason=delta.get('stop_reason')
   if reason:self.row['stop_reason']=reason if reason in ('end_turn','max_tokens','tool_use','stop_sequence','pause_turn','refusal','model_context_window_exceeded') else 'unknown'
   if delta.get('type')=='text_delta' and isinstance(delta.get('text'),str):self.row['text_bytes']+=len(delta['text'].encode('utf8'))
  blocks=v.get('content',[]) if isinstance(v.get('content'),list) else []
  if isinstance(v.get('content_block'),dict):blocks=blocks+[v['content_block']]
  for b in blocks:
   if not isinstance(b,dict):continue
   k=b.get('type');k=k if k in ('text','thinking','tool_use','redacted_thinking') else 'unknown'
   self.row['blocks'][k]=self.row['blocks'].get(k,0)+1
   if k=='text' and isinstance(b.get('text'),str):self.row['text_bytes']+=len(b['text'].encode('utf8'))
  if v.get('stop_reason'):self.note({'type':'message_delta','delta':{'stop_reason':v['stop_reason']}})
 def event(self):
  if self.data:
   try:self.note(json.loads(b'\n'.join(self.data)))
   except (ValueError,UnicodeError):self.row['parse_errors']+=1
  self.data=[]
 def feed(self,chunk):
  self.buffer+=chunk
  if len(self.buffer)>2000000:self.buffer=b'';self.data=[];self.row['parse_errors']+=1;return
  while b'\n' in self.buffer:
   line,self.buffer=self.buffer.split(b'\n',1);line=line.rstrip(b'\r')
   if not line:self.event()
   elif line.startswith(b'data:'):self.data.append(line[5:].lstrip(b' '))
 def finish(self):
  if self.buffer:self.feed(b'\n')
  self.event()

@contextmanager
def observe(base,key):
 records=[];token=secrets.token_urlsafe(32)
 class Handler(BaseHTTPRequestHandler):
  def log_message(self,*args):pass
  def do_POST(self):
   self.connection.settimeout(15)
   provided=self.headers.get('x-api-key','')
   bearer=self.headers.get('Authorization','')
   if not (hmac.compare_digest(provided,token) or hmac.compare_digest(bearer,'Bearer '+token)):
    self.send_error(403);return
   target=urlsplit(self.path)
   if target.scheme or target.netloc or target.path not in ('/v1/messages','/v1/messages/count_tokens'):
    records.append({'endpoint':'rejected','origin':'relay','http_status':404});self.send_error(404);return
   query=parse_qsl(target.query,keep_blank_values=True)
   if len(query)>1 or any(k!='beta' or v not in ('true','false') for k,v in query):
    records.append({'endpoint':'rejected','origin':'relay','http_status':400});self.send_error(400);return
   try:length=int(self.headers.get('Content-Length','0'))
   except ValueError:self.send_error(400);return
   if not 0<length<=8000000:self.send_error(413);return
   body=self.rfile.read(length)
   try:request=json.loads(body)
   except ValueError:self.send_error(400);return
   if not isinstance(request,dict):self.send_error(400);return
   row={'endpoint':'count_tokens' if target.path.endswith('count_tokens') else 'messages','stream':request.get('stream') is True,'max_tokens':request.get('max_tokens') if type(request.get('max_tokens')) is int else None,'events':{},'blocks':{},'usage':{},'text_bytes':0,'response_bytes':0,'message_stop':False,'parse_errors':0}
   records.append(row);meter=Meter(row)
   headers={'Content-Type':'application/json','x-api-key':key,'Authorization':'Bearer '+key,'Accept-Encoding':'identity'}
   for k in ('anthropic-version','anthropic-beta','Accept'):
    if self.headers.get(k):headers[k]=self.headers[k]
   req=urllib.request.Request(base.rstrip('/')+self.path,data=body,headers=headers)
   response=None;sent=False
   try:
    try:response=urllib.request.build_opener(urllib.request.ProxyHandler({})).open(req,timeout=900)
    except urllib.error.HTTPError as exc:response=exc
    row['http_status']=response.code;content_type=response.headers.get('Content-Type','application/json')
    row['content_type']='sse' if 'text/event-stream' in content_type else 'json' if 'json' in content_type else 'other'
    rid=response.headers.get('request-id') or response.headers.get('x-request-id')
    if rid and re.fullmatch(r'[A-Za-z0-9_-]{1,128}',rid):row['request_id']=rid
    self.send_response(response.code);self.send_header('Content-Type',content_type);self.end_headers();sent=True
    data=b''
    while True:
     chunk=response.read1(8192)
     if not chunk:break
     row['response_bytes']+=len(chunk)
     if row['content_type']=='sse':meter.feed(chunk)
     elif len(data)<2000000:data+=chunk
     self.wfile.write(chunk);self.wfile.flush()
    if row['content_type']=='sse':meter.finish();row['incomplete_sse']=not row['message_stop']
    elif row['content_type']=='json':
     try:meter.note(json.loads(data))
     except (ValueError,UnicodeError):row['parse_errors']+=1
   except (OSError,ValueError,HTTPException) as exc:
    row['transport_error']=type(exc).__name__
    if not sent:self.send_error(502,'Upstream transport failed')
   finally:
    if response:response.close()
 server=ThreadingHTTPServer(('127.0.0.1',0),Handler);server.daemon_threads=True
 thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
 try:yield {'ANTHROPIC_BASE_URL':f'http://127.0.0.1:{server.server_port}','ANTHROPIC_API_KEY':token,'ANTHROPIC_AUTH_TOKEN':''},records
 finally:server.shutdown();server.server_close();thread.join(2)
