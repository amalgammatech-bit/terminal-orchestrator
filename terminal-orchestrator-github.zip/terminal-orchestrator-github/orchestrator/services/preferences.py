"""Small shared UI preferences file, separate from model configuration."""
import json
import threading
import uuid
from orchestrator.config import SETTINGS

_lock=threading.RLock()

def read_preferences():
    path=SETTINGS.path('sessions_db').parent/'ui-preferences.json'
    try:
        data=json.loads(path.read_text(encoding='utf-8'))
        return data if isinstance(data,dict) else {}
    except (OSError,ValueError):
        return {}


def save_preferences(changes):
    with _lock:
        data=read_preferences()
        data.update(changes)
        path=SETTINGS.path('sessions_db').parent/'ui-preferences.json'
        path.parent.mkdir(parents=True,exist_ok=True)
        temporary=path.with_name(path.name+'.'+uuid.uuid4().hex+'.tmp')
        temporary.write_text(json.dumps(data,ensure_ascii=False),encoding='utf-8')
        temporary.replace(path)
        return data
