from pathlib import Path

from orchestrator.config import SETTINGS

MEMORY_DIR = SETTINGS.path("memory_dir")

def get_memory_path(project_name):
    if not project_name:
        project_name = "default"
    # безопасное имя файла
    safe_name = "".join(c for c in project_name if c.isalnum() or c in ('-', '_')).rstrip()
    return MEMORY_DIR / f"{safe_name}.md"

def load_memory(project_name):
    path = get_memory_path(project_name)
    if path.exists():
        try:
            return path.read_text(encoding="utf-8")
        except Exception:
            return ""
    return ""

def save_memory(project_name, text):
    path = get_memory_path(project_name)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
        return True
    except Exception:
        return False

def list_projects():
    """Список папок в настроенном каталоге проектов."""
    from orchestrator.services.access import state
    policy=state()
    if policy["mode"]=="folder":return [policy["folder"]]
    root = SETTINGS.path("projects_root")
    projects = []
    for p in root.iterdir():
        if p.is_dir() and not p.name.startswith('.') and p.name not in ('terminal-orchestrator', 'tools', '__pycache__'):
            projects.append(p.name)
    return sorted(projects)
