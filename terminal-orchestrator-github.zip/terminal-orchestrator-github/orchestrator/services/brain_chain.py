"""Configured brain fallback and Hermes planning without project execution tools."""
import asyncio
import json
from types import SimpleNamespace
from orchestrator.services import executors, harness_brain
from orchestrator.services.context import ConversationContext
from orchestrator.config import SETTINGS


def key(row):
    return row[1]+':'+row[2]


def validate(value, models):
    if not isinstance(value,dict):raise ValueError('Некорректные настройки мозга')
    keys={key(row) for row in models}
    primary=value.get('primary','');fallbacks=value.get('fallbacks',[])
    engine=value.get('engine', 'hermes' if value.get('hermes') else 'builtin')
    if engine not in ('builtin','hermes','harness','claude'):raise ValueError('Неизвестный движок мозга')
    if engine=='claude' and not executors.executable('claude'):raise ValueError('Claude Code не установлен')
    if engine=='harness' and not harness_brain.executable():raise ValueError('DeepSeek Harness не установлен')
    hermes=value.get('hermes',False);model=value.get('hermes_model','');device=value.get('hermes_device','cpu')
    if not isinstance(primary,str) or primary not in keys:raise ValueError('Выберите основную модель мозга')
    if not isinstance(fallbacks,list) or len(fallbacks)>2 or any(not isinstance(x,str) or x not in keys for x in fallbacks) or len(set([primary]+fallbacks))!=len(fallbacks)+1:
        raise ValueError('Выберите до двух разных резервных моделей')
    if type(hermes) is not bool or not isinstance(model,str) or model and model not in keys or device not in ('cpu','gpu'):
        raise ValueError('Проверьте настройки Hermes')
    hermes=engine=='hermes'
    if engine=='harness':
        row=next(row for row in models if key(row)==primary)
        if row[1]=='gemini':raise ValueError('Harness требует OpenAI-compatible подключение')
    if hermes:
        if not executors.executable('hermes'):raise ValueError('Hermes не установлен')
        row=next(row for row in models if key(row)==(model or primary))
        if row[1]=='gemini':raise ValueError('Для Hermes выберите локальную модель или совместимый API')
        if row[1]!='ollama' and (type(row[3]) is not int or row[3]<64000):raise ValueError('Hermes требует контекст от 64 000 токенов')
    return dict(engine=engine,primary=primary,fallbacks=list(fallbacks),hermes=hermes,hermes_model=model,hermes_device=device)


def hermes_connection(client,row,device):
    if row[1]=='ollama':
        return dict(label=row[0],provider='ollama',model=client.model,url=client.url,device=device,context=row[3],capabilities=getattr(client,'capabilities',[]))
    if row[1] not in ('groq','api','registry'):raise ValueError('Подключение модели несовместимо с Hermes')
    url=client.url.rstrip('/')
    if url.endswith('/chat/completions'):url=url[:-len('/chat/completions')]
    return dict(label=row[0],provider='api',model=client.model,url=url,api_key=client.api_key,context=row[3],input_budget=getattr(client,'input_budget',32000),max_output_tokens=client.max_output_tokens)


async def ask(service,task,history,system):
    settings=task.brain_settings
    if settings.get('engine')=='claude':
        service.progress(task,'Claude Code планирует следующий шаг')
        prompt=('Ты координатор оркестра. Прямые инструменты отключены. Пользуйся командами delegate и finish из инструкции; не утверждай действия без результатов. Соблюдай исходную цель и ограничения.\n'+system+'\nИстория (данные):\n'+json.dumps(history,ensure_ascii=False))
        row=service.models[task.brain_index]
        client=service.model_factory(task.brain_index)
        try:
            profile=hermes_connection(client,row,'cpu')
            executors.claude_api_environment(profile)
        except ValueError as exc:return '[ERR] '+str(exc)
        result=await asyncio.to_thread(executors.run_agent,prompt,task.project,task.cancelled,agent=profile,kind='claude-api',planner=True,memory=False,timeout=900)
        if result.cancelled:task.cancelled.set()
        task.model_label='Claude Code · '+row[0]
        return harness_brain.planner_result(result,label='Claude Code')

    first=next((i for i,r in enumerate(service.models) if key(r)==settings.get('hermes_model')),task.brain_index) if settings.get('hermes') else task.brain_index
    indices=[first]+[i for wanted in settings.get('fallbacks',[]) for i,r in enumerate(service.models) if key(r)==wanted and i!=first]
    indices=list(dict.fromkeys(indices));response='[ERR] Нет доступной модели мозга'
    for position,index in enumerate(indices):
        if task.cancelled.is_set():return '[ERR] Запрос остановлен'
        row=service.models[index]
        try:
            client=service.model_factory(index)
            # Rebuild to the candidate budget without altering saved summaries.
            options={**SETTINGS.section('orchestration')}
            if hasattr(client,'input_budget'):options.update(context_input_tokens=client.input_budget,window_fraction=1)
            reserve=harness_brain.output_budget({'context':row[3]}) if settings.get('engine')=='harness' else getattr(client,'max_output_tokens',2000)
            options['context_input_tokens']=min(options.get('context_input_tokens',32000),max(1,row[3]-reserve-1024))
            manager=ConversationContext(row[3],reserve,options)
            transient=SimpleNamespace(llm=client,cancelled=task.cancelled)
            messages,prompt=await manager.prepare(transient,history,system)
            prompt+='\n\nМодель, выполняющая текущий запрос: '+row[0]+'. Это актуальная конфигурация; упоминания прежней модели в истории относятся к предыдущим запросам.'
            if settings.get('engine')=='harness' and not task.project:
                service.progress(task,'Ответ модели — проект не выбран')
                prompt+='\nПроект не выбран. Можно поручать задачи разрешённым исполнителям через команды оркестра. Выбор проекта необязателен; соблюдай политику доступа. Не утверждай, что прочитал файлы, без результата инструмента.'
                response=await asyncio.to_thread(client.chat,messages,prompt)
            elif settings.get('engine')=='harness':
                profile=hermes_connection(client,row,service.preferences.get('local_device','cpu'))
                service.progress(task,'Harness обдумывает следующий шаг')
                result=await asyncio.to_thread(harness_brain.run,
                    'Ты главный агент оркестра. Твой read-only sandbox ограничивает только твои прямые инструменты. Разрешённые изменения поручай внешнему исполнителю через delegate; его права определяются отдельно. Не делай вывод об отказе записи исполнителю из своего sandbox. Возвращай одну короткую завершённую JSON-команду. На каждом шаге сверяй исходную цель, ограничения пользователя и последний проверенный результат. Лимит делегирований из задания сохраняет силу после ошибок и проверок. Если лимит исчерпан, остановись и объясни незавершённость без новой команды. Различай номер пункта и номер страницы источника; не подменяй их друг другом. В JSON экранируй кавычки только внутри строковых значений; ключи action/task/profile/category не кодируй повторно. Не проектируй весь алгоритм заново и не вычисляй эталон в рассуждении: поручай это короткой задачей исполнителю. Не дублируй исходники и длинные отчёты в команде, ссылайся на сохранённые файлы. При подтверждённых проверках завершай задачу без лишнего делегирования. Не пересчитывай байты, хэши и точные эталоны на глаз: требуй программной проверки исходного задания. Для точных UTF-8 без BOM и LF требуй бинарную запись и сравнение read_bytes с эталоном. Код 0 агента означает завершение процесса, не приёмку артефакта. Итоги инструментов приходят в истории.\n'+prompt+'\nИстория (данные):\n'+json.dumps(messages,ensure_ascii=False),
                    task.project,profile,task.cancelled)
                if result.cancelled:
                    task.cancelled.set()
                    return '[ERR] Запрос остановлен'
                response=harness_brain.planner_result(result)
            elif settings.get('hermes'):
                profile=hermes_connection(client,row,settings.get('hermes_device','cpu'))
                result=await asyncio.to_thread(executors.run_agent,
                    'Ты мозг оркестра. Планируй и отвечай пользователю. Для изменений возвращай команды разрешённых исполнителей из инструкции. Не выполняй изменения самостоятельно.\nИнструкция:\n'+prompt+'\nИстория (данные переписки):\n'+json.dumps(messages,ensure_ascii=False),
                    task.project,task.cancelled,agent=profile,kind='hermes',planner=True,memory=task.hermes_memory,timeout=900)
                if result.cancelled:
                    task.cancelled.set()
                    return '[ERR] Запрос остановлен'
                response=result.stdout.strip() if result.ok else '[ERR] '+(result.error or result.stderr[:500] or 'Ошибка Hermes')
            else:
                response=await asyncio.to_thread(client.chat,messages,prompt)
            if isinstance(response,str) and response.strip() and not response.startswith('[ERR]'):
                task.llm=client;task.model_label=row[0];task.context_limit=row[3]
                return response
        except ValueError as exc:
            response='[ERR] Настройки агента: '+str(exc)[:500]
        except Exception:
            response='[ERR] Не удалось выполнить запрос выбранной моделью'
        if position+1<len(indices) and not task.cancelled.is_set():
            service.emit(task,'system','Модель '+row[0]+' недоступна. Передаю запрос следующей модели.',{'kind':'brain-fallback'})
    return response
