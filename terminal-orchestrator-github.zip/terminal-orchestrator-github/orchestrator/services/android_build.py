"""Single-owner Android build runner. Scripts are trusted project code, not sandboxed."""
import hashlib
import os
from pathlib import Path
import signal
import shutil
import subprocess
import threading
import uuid

_BUILD_TIMEOUT_SECONDS = 900

def build_environment():
    """Supply installed Android tools to GUI launches without changing Windows settings."""
    env=os.environ.copy()
    if not env.get('JAVA_HOME') and not shutil.which('java',path=env.get('PATH','')):
        jbr=Path(env.get('PROGRAMFILES','C:/Program Files'))/'Android/Android Studio/jbr'
        if (jbr/'bin/java.exe').is_file():
            env['JAVA_HOME']=str(jbr)
            env['PATH']=str(jbr/'bin')+os.pathsep+env.get('PATH','')
    if not env.get('ANDROID_HOME') and not env.get('ANDROID_SDK_ROOT'):
        sdk=Path(env.get('LOCALAPPDATA',''))/'Android/Sdk'
        if sdk.is_dir():
            # Reuse an existing SDK alias only when it points to this exact SDK.
            alias=Path('Z:/')
            try:
                if alias.exists() and alias.samefile(sdk):sdk=alias
            except OSError:pass
            env['ANDROID_HOME']=str(sdk)
            env['ANDROID_SDK_ROOT']=str(sdk)
    return env

class AndroidBuilder:
    def __init__(self, resolve_project, output_dir, adb_path=None, apksigner_path=None):
        self.resolve_project=resolve_project
        self.output_dir=Path(output_dir).resolve()
        self.adb_path=str(adb_path) if adb_path else None
        self.apksigner_path=str(apksigner_path) if apksigner_path else None
        self._lock=threading.RLock()
        self._process=None
        self._thread=None
        self._cancel=threading.Event()
        self._state=dict(active=False,status='idle',message='Сборка не запускалась',log='',artifacts=[],returncode=None)

    def state(self):
        with self._lock:return {**self._state,'artifacts':list(self._state['artifacts'])}

    def _finish(self,status,message,returncode=None,artifacts=()):
        with self._lock:self._state.update(active=False,status=status,message=message,returncode=returncode,artifacts=list(artifacts))
        return self.state()

    def start(self,project,variant='debug',install=False):
        with self._lock:
            if self._state['active'] or self._thread is not None and self._thread.is_alive():raise ValueError('Сборка уже выполняется')
            if variant not in ('debug','release') or not isinstance(variant,str):raise ValueError('Вариант: debug или release')
            if type(install) is not bool:raise ValueError('install должен быть boolean')
            if install and (not self.adb_path or not self.apksigner_path):raise ValueError('Для установки укажите adb и apksigner; автоматическая установка отключена')
            project=Path(self.resolve_project(project)).resolve()
            if not project.is_dir():raise ValueError('Папка проекта не найдена')
            wrapper=project/'gradlew.bat'
            if wrapper.is_file():
                # cmd parses the command even with shell=False. Reject metacharacters
                # in wrapper paths rather than interpreting a project name as code.
                if any(ch in str(wrapper) for ch in '&|<>^%!\r\n'):
                    raise ValueError('Путь Gradle содержит недопустимые символы cmd')
                command='cmd.exe /d /s /c ""'+str(wrapper)+'" '+('assembleDebug' if variant=='debug' else 'assembleRelease')+'"'
            elif (project/'build.ps1').is_file():
                if variant=='release':raise ValueError('Для build.ps1 доступен только debug; release требует настройки проекта')
                command=['powershell.exe','-NoProfile','-File',str(project/'build.ps1')]
            else:raise ValueError('В корне проекта нужен gradlew.bat или build.ps1')
            before=self._fingerprint_apks(project)
            self.output_dir.mkdir(parents=True,exist_ok=True)
            logfile=self.output_dir/('android-'+uuid.uuid4().hex+'.log')
            self._cancel.clear()
            self._state=dict(active=True,status='running',message='Сборка '+variant,log=str(logfile),artifacts=[],returncode=None)
            self._thread=threading.Thread(target=self._run,args=(project,command,before,logfile,install),daemon=True)
            self._thread.start()
            return self.state()

    def _run(self,project,command,before,logfile,install):
        try:
            with logfile.open('w',encoding='utf-8') as log:
                code=self._command(command,project,log,_BUILD_TIMEOUT_SECONDS)
                if self._cancel.is_set():self._finish('cancelled','Сборка остановлена',code);return
                if code!=0:self._finish('error','Сборка завершилась с ошибкой',code);return
                after=self._fingerprint_apks(project)
                artifacts=sorted(name for name,sha in after.items() if before.get(name)!=sha)
                if not artifacts:self._finish('error','Новых или изменённых APK нет; старый APK не считается результатом',code);return
                if install:
                    if len(artifacts)!=1:raise ValueError('Установка требует ровно один новый APK; выберите вариант сборки без split APK')
                    if self._cancel.is_set():self._finish('cancelled','Установка отменена',code);return
                    devices=self.output_dir/('devices-'+uuid.uuid4().hex+'.txt')
                    with devices.open('w',encoding='utf-8') as device_output:
                        result=self._command([self.adb_path,'devices'],project,device_output,30)
                    if result:raise ValueError('Не удалось получить список adb устройств')
                    rows=[line.split() for line in devices.read_text(encoding='utf-8',errors='replace').splitlines() if line.strip() and not line.startswith(('List of devices','*'))]
                    if len(rows)!=1 or len(rows[0])<2 or rows[0][1]!='device':raise ValueError('Для установки нужно ровно одно подключённое и разрешённое adb устройство')
                    signer=Path(self.apksigner_path)
                    if signer.suffix.lower()=='.bat':
                        if any(ch in str(signer)+artifacts[0] for ch in '&|<>^%!\r\n'):raise ValueError('Недопустимый путь apksigner/APK')
                        verify='cmd.exe /d /s /c ""'+str(signer)+'" verify --verbose "'+artifacts[0]+'""'
                    else:verify=[str(signer),'verify','--verbose',artifacts[0]]
                    if self._command(verify,project,log,60):raise ValueError('Подпись APK не прошла apksigner verify; установка отменена')
                    if self._command([self.adb_path,'-s',rows[0][0],'install','-r',artifacts[0]],project,log,120):raise ValueError('adb install -r завершился с ошибкой')
                if self._cancel.is_set():self._finish('cancelled','Операция остановлена',None,artifacts);return
                self._finish('success','APK собран'+(' и установлен' if install else ''),code,artifacts)
        except InterruptedError:
            self._finish('cancelled','Операция остановлена')
        except subprocess.TimeoutExpired:
            self._finish('error','Превышено время выполнения команды')
        except Exception as exc:
            self._finish('cancelled' if self._cancel.is_set() else 'error',str(exc))
        finally:
            with self._lock:self._process=None

    def _command(self,command,project,log,timeout):
        with self._lock:
            if self._cancel.is_set():raise InterruptedError()
            process=subprocess.Popen(command,cwd=str(project),stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,
                env=build_environment(),
                creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0,start_new_session=os.name!='nt')
            self._process=process
        try:
            return process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            self._terminate_owned_process(process)
            process.wait(timeout=10)
            raise
        finally:
            with self._lock:
                if self._process is process:self._process=None

    def stop(self):
        with self._lock:
            if not self._state['active']:return self.state()
            self._cancel.set()
            if self._process is not None:self._terminate_owned_process(self._process)
            self._state['message']='Останавливаю собственный процесс сборки'
        return self.state()

    @staticmethod
    def _terminate_owned_process(process):
        if process.poll() is not None:return
        if os.name=='nt':
            subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW,timeout=15)
            if process.poll() is None:process.kill()
        else:
            try:os.killpg(process.pid,signal.SIGKILL)
            except ProcessLookupError:pass

    @staticmethod
    def _fingerprint_apks(project):
        results={}
        # Gradle root module, app and other module build directories, or custom dist.
        roots=[project/'dist',project/'build/outputs/apk']
        roots.extend(child/'build/outputs/apk' for child in project.iterdir() if child.is_dir() and not child.is_symlink())
        for root in roots:
            resolved=root.resolve()
            if not resolved.is_relative_to(project) or not resolved.is_dir():continue
            for candidate in resolved.rglob('*.apk'):
                path=candidate.resolve()
                if not path.is_relative_to(resolved) or not path.is_file():continue
                digest=hashlib.sha256()
                with path.open('rb') as stream:
                    for chunk in iter(lambda:stream.read(1024*1024),b''):digest.update(chunk)
                results[str(path)]=(digest.hexdigest(),path.stat().st_mtime_ns)
        return results
