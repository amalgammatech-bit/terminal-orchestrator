"""Per-run OpenCode provider with explicit Ollama CPU/GPU routing."""
import hmac
import json
import secrets
import threading
import urllib.request
import uuid
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from contextlib import contextmanager
from orchestrator.config import SETTINGS


def catalog():
    rows=[]
    for row in SETTINGS.section('llm').get('models',[]):
        if row.get('provider')!='ollama':continue
        if 'tools' in row.get('capabilities',[]):rows.append(dict(row))
        elif row.get('model')=='deepseek-coder-v2:16b':
            rows.append(dict(row))
    return rows


def effective_limits(profile):
    context = int(profile.get('context', SETTINGS.provider('ollama')['context']))
    if context < 512: raise ValueError('Executor context must be >=512')
    default = SETTINGS.section('orchestration').get('executor_output_tokens', 8192) if profile.get('provider')=='api' else SETTINGS.provider('ollama')['max_output_tokens']
    output = profile.get('executor_max_output_tokens', default)
    if type(output) is not int or output < 256: raise ValueError('Executor output must be >=256')
    return context, min(output, context//2)


def native_payload(data, profile):
    context, output = effective_limits(profile)
    messages=[]
    for original in data.get('messages',[]):
        item=dict(original)
        calls=[]
        for call in item.get('tool_calls',[]):
            function=dict(call['function'])
            if isinstance(function.get('arguments'),str):
                function['arguments']=json.loads(function['arguments'] or '{}')
            calls.append({'function':function})
        if calls:
            item['tool_calls']=calls
        if item.get('content') is None:
            item['content']=''
        messages.append(item)
    payload={'model':profile['model'],'messages':messages,'stream':False,'keep_alive':'60s',
             'options':{'num_gpu':0 if profile['device']=='cpu' else -1,
                        'num_ctx':context,
                        'num_predict':output}}
    if data.get('tools'):
        payload['tools']=data['tools']
    if 'thinking' in profile.get('capabilities',[]):
        payload['think']='low' if profile['model'].startswith('gpt-oss') else False
    return payload


def completion(data, profile):
    request=urllib.request.Request(profile['url'].rstrip('/')+'/api/chat',
        data=json.dumps(native_payload(data,profile),ensure_ascii=False).encode('utf-8'),
        headers={'Content-Type':'application/json'})
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(request,timeout=SETTINGS.provider('ollama')['timeout']) as response:
        result=json.load(response)
    message=result.get('message',{})
    calls=[]
    for call in message.get('tool_calls',[]):
        function=call['function']
        calls.append({'id':'call_'+uuid.uuid4().hex,'type':'function',
                      'function':{'name':function['name'],'arguments':json.dumps(function.get('arguments',{}),ensure_ascii=False)}})
    if not calls and not message.get('content'):
        raise ValueError('Модель агента не выдала ответ или вызов инструмента')
    reply={'role':'assistant','content':message.get('content','')}
    if calls:
        reply['tool_calls']=calls
    return {'id':'chatcmpl-'+uuid.uuid4().hex,'object':'chat.completion','created':int(time.time()),'model':profile['model'],
            'choices':[{'index':0,'message':reply,'finish_reason': 'length' if result.get('done_reason')=='length' else 'tool_calls' if calls else 'stop'}],
            'usage':{'prompt_tokens':result.get('prompt_eval_count',0),'completion_tokens':result.get('eval_count',0),
                     'total_tokens':result.get('prompt_eval_count',0)+result.get('eval_count',0)}}


@contextmanager
def agent_provider(profile):
    context, output = effective_limits(profile)
    if profile.get('provider')=='api':
        key='orchestrator-agent'
        config={'model':key+'/'+profile['model'],'small_model':key+'/'+profile['model'],
                # OpenCode's default reserve can exceed a small configured window,
                # forcing compaction immediately after the first tool call.
                'compaction':{'reserved':min(2048,max(256,profile['context']//8))},
                'provider':{key:{'npm':'@ai-sdk/openai-compatible','name':'API агента',
                    'options':{'baseURL':profile['url'],'apiKey':profile.get('api_key','')},
                    'models':{profile['model']:{'name':profile['label'],
                        'limit':{'context':context,'output':output}}}}}}
        yield json.dumps(config,ensure_ascii=False)
        return
    token=secrets.token_urlsafe(24)
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):
            pass
        def do_POST(self):
            try:
                self.connection.settimeout(15)
                if self.path!='/v1/chat/completions' or not hmac.compare_digest(self.headers.get('Authorization',''),'Bearer '+token):
                    self.send_error(403)
                    return
                length=int(self.headers.get('Content-Length','0'))
                if not 0<length<=2000000:
                    self.send_error(413)
                    return
                data=json.loads(self.rfile.read(length))
                result=completion(data,profile)
                if data.get('stream'):
                    choice=result['choices'][0]
                    delta=dict(choice['message'])
                    for index,call in enumerate(delta.get('tool_calls',[])):
                        call['index']=index
                    chunk={**result,'object':'chat.completion.chunk',
                           'choices':[{'index':0,'delta':delta,'finish_reason':choice['finish_reason']}]}
                    body=('data: '+json.dumps(chunk,ensure_ascii=False)+'\n\ndata: [DONE]\n\n').encode('utf-8')
                    mime='text/event-stream'
                else:
                    body=json.dumps(result,ensure_ascii=False).encode('utf-8')
                    mime='application/json'
                self.send_response(200)
                self.send_header('Content-Type',mime)
                self.send_header('Content-Length',str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            except Exception as exc:
                try:
                    body=json.dumps({'error':{'message':str(exc),'type':'agent_error'}}).encode('utf-8')
                    self.send_response(502)
                    self.send_header('Content-Type','application/json')
                    self.send_header('Content-Length',str(len(body)))
                    self.end_headers()
                    self.wfile.write(body)
                except OSError:
                    pass
    server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
    server.daemon_threads=True
    thread=threading.Thread(target=server.serve_forever,daemon=True)
    thread.start()
    key='orchestrator-agent'
    config={'model':key+'/'+profile['model'],'small_model':key+'/'+profile['model'],
            'compaction':{'reserved':min(2048,max(256,profile.get('context',8192)//8))},
            'provider':{key:{'npm':'@ai-sdk/openai-compatible','name':'Агент оркестратора',
                'options':{'baseURL':f'http://127.0.0.1:{server.server_port}/v1','apiKey':token},
                'models':{profile['model']:{'name':profile['label'],'limit':{'context':context,'output':output}}}}}}
    try:
        yield json.dumps(config,ensure_ascii=False)
    finally:
        server.shutdown()
        server.server_close()
        thread.join(2)
