"""Two independent API profiles; keys protected with Windows DPAPI."""
import base64
import ctypes
from ctypes import wintypes
import json
import threading
import uuid
from urllib.parse import urlsplit
from orchestrator.config import SETTINGS

_lock=threading.RLock()

class Blob(ctypes.Structure):
    _fields_=[('size',wintypes.DWORD),('data',ctypes.POINTER(ctypes.c_byte))]


def protect(value, decrypt=False):
    try:
        data=base64.b64decode(value,validate=True) if decrypt else value.encode('utf-8')
    except (ValueError,TypeError):
        raise ValueError('Сохранённый API-ключ повреждён. Введите ключ заново.') from None
    buffer=ctypes.create_string_buffer(data)
    source=Blob(len(data),ctypes.cast(buffer,ctypes.POINTER(ctypes.c_byte)))
    result=Blob()
    crypt=ctypes.WinDLL('crypt32',use_last_error=True)
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    blob_pointer=ctypes.POINTER(Blob)
    crypt.CryptProtectData.argtypes=[blob_pointer,wintypes.LPCWSTR,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,wintypes.DWORD,blob_pointer]
    crypt.CryptProtectData.restype=wintypes.BOOL
    crypt.CryptUnprotectData.argtypes=[blob_pointer,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,wintypes.DWORD,blob_pointer]
    crypt.CryptUnprotectData.restype=wintypes.BOOL
    kernel.LocalFree.argtypes=[ctypes.c_void_p]
    kernel.LocalFree.restype=ctypes.c_void_p
    if decrypt:
        success=crypt.CryptUnprotectData(ctypes.byref(source),None,None,None,None,1,ctypes.byref(result))
    else:
        success=crypt.CryptProtectData(ctypes.byref(source),'Orchestrator API',None,None,None,1,ctypes.byref(result))
    if not success:
        raise OSError('Не удалось защитить API-ключ средствами Windows')
    try:
        raw=ctypes.string_at(result.data,result.size)
        return raw.decode('utf-8') if decrypt else base64.b64encode(raw).decode('ascii')
    finally:
        kernel.LocalFree(ctypes.cast(result.data,ctypes.c_void_p))


def path():
    return SETTINGS.path('sessions_db').parent/'api-connections.json'


def read():
    try:
        data=json.loads(path().read_text(encoding='utf-8'))
        return data if isinstance(data,dict) else {}
    except FileNotFoundError:
        return {}


def public(role):
    row=read().get(role,{})
    result={**{k:v for k,v in row.items() if k!='protected_key'},'has_key':bool(row.get('protected_key'))}
    if all(k in result for k in ('context','max_output_tokens','input_budget')):result['input_budget']=effective_input_budget(result)
    return result


def private(role):
    row=read().get(role,{})
    validated,_=validate(row)
    return {**validated, 'api_key':protect(row['protected_key'],True) if row.get('protected_key') else ''}


def validate(data):
    if not isinstance(data,dict) or type(data.get('enabled')) is not bool:
        raise ValueError('Некорректные настройки подключения')
    row={key:data.get(key,'') for key in ('url','model')}
    row['enabled']=data['enabled']
    row['format']='openai-compatible'
    for key,default in [('context',131072),('input_budget',32000),('max_output_tokens',2000)]:
        value=data.get(key,default)
        if type(value) is not int or not 1<=value<=2000000:
            raise ValueError('Лимиты токенов должны быть положительными числами')
        row[key]=value
    if row['input_budget']+row['max_output_tokens']>row['context']:
        raise ValueError('Бюджет входа и лимит ответа превышают окно контекста')
    for key in ('url','model'):
        if not isinstance(row[key],str) or len(row[key])>1000:
            raise ValueError('Некорректный адрес или имя модели')
        row[key]=row[key].strip()
    if row['enabled']:
        parsed=urlsplit(row['url'])
        if parsed.scheme not in ('http','https') or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise ValueError('Укажите базовый URL API без ключей, query и fragment, например https://server/v1')
        if parsed.path.rstrip('/').endswith('/chat/completions'):
            raise ValueError('Укажите базовый URL до /chat/completions, например https://server/v1')
        if not row['model'] or any(ord(ch)<32 for ch in row['model']):
            raise ValueError('Укажите точный идентификатор модели')
        row['url']=row['url'].rstrip('/')
    key=data.get('api_key','')
    if not isinstance(key,str) or len(key)>8192 or '\n' in key or '\r' in key:
        raise ValueError('Некорректный API-ключ')
    return row,key.strip()


def candidate(role,data):
    if role not in ('brain','agent'):
        raise ValueError('Неизвестная роль подключения')
    row,key=validate(data)
    old=read().get(role,{})
    if data.get('clear_key'):
        key=''
    elif not key:
        if urlsplit(old.get('url','')).netloc!=urlsplit(row['url']).netloc and old.get('protected_key'):
            raise ValueError('Для нового сервера введите ключ заново или очистите сохранённый ключ')
        key=protect(old['protected_key'],True) if old.get('protected_key') else ''
    return {**row,'api_key':key}


def save(data):
    with _lock:
        profiles=read()
        replacements={}
        for role in ('brain','agent'):
            if role not in data:
                continue
            row=candidate(role,data[role])
            key=row.pop('api_key')
            row['protected_key']=protect(key) if key else ''
            replacements[role]=row
        if not replacements:
            raise ValueError('Нет настроек для сохранения')
        profiles.update(replacements)
        target=path()
        target.parent.mkdir(parents=True,exist_ok=True)
        temporary=target.with_name(target.name+'.'+uuid.uuid4().hex+'.tmp')
        temporary.write_text(json.dumps(profiles,ensure_ascii=False,indent=2),encoding='utf-8')
        temporary.replace(target)
    return {role:public(role) for role in ('brain','agent')}


def effective_input_budget(profile):
    """Use the configured model window; retain room for protocol overhead/output."""
    if not SETTINGS.section('orchestration').get('cloud_full_context',True):
        return profile['input_budget']
    window=profile['context']
    guard=min(4096,max(256,window//100))
    return max(1,window-profile['max_output_tokens']-guard)
