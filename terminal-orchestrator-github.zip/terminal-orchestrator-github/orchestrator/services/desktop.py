"""Local desktop API. Models and execution remain in shared services."""
import asyncio
import os
import sys
import subprocess
import ctypes
import hmac
import json
import re
import secrets
import threading
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

from orchestrator.config import SETTINGS
from orchestrator.models.session import Session, Message
from orchestrator.prompts import SYSTEM_PROMPT
from orchestrator.services.executor import run_opencode, run_review, resolve_project, ExecutionResult
from orchestrator.services.llm.groq import GroqLLM
from orchestrator.services.llm.gemini import GeminiLLM
from orchestrator.services.memory import load_memory, save_memory, list_projects
from orchestrator.services.runner import run_turn
from orchestrator.services.context import ConversationContext
from orchestrator.services.resources import ResourceMonitor
from orchestrator.services.agent import catalog as agent_catalog
from orchestrator.services import connections, executors, routing, brain_chain, model_registry, access
from orchestrator.services.llm.compatible import CompatibleLLM
from orchestrator.services.llm.factory import create_model
from orchestrator.services.preferences import read_preferences, save_preferences
from orchestrator.utils.parser import parse_command, split_files


class ApiError(ValueError):
    def __init__(self, text, status=400):
        super().__init__(text)
        self.status = status


@dataclass
class Task:
    session_id: int
    project: str
    llm: object
    model_label: str
    id: str = field(default_factory=lambda: uuid.uuid4().hex)
    cancelled: threading.Event = field(default_factory=threading.Event)
    status: str = 'running'
    phase: str = 'Подготовка'
    step: int = 0
    context_info: dict = field(default_factory=dict)
    agent: dict = field(default_factory=dict)
    agent_connection: dict = field(default_factory=dict, repr=False)
    executor_kind: str = "opencode"
    native_model: str = ""
    hermes_memory: bool = True
    executor_timeout: int = 300
    routing_config: dict = field(default_factory=dict)
    route_reason: str = ""
    brain_settings: dict = field(default_factory=dict)
    brain_index: int = 0
    context_limit: int = 131072

    def public(self):
        return {'id':self.id, 'session_id':self.session_id, 'status':self.status,
                'phase':self.phase, 'step':self.step, 'model':self.model_label, 'context':self.context_info, 'agent':self.agent, 'executor':self.executor_kind, 'device':getattr(self.llm,'device',None)}


class DesktopService:
    def __init__(self, model_factory=None, executor=None, reviewer=None):
        self.models = SETTINGS.models()
        self.agent_models = agent_catalog()
        self.default_model = next((i for i,m in enumerate(self.models)
                                  if m[1] == SETTINGS.section('llm')['default']
                                  and m[2] == SETTINGS.provider(m[1])['model']), 0)
        self.model_factory = model_factory or self._model
        self.executor = executor or run_opencode
        self.reviewer = reviewer or run_review
        self.lock = threading.RLock()
        self.active = None
        self.last_tasks = {}
        self.thread = None
        self.closed = False
        self.resources = ResourceMonitor()
        self.revision = 0
        self.preferences_path = SETTINGS.path('sessions_db').parent / 'ui-preferences.json'
        try:
            self.preferences = json.loads(self.preferences_path.read_text(encoding='utf-8'))
            if not isinstance(self.preferences, dict):
                self.preferences = {}
        except (OSError, ValueError):
            self.preferences = {}
        self._reload_connections()
        self.update_status={'active':False,'message':'Ручное обновление','results':[]}
        self.maintenance_cancel=threading.Event()
        self.executor_catalog=executors.catalog()
        from orchestrator.services.android_build import AndroidBuilder
        import shutil
        sdk=Path(os.environ.get('ANDROID_SDK_ROOT') or os.environ.get('ANDROID_HOME') or Path.home()/'AppData/Local/Android/Sdk')
        signer=next(iter(sorted((sdk/'build-tools').glob('*/apksigner.bat'),reverse=True)),None)
        self.android_builder=AndroidBuilder(lambda project:(access.approve_execution(['gradle'],project),resolve_project(project))[1],SETTINGS.path('logs_dir')/'android',adb_path=shutil.which('adb') or str(sdk/'platform-tools/adb.exe'),apksigner_path=str(signer) if signer else None)
        self.auto_thread=threading.Thread(target=self._auto_updates,daemon=True)
        self.auto_thread.start()

    def _auto_updates(self):
        while not self.maintenance_cancel.wait(60):
            self.check_auto_updates()

    def check_auto_updates(self):
        if self.preferences.get('agent_updates','manual')!='auto':
            return False
        if time.time()-self.preferences.get('agent_update_at',0)<86400:
            return False
        try:
            self.update_executors('all')
            return True
        except ApiError:
            return False

    def update_executors(self,kind):
        if hasattr(self,'android_builder') and self.android_builder.state().get('active'):raise ApiError('Дождитесь Android-сборки',409)
        if kind!='all' and kind not in executors.SPECS:
            raise ApiError('Неизвестный исполнитель')
        with self.lock:
            if hasattr(self,'android_builder') and self.android_builder.state().get('active'):raise ApiError('Дождитесь Android-сборки',409)
            if self.closed or self.active or self.update_status['active']:
                raise ApiError('Дождитесь завершения задачи или обновления',409)
            rows=executors.catalog()
            targets=[r['id'] for r in rows if r['can_update'] and (kind=='all' or r['id']==kind)]
            if not targets:
                self.update_status={'active':False,'message':'Нет исполнителей для обновления','results':[]}
                raise ApiError('Исполнитель не установлен или обновляется другим приложением')
            self.preferences=save_preferences({'agent_update_at':time.time()})
            self.update_status={'active':True,'message':'Обновляю исполнителей…','results':[]}
            try:
                threading.Thread(target=self._update_worker,args=(targets,),daemon=True).start()
            except RuntimeError:
                self.update_status={'active':False,'message':'Не удалось запустить обновление','results':[]}
                raise ApiError('Не удалось запустить обновление') from None
        return self.maintenance_state()

    def _update_worker(self,targets):
        try:
            for kind in targets:
                if self.maintenance_cancel.is_set():
                    break
                with self.lock:
                    self.update_status['message']='Обновляю '+executors.SPECS[kind][0]+'…'
                result=executors.update_agent(kind,self.maintenance_cancel)
                with self.lock:
                    self.update_status['results'].append({'id':kind,'ok':result.ok,
                        'message':'Обновлён / уже актуален' if result.ok else result.error or 'Обновление не выполнено; см. журнал',
                        'log':Path(result.log_path).name if result.log_path else ''})
        except Exception:
            with self.lock:
                self.update_status['results'].append({'id':'update','ok':False,'message':'Ошибка обновления; прежние настройки сохранены'})
        finally:
            with self.lock:
                self.executor_catalog=executors.catalog()
                self.update_status['active']=False
                self.update_status['message']='Обновление завершено' if all(r['ok'] for r in self.update_status['results']) else 'Обновление завершено с ошибками'

    def maintenance_state(self):
        with self.lock:
            return {'executors':[dict(r) for r in self.executor_catalog],
                    'update':{**self.update_status,'results':list(self.update_status['results'])}}

    def _reload_connections(self):
        self.models=SETTINGS.models()
        self.agent_models=agent_catalog()
        self.models.extend(model_registry.brain_rows())
        self.agent_models.extend(model_registry.agent_rows())
        brain=connections.public('brain')
        agent=connections.public('agent')
        if brain.get('enabled'):
            self.models.append(('API мозга: '+brain['model'],'api',brain['model'],brain['context']))
        if agent.get('enabled'):
            self.agent_models.append({**agent,'model':'api-agent','actual_model':agent['model'],'provider':'api','label':'API агента: '+agent['model']})

    def configure_connections(self,data):
        if hasattr(self,'android_builder') and self.android_builder.state().get('active'):raise ApiError('Дождитесь Android-сборки',409)
        with self.lock:
            if hasattr(self,'android_builder') and self.android_builder.state().get('active'):raise ApiError('Дождитесь Android-сборки',409)
            if self.active:
                raise ApiError('Дождитесь завершения задачи',409)
            connections.save(data)
            self._reload_connections()
        return {'ok':True,'connections':{role:connections.public(role) for role in ('brain','agent')}}

    def test_connection(self,data):
        profile=connections.candidate(data.get('role'),data.get('profile'))
        if not profile.get('enabled'):
            raise ApiError('Включите API-подключение')
        client=CompatibleLLM(profile)
        client.max_output_tokens=min(64,client.max_output_tokens)
        client.timeout=25
        result=client.chat([{'role':'user','content':'Reply with OK.'}])
        if result.startswith('[ERR]'):
            raise ApiError(result)
        return {'ok':True,'message':'API ответил. Для агента дополнительно требуется поддержка tools.'}

    def _model(self, index):
        if not self.models:
            raise ApiError("Добавьте подключение ИИ в настройках")
        row = self.models[index]
        if row[1]=='api':
            return CompatibleLLM(connections.private('brain'))
        client=create_model(row, self.preferences.get('local_device', SETTINGS.provider('ollama')['device']))
        if row[1] in ('groq','gemini'):
            client.input_budget=connections.effective_input_budget({'context':row[3],'max_output_tokens':client.max_output_tokens,'input_budget':getattr(client,'input_budget',SETTINGS.section('orchestration')['context_input_tokens'])})
            client.cloud_full_context=True
        return client

    def get_session(self, sid):
        if type(sid) is not int or sid <= 0:
            raise ApiError('Некорректный номер чата')
        session = Session.get(sid)
        if not session:
            raise ApiError('Чат не найден', 404)
        return session

    def bootstrap(self):
        try:
            projects = list_projects()
        except OSError:
            projects = []
        return {'executors':self.executor_catalog, 'connections':{role:connections.public(role) for role in ('brain','agent')}, 'agents':self.agent_models, 'models':[{'label':m[0], 'model':m[2], 'provider':m[1], 'context':m[3], 'input_budget':next(p['input_budget'] for p in model_registry.public_list() if p['id']==m[2]) if m[1]=='registry' else connections.public('brain')['input_budget'] if m[1]=='api' else connections.effective_input_budget({'context':m[3],'max_output_tokens':SETTINGS.provider(m[1])['max_output_tokens'],'input_budget':SETTINGS.provider(m[1]).get('input_budget',SETTINGS.section('orchestration')['context_input_tokens'])}) if m[1] in ('groq','gemini') else min(SETTINGS.section('orchestration')['context_input_tokens'],int(m[3]*.75)-SETTINGS.provider(m[1])['max_output_tokens'])} for m in self.models],
                'default_model':self.default_model, 'projects':projects,
                'warnings':SETTINGS.startup_issues(), 'max_steps':SETTINGS.section('orchestration')['max_steps'],
                'context_input_tokens':SETTINGS.section('orchestration')['context_input_tokens'],
                'preferences':self.preferences, 'history_messages':SETTINGS.section('orchestration')['history_messages']}

    def set_preferences(self, data):
        if hasattr(self,'android_builder') and self.android_builder.state().get('active'):raise ApiError('Дождитесь Android-сборки',409)
        changes = {}
        if 'brain_execute' in data:
            if type(data['brain_execute']) is not bool:raise ApiError('Некорректный флаг исполнения мозга')
            changes['brain_execute']=data['brain_execute']
        if 'brain_executor_kind' in data:
            kind=data['brain_executor_kind']
            if kind not in executors.SPECS or not executors.SPECS[kind][1]:raise ApiError('Выберите совместимого агента мозга')
            changes['brain_executor_kind']=kind
        if 'brain_settings' in data:
            try:changes['brain_settings']=brain_chain.validate(data['brain_settings'],self.models)
            except ValueError as exc:raise ApiError(str(exc)) from exc
        if 'routing' in data:
            try:
                config={**self.preferences.get('routing',{}),**data['routing']}
                self_exec=data.get('brain_execute',self.preferences.get('brain_execute',False))
                changes['routing']=routing.validate({**config,'mode':'manual'} if self_exec and config.get('mode')=='auto' else config,self.agent_models)
                if self_exec and config.get('mode')=='auto':changes['routing']['mode']='auto'
            except ValueError as exc:
                raise ApiError(str(exc)) from exc
        if 'theme' in data:
            if data['theme'] not in ('dark','light'):
                raise ApiError('Некорректная тема')
            changes['theme'] = data['theme']
        if 'local_device' in data:
            if data['local_device'] not in ('cpu','gpu'):
                raise ApiError('Выберите процессор или видеокарту')
            changes['local_device'] = data['local_device']
        if 'agent_device' in data:
            if data['agent_device'] not in ('cpu','gpu'):
                raise ApiError('Выберите CPU или GPU для агента')
            changes['agent_device']=data['agent_device']
        if 'agent_model' in data:
            if data['agent_model'] not in [m['model'] for m in self.agent_models]:
                raise ApiError('Неизвестная модель агента')
            changes['agent_model']=data['agent_model']
        if 'executor_kind' in data:
            kind=data['executor_kind']
            if kind not in executors.SPECS:
                raise ApiError('Неизвестный исполнитель')
            if kind!='none' and not executors.executable(kind):
                raise ApiError('Исполнитель не установлен или не найден в PATH')
            changes['executor_kind']=kind
        if 'native_agent_model' in data:
            model=data['native_agent_model']
            if not isinstance(model,str) or len(model)>200 or any(ord(c)<32 for c in model):
                raise ApiError('Некорректная модель исполнителя')
            kind=changes.get('executor_kind',self.preferences.get('executor_kind','opencode'))
            models=dict(self.preferences.get('native_agent_models',{}))
            models[kind]=model.strip()
            changes['native_agent_models']=models
        for key in ('hermes_memory',):
            if key in data:
                if type(data[key]) is not bool:
                    raise ApiError('Некорректное значение настройки памяти')
                changes[key]=data[key]
        if 'agent_timeout' in data:
            value=data['agent_timeout']
            if type(value) is not int or not 60<=value<=3600:
                raise ApiError('Время работы исполнителя: от 60 до 3600 секунд')
            changes['agent_timeout']=value
        if 'agent_updates' in data:
            if data['agent_updates'] not in ('manual','auto'):
                raise ApiError('Выберите ручное или автоматическое обновление')
            changes['agent_updates']=data['agent_updates']
        if not changes:
            raise ApiError('Нет настроек для сохранения')
        with self.lock:
            if hasattr(self,'android_builder') and self.android_builder.state().get('active'):raise ApiError('Дождитесь Android-сборки',409)
            if self.active or self.update_status['active']:
                raise ApiError('Дождитесь завершения задачи или обновления',409)
            self.preferences = save_preferences(changes)
        return {'ok':True, 'preferences':self.preferences}

    def state(self, sid=None):
        with self.lock:
            sessions = [{k:v for k,v in row.items() if k != 'context_summary'} for row in Session.get_all(include_archived=True)]
            messages = Message.get_by_session(sid, limit=200) if sid and Session.get(sid) else []
            for message in messages:
                try:
                    message['metadata'] = json.loads(message.pop('metadata_json', '{}'))
                except (ValueError, TypeError):
                    message['metadata'] = {}
            selected = Session.get(sid) if sid else None
            return {'sessions':sessions, 'messages':messages, 'revision':self.revision,
                    'context_summary':selected.get('context_summary','') if selected else '',
                    'active':self.active.public() if self.active else None,
                    'task':self.last_tasks[sid].public() if sid in self.last_tasks else None}

    def new_session(self, project=''):
        if not isinstance(project, str):
            raise ApiError('Некорректный проект')
        if project:
            resolve_project(project)
        with self.lock:
            sid = Session.create('Новый чат', project)
            self.revision += 1
        return {'id':sid}

    def mutate_session(self, sid, action, data):
        with self.lock:
            session = self.get_session(sid)
            if action == 'rename':
                name = data.get('name', '')
                if not isinstance(name, str) or not 1 <= len(name.strip()) <= 100:
                    raise ApiError('Название должно содержать от 1 до 100 символов')
                Session.rename(sid, name.strip())
            elif action == 'archive':
                archived = data.get('archived')
                if type(archived) is not bool:
                    raise ApiError('Некорректный статус архива')
                Session.set_archived(sid, archived)
            elif action == 'delete':
                if self.active and self.active.session_id == sid:
                    raise ApiError('Сначала остановите задачу и дождитесь завершения', 409)
                if data.get('confirmed') is not True:
                    raise ApiError('Удаление не подтверждено')
                Session.delete(sid)
                self.last_tasks.pop(sid, None)
            elif action == 'memory':
                messages = Message.get_by_session(sid, limit=10)
                if not messages:
                    raise ApiError('В чате пока нет сообщений')
                summary = '\n'.join(f"[{m['role']}]: {m['text'][:500]}" for m in messages)
                if not save_memory(session['project'], summary):
                    raise ApiError('Не удалось сохранить память проекта', 500)
            else:
                raise ApiError('Неизвестное действие', 404)
            self.revision += 1
        return {'ok':True}

    @staticmethod
    def _is_execution(message):
        try:
            metadata = json.loads(message.get('metadata_json') or '{}')
            return isinstance(metadata, dict) and metadata.get('kind') == 'execution'
        except (ValueError, TypeError):
            return False

    def start(self, sid, text, model_index, compact=False):
        if not compact and (not isinstance(text, str) or not text.strip() or len(text) > 50000):
            raise ApiError('Сообщение должно содержать от 1 до 50 000 символов')
        if type(model_index) is not int or not 0 <= model_index < len(self.models):
            raise ApiError('Выберите модель из списка')
        with self.lock:
            if self.closed:
                raise ApiError('Приложение закрывается', 409)
            if self.update_status['active']:
                raise ApiError('Дождитесь завершения обновления исполнителей',409)
            if self.android_builder.state().get('active'):raise ApiError('Дождитесь Android-сборки',409)
            if self.active:
                raise ApiError('Уже выполняется задача. Дождитесь завершения или остановите её.', 409)
            session = self.get_session(sid)
            if session.get('project') and access.state()['mode']!='none':resolve_project(session['project'])
            if session.get('archived'):
                raise ApiError('Сначала верните чат из архива', 409)
            task = Task(sid, session['project'], self.model_factory(model_index), self.models[model_index][0], context_limit=self.models[model_index][3])
            task.brain_index=model_index
            task.brain_settings=dict(self.preferences.get('brain_settings',{}))
            routing_config=self.preferences.get('routing',{})
            self_exec=self.preferences.get('brain_execute',False)
            task.routing_config=routing.validate({**routing_config,'mode':'manual'} if self_exec and routing_config.get('mode')=='auto' else routing_config,self.agent_models)
            if self_exec and routing_config.get('mode')=='auto':task.routing_config['mode']='auto'
            task.executor_kind=self.preferences.get('executor_kind','opencode')
            task.native_model=self.preferences.get('native_agent_models',{}).get(task.executor_kind,'')
            task.hermes_memory=self.preferences.get('hermes_memory',True)
            task.executor_timeout=self.preferences.get('agent_timeout',900 if task.executor_kind=='hermes' else SETTINGS.section('executor')['timeout'])
            selected_agent=self.preferences.get('agent_model','')
            task.agent=dict(next((m for m in self.agent_models if m['model']==selected_agent),self.agent_models[0]))
            task.agent['device']=self.preferences.get('agent_device','cpu')
            if not self.preferences.get('brain_execute') and task.agent.get('provider')=='api' and executors.SPECS[task.executor_kind][1]:
                task.agent_connection={**(model_registry.private_profile(task.agent['registry_id']) if task.agent.get('registry_id') else connections.private('agent')),'provider':'api','label':task.agent['label']}
                task.agent['model']=task.agent['actual_model']
                task.agent['device']='api'
            if not executors.SPECS[task.executor_kind][1]:
                task.agent={'model':task.native_model or 'Собственные настройки CLI','device':'настройки CLI','url':'настройки CLI','label':executors.SPECS[task.executor_kind][0]}
                task.agent_connection={}
            if self.preferences.get('brain_execute'):
                row=self.models[model_index]
                task.executor_kind=self.preferences.get('brain_executor_kind','hermes')
                if not executors.executable(task.executor_kind):raise ApiError('Агент мозга не установлен')
                if row[1]=='registry' and model_registry.private_profile(row[2]).get('brain_only'):raise ApiError('Эта модель разрешена только для мозга; снимите ограничение в каталоге для самостоятельного исполнения')
                client=task.llm
                profile={**brain_chain.hermes_connection(client,row,self.preferences.get('local_device','cpu')),'label':row[0]}
                task.agent={**{k:v for k,v in profile.items() if k!='api_key'},'label':row[0],'device':profile.get('device','api')}
                task.agent_connection=profile if profile['provider']=='api' else {}
                task.native_model=''
                task.brain_self_agent={**task.agent,'model':'brain-self-model','actual_model':profile['model']}
                task.brain_self_connection=dict(task.agent_connection)
                task.brain_self_kind=task.executor_kind
                task.brain_self_timeout=task.executor_timeout
                if task.routing_config['mode']=='auto':
                    task.routing_config['profiles'].append(dict(id='brain-self',kind=task.executor_kind,model='brain-self-model',device=profile.get('device','cpu'),enabled=True,fallback=False,category='general',priority=50,timeout=task.executor_timeout,label='Мозг — самостоятельное выполнение'))
            if task.routing_config['mode']=='auto' and not routing.eligible(task.routing_config,self.agent_models+([task.brain_self_agent] if hasattr(task,'brain_self_agent') else [])):raise ApiError('Нет разрешённых исполнителей: проверьте облачный доступ и агента мозга')
            if not compact and not Message.get_by_session(sid, limit=1) and session['name'] == 'Новый чат':
                Session.rename(sid, text.strip().splitlines()[0][:48])
            if not compact:
                Message.create(sid, 'user', text.strip())
            history = [{'id':m['id'], 'role':'assistant' if m['role'] == 'assistant' else 'user', 'content':m['text'], 'tool_result':self._is_execution(m)}
                       for m in Message.get_by_session(sid, limit=-1) if (m['role'] in ('user','assistant') and not (m['role']=='assistant' and m['text'].startswith('[ERR]'))) or self._is_execution(m)]
            memory = load_memory(task.project) if access.state()['mode']!='none' else ''
            if task.project and task.executor_kind=='hermes' and task.hermes_memory and access.state()['mode']!='none':
                hermes_notes=executors.read_project_memory(resolve_project(task.project))
                if hermes_notes:
                    memory += '\n\nПамять Hermes этого проекта:\n'+hermes_notes
            system = SYSTEM_PROMPT + (f'\n\nПамять проекта:\n{memory}' if memory else '')
            system += f'\n\nФактическая конфигурация: ты — мозг {task.model_label}, модель API {getattr(task.llm, "model", "")}, устройство {getattr(task.llm, "device", "облако")}, адрес {getattr(task.llm, "url", "")}. Агент-исполнитель {executors.SPECS[task.executor_kind][0]}: {task.agent["model"]}, {task.agent["device"].upper()}, {task.agent["url"]}. Это проверенные настройки приложения. На вопросы о выбранной модели отвечай по этим данным, не запускай проверочные скрипты. Не утверждай успех проверки, если вывод содержит ошибку; код 0 оболочки означает только завершение агента.'
            from orchestrator.services import agent_guides
            system += agent_guides.instructions()
            if task.executor_kind=='none' and task.routing_config['mode']!='auto':
                system += '\nИсполнитель отключён. Не выдавай команды выполнения; только обсуждай и составляй планы.'
            if task.routing_config['mode']=='auto':
                system += routing.instructions(task.routing_config,self.agent_models+([task.brain_self_agent] if hasattr(task,'brain_self_agent') else []))
            if task.project:
                system += f'\n\nВыбранный проект: {task.project}. Выполняй задачу в этом проекте.'
            policy=access.state()
            system += '\nПолитика доступа компьютера: '+policy['mode']+'. none — действия запрещены; folder — выбранная папка и отдельные разрешения; ask — по подтверждению; full — постоянный доступ с правами текущего пользователя Windows, не автоматическое повышение до администратора.'
            if not task.project:
                working_folder=policy['folder'] if policy['mode']=='folder' else str(SETTINGS.path('projects_root'))
                system += '\nПроект не выбран: это общий чат управления компьютером. Выбор проекта необязателен. Начальная рабочая папка: '+working_folder+'. Используй абсолютные пути для целей в других местах; рабочая папка не выдаёт прав доступа. Контракты артефактов относительны рабочей папке команды.'
            self.active = task
            self.last_tasks[sid] = task
            self.revision += 1
            self.thread = threading.Thread(target=self._run, args=(task, history, system, compact), daemon=True)
            self.thread.start()
        return task.public()

    def stop(self, task_id):
        with self.lock:
            if not self.active or task_id != self.active.id:
                raise ApiError('Эта задача уже завершена', 409)
            self.active.cancelled.set()
            access.deny_pending()
            self.active.status = 'stopping'
            self.active.phase = 'Остановка текущей операции'
            self.revision += 1
        return {'ok':True}

    def emit(self, task, role, text, metadata=None):
        with self.lock:
            if not Session.get(task.session_id):
                task.cancelled.set()
                return None
            if role == 'assistant' and metadata is None:
                metadata = {'model':task.model_label, 'run_id':task.id}
                try:
                    command = parse_command(text)
                    if command:
                        metadata['command'] = {'action':command[0], 'task':command[1], 'project':command[2]}
                except ValueError:
                    pass
                if text.startswith('[ERR]'):
                    task.status = 'error'
            if role == 'system' and text.startswith('Остановка после'):
                task.status = 'error'
            message_id = Message.create(task.session_id, role, text, metadata)
            self.revision += 1
            return message_id

    def progress(self, task, phase):
        with self.lock:
            if not task.cancelled.is_set():
                task.phase = phase
            self.revision += 1

    async def _ask(self, task, history, system):
        if task.brain_settings:
            return await brain_chain.ask(self,task,history,system)
        response = await asyncio.to_thread(task.llm.chat, history, system)
        if not task.cancelled.is_set() and isinstance(response, str) and response.startswith('[ERR]') and isinstance(task.llm, GeminiLLM):
            self.emit(task, 'system', 'Gemini недоступен. Пробую Groq.')
            response = await asyncio.to_thread(GroqLLM().chat, history, system)
        return response

    async def _execute(self, command, task):
        if task.routing_config.get("mode")=="auto":
            return await routing.execute(self,command,task)
        if command[0]=="delegate":
            return ExecutionResult(error="Автоматическое распределение выключено")
        return await self._execute_manual(command,task)

    async def _execute_manual(self, command, task):
        if task.cancelled.is_set():
            return None
        action, data, project = command
        project = project or task.project
        task.step += 1
        metadata = {'kind':'execution', 'action':action, 'task':data, 'project':project,
                    'executor':task.executor_kind, 'route_reason':task.route_reason, 'step':task.step, 'run_id':task.id, 'status':'running', 'agent':task.agent}
        mid = self.emit(task, 'system', f'Выполнение: {data}', metadata)
        if mid is None:
            return None
        try:
            if task.executor_kind=='none':
                result=ExecutionResult(error='Исполнитель отключён')
            elif action == 'opencode':
                if self.executor is run_opencode:
                    result = await asyncio.to_thread(executors.run_agent, data, project, task.cancelled, agent=task.agent_connection or task.agent, kind=task.executor_kind, native_model=task.native_model, memory=task.hermes_memory, timeout=task.executor_timeout)
                else:
                    result = await asyncio.to_thread(self.executor, data, project, task.cancelled)
            else:
                result = await asyncio.to_thread(self.reviewer, split_files(data), task.cancelled, project)
        except Exception as exc:
            metadata.update(status='error', error=str(exc))
            with self.lock:
                Message.update(mid, f'Ошибка исполнителя: {exc}', metadata)
                self.revision += 1
            raise
        metadata.update(status='cancelled' if result.cancelled else 'success' if result.ok else 'error',
                        returncode=result.returncode, timed_out=result.timed_out, error=result.error,
                        stdout=result.stdout[:12000], stderr=result.stderr[:12000],
                        log=Path(result.log_path).name if result.log_path else '', log_error=result.log_error)
        with self.lock:
            Message.update(mid, result.summary(), metadata)
            self.revision += 1
        task.last_execution_record=(mid,dict(metadata))
        return result

    def update_artifact_result(self,task,result):
        record=getattr(task,'last_execution_record',None)
        if not record:return
        mid,metadata=record
        metadata.update(status='success' if result.ok else 'error',error=result.error,artifact_checks=result.artifact_checks,
                        log=Path(result.log_path).name if result.log_path else '')
        with self.lock:
            Message.update(mid,result.summary(),metadata)
            self.revision+=1

    def _run(self, task, history, system, compact=False):
        def report(info):
            with self.lock:
                task.context_info = info
                if info.get('compacting'):
                    task.phase = 'Сжатие истории'
                self.revision += 1
        def save(summary, through):
            with self.lock:
                if not task.cancelled.is_set():
                    Session.save_context(task.session_id, summary, through)
        session = Session.get(task.session_id)
        manager = ConversationContext(task.context_limit, getattr(task.llm, 'max_output_tokens', 2000),
                                      ({**SETTINGS.section('orchestration'),'context_input_tokens':task.llm.input_budget,'window_fraction':1} if isinstance(task.llm,CompatibleLLM) or getattr(task.llm,'cloud_full_context',False) else SETTINGS.section('orchestration')), session.get('context_summary', ''),
                                      session.get('summary_through', 0), save=save, report=report)
        try:
            if compact:
                asyncio.run(manager.prepare(task, history, system, force=True))
                if not task.cancelled.is_set():
                    changed = manager.through > session.get('summary_through', 0)
                    self.emit(task, 'system', 'Контекст сжат. Свежая задача сохранена полностью; сводка доступна в меню чата.' if changed else 'Нет старой истории для сжатия. Свежая задача сохранена полностью.')
            else:
                async def native_prepare(context, messages, instruction):
                    return messages, instruction
                outcome = asyncio.run(run_turn(history, system, task, self._ask, self._execute, self.emit,
                                     lambda phase:self.progress(task, phase), prepare=native_prepare if task.brain_settings.get("engine")=="claude" else manager.prepare))
                if outcome in ('error','incomplete','unverified','checked'):
                    task.status = outcome
        except Exception as exc:
            task.status = 'error'
            self.emit(task, 'system', f'Ошибка: {exc}')
        finally:
            with self.lock:
                if task.cancelled.is_set():
                    task.status = 'cancelled'
                    self.emit(task, 'system', 'Задача остановлена. Уже выполненные изменения сохранены.')
                elif task.status not in ('error','incomplete','unverified','checked'):
                    task.status = 'done'
                task.phase = {'cancelled':'Остановлено', 'error':'Ошибка', 'done':'Ответ завершён','incomplete':'Задача не завершена','unverified':'Результат требует проверки','checked':'Проверки контракта пройдены'}[task.status]
                self.emit(task,'system',task.phase,{'kind':'task-outcome','status':task.status})
                self.active = None
                self.revision += 1

    def files(self, sid, relative='', read=False):
        session = self.get_session(sid)
        if not session['project']:
            return {'entries':[], 'path':'', 'project':''}
        root = resolve_project(session['project'])
        path = (root / relative).resolve()
        if not path.is_relative_to(root) or any(part.startswith('.') for part in Path(relative).parts):
            raise ApiError('Этот путь недоступен', 403)
        if read:
            if not path.is_file():
                raise ApiError('Файл не найден', 404)
            if path.stat().st_size > 256000:
                raise ApiError('Для просмотра доступны файлы размером до 256 КБ')
            content = path.read_bytes()
            if b'\x00' in content:
                raise ApiError('Этот файл нельзя показать как текст')
            return {'path':str(path.relative_to(root)), 'content':content.decode('utf-8-sig', errors='replace')}
        if not path.is_dir():
            raise ApiError('Папка не найдена', 404)
        entries = []
        for child in sorted(path.iterdir(), key=lambda p:(not p.is_dir(), p.name.lower())):
            if child.name.startswith('.') or child.name in ('node_modules', '__pycache__', 'build', 'dist'):
                continue
            if not child.resolve().is_relative_to(root):
                continue
            entries.append({'name':child.name, 'path':str(child.relative_to(root)).replace('\\','/'), 'directory':child.is_dir()})
            if len(entries) >= 250:
                break
        return {'entries':entries, 'path':relative, 'project':session['project']}

    def log(self, name):
        if not re.fullmatch(r'[a-f0-9]{32}\.json', name):
            raise ApiError('Журнал не найден', 404)
        path = SETTINGS.path('logs_dir') / name
        if not path.is_file():
            raise ApiError('Журнал не найден', 404)
        return json.loads(path.read_text(encoding='utf-8'))

    def close(self):
        if hasattr(self,'android_builder'):self.android_builder.stop()
        self.resources.close()
        self.maintenance_cancel.set()
        with self.lock:
            self.closed = True
            if self.active:
                self.active.cancelled.set()
            access.deny_pending()


def make_server(service, assets, port=0):
    token = secrets.token_urlsafe(32)
    assets = Path(assets)
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def reply(self, value, status=200):
            self.send_bytes(json.dumps(value, ensure_ascii=False).encode('utf-8'), 'application/json; charset=utf-8', status)

        def send_bytes(self, data, mime, status=200):
            self.send_response(status)
            self.send_header('Content-Type', mime)
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            ancestors="self" if urlsplit(self.path).path in ("/help.html","/help-en.html","/help-zh.html") else "none"
            self.send_header('Content-Security-Policy', f"default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; frame-ancestors '{ancestors}'; base-uri 'none'")
            self.end_headers()
            self.wfile.write(data)

        def dispatch(self, post=False):
            try:
                self.connection.settimeout(10)
                host = f'127.0.0.1:{self.server.server_port}'
                if self.headers.get('Host') != host:
                    raise ApiError('Недопустимый адрес', 403)
                parsed = urlsplit(self.path)
                route = parsed.path
                if route.startswith('/api/'):
                    if not hmac.compare_digest(self.headers.get('Authorization', ''), 'Bearer ' + token):
                        raise ApiError('Нет доступа к приложению', 401)
                    origin = self.headers.get('Origin')
                    if origin and origin != 'http://' + host:
                        raise ApiError('Недопустимый источник запроса', 403)
                elif not post:
                    static = {'/':'index.html', '/app.js':'app.js', '/style.css':'style.css', '/help.html':'help.html', '/help-en.html':'help-en.html', '/help-zh.html':'help-zh.html', '/i18n.js':'i18n.js'}
                    if route not in static:
                        raise ApiError('Не найдено', 404)
                    mime = {'/':'text/html; charset=utf-8', '/app.js':'text/javascript; charset=utf-8', '/style.css':'text/css; charset=utf-8', '/help.html':'text/html; charset=utf-8', '/help-en.html':'text/html; charset=utf-8', '/help-zh.html':'text/html; charset=utf-8', '/i18n.js':'text/javascript; charset=utf-8'}[route]
                    self.send_bytes((assets/static[route]).read_bytes(), mime)
                    return
                else:
                    raise ApiError('Не найдено', 404)
                query = parse_qs(parsed.query)
                sid = int(query['session_id'][0]) if 'session_id' in query else None
                if post:
                    if self.headers.get('Content-Type', '').split(';')[0] != 'application/json':
                        raise ApiError('Нужен JSON-запрос', 415)
                    length = int(self.headers.get('Content-Length', '0'))
                    if not 0 < length <= 200000:
                        raise ApiError('Некорректный размер запроса', 413)
                    data = json.loads(self.rfile.read(length))
                    if not isinstance(data, dict):
                        raise ApiError('Некорректный запрос')
                    if route == '/api/app/exit':
                        value={'ok':True,'message':'Терминал завершается. Для обычных прав запустите START.cmd из Проводника.'}
                        service.closed=True
                        def shutdown_copy():
                            service.close();self.server.shutdown()
                        threading.Timer(1,shutdown_copy).start()
                    elif route == '/api/android/build':
                        with service.lock:
                            if service.closed or service.active or service.update_status['active']:raise ApiError('Дождитесь завершения работы',409)
                            access.check_execution()
                            value=service.android_builder.start(data.get('project',''),data.get('variant','debug'),data.get('install',False))
                    elif route in ('/api/custom-agents/save','/api/custom-agents/delete','/api/custom-agents/restore'):
                        from orchestrator.services import custom_agents
                        with service.lock:
                            if service.active or service.update_status['active']:raise ApiError('Дождитесь завершения работы',409)
                            if route.endswith('/save'):custom_agents.save(data)
                            elif route.endswith('/restore'):custom_agents.set_builtin(data.get('id'),False)
                            else:
                                ident=data.get('id')
                                prefs=service.preferences
                                if ident in (prefs.get('executor_kind'),prefs.get('brain_executor_kind')) or any(p.get('kind')==ident for p in prefs.get('routing',{}).get('profiles',[])):raise ApiError('Сначала уберите агента из настроек исполнителей')
                                if isinstance(ident,str) and ident.startswith('custom-'):custom_agents.delete(ident)
                                else:custom_agents.set_builtin(ident,True)
                            executors.refresh_custom()
                            value={'agents':custom_agents.rows(),'executors':executors.catalog()}
                    elif route == '/api/android/stop':
                        value=service.android_builder.stop()
                    elif route.startswith('/api/model-registry/'):
                        with service.lock:
                            if service.active or service.update_status['active']:raise ApiError('Дождитесь завершения работы',409)
                            if route.endswith('/test'):
                                client=CompatibleLLM(model_registry.candidate(data));client.max_output_tokens=64;client.timeout=25
                                answer=client.chat([{'role':'user','content':'Reply with OK.'}])
                                if answer.startswith('[ERR]'):raise ApiError(answer)
                            elif route.endswith('/save'):model_registry.save_profile(data)
                            elif route.endswith('/delete'):model_registry.delete_profile(data.get('id'))
                            else:raise ApiError('Неизвестная операция',404)
                            service._reload_connections()
                            prefs=dict(service.preferences)
                            valid_brains={brain_chain.key(row) for row in service.models}
                            bs=dict(prefs.get('brain_settings',{}))
                            if bs:
                                bs['primary']=bs.get('primary') if bs.get('primary') in valid_brains else brain_chain.key(service.models[service.default_model])
                                bs['fallbacks']=[v for v in bs.get('fallbacks',[]) if v in valid_brains and v!=bs['primary']]
                                if bs.get('hermes_model') and bs['hermes_model'] not in valid_brains:bs.update(hermes=False,hermes_model='')
                                prefs['brain_settings']=bs
                            valid_agents={row['model'] for row in service.agent_models}
                            rc=dict(prefs.get('routing',{}));rc['profiles']=[{**row,'enabled':False} if executors.SPECS[row['kind']][1] and row['model'] not in valid_agents else row for row in rc.get('profiles',[])]
                            if rc.get('mode')=='auto' and not routing.eligible(rc,service.agent_models):rc['mode']='manual'
                            prefs['routing']=rc
                            if prefs.get('agent_model') not in valid_agents:prefs['agent_model']=service.agent_models[0]['model'] if service.agent_models else ''
                            service.preferences=save_preferences(prefs)
                            value={'ok':True,'profiles':model_registry.public_list(),'message':'API ответил' if route.endswith('/test') else 'Сохранено'}
                    elif route == '/api/access/decision':
                        value=access.decide(data.get('id'),data.get('allowed'),data.get('always',False))
                    elif route == '/api/access':
                        with service.lock:
                            if service.active or service.update_status['active'] or getattr(service,'android_builder',None) and service.android_builder.state().get('active'):raise ApiError('Дождитесь завершения работы',409)
                            value=access.save(data)
                    elif route == '/api/access/pick-folder':
                        if os.environ.get('ORCHESTRATOR_DISABLE_DIALOGS')=='1':raise ApiError('Диалоги отключены')
                        output=SETTINGS.path('sessions_db').parent/'.runtime'/('folder-'+uuid.uuid4().hex+'.txt')
                        cmd=[sys.executable] if getattr(sys,'frozen',False) else [sys.executable,str(Path(__file__).resolve().parents[2]/'desktop.py')]
                        result=subprocess.run(cmd+['--pick-folder-output',str(output)],timeout=120,capture_output=True)
                        value={'folder':output.read_text(encoding='utf-8') if output.exists() else ''}
                        output.unlink(missing_ok=True)
                    elif route == '/api/access/elevate':
                        with service.lock:
                            if service.active or service.update_status['active'] or getattr(service,'android_builder',None) and service.android_builder.state().get('active'):raise ApiError('Дождитесь завершения работы',409)
                            if access.elevated():raise ApiError('Терминал уже работает от администратора')
                            access.check_execution()
                            if not getattr(sys,'frozen',False):raise ApiError('Повышение прав доступно в собранном EXE')
                            args=subprocess.list2cmdline(['--config',str(SETTINGS.source),'--wait-pid',str(os.getpid()),'--keep-running'])
                            shell=ctypes.windll.shell32.ShellExecuteW;shell.argtypes=[ctypes.c_void_p,ctypes.c_wchar_p,ctypes.c_wchar_p,ctypes.c_wchar_p,ctypes.c_wchar_p,ctypes.c_int];shell.restype=ctypes.c_void_p
                            result=shell(None,'runas',sys.executable,args,str(SETTINGS.source.parent),1)
                            if not result or result<=32:raise ApiError('Повышение прав отменено или недоступно')
                            service.closed=True
                            value={'ok':True,'message':'Подтвердите Windows UAC; терминал откроется заново.'}
                            def shutdown_for_elevation():
                                service.close();self.server.shutdown()
                            threading.Timer(1,shutdown_for_elevation).start()
                    elif route == '/api/sessions':
                        value = service.new_session(data.get('project', ''))
                    elif route == '/api/send':
                        value = service.start(data.get('session_id'), data.get('text'), data.get('model'))
                    elif route == '/api/compact':
                        value = service.start(data.get('session_id'), None, data.get('model'), compact=True)
                    elif route == '/api/stop':
                        value = service.stop(data.get('task_id'))
                    elif route in ('/api/heartbeat', '/api/gone'):
                        self.server.last_seen = time.monotonic()
                        self.server.connected = True
                        self.server.gone_at = time.monotonic() if route.endswith('gone') else None
                        value = {'ok':True}
                    elif route == '/api/connections':
                        value = service.configure_connections(data)
                    elif route == '/api/connections/test':
                        value = service.test_connection(data)
                    elif route == '/api/executors/update':
                        value = service.update_executors(data.get('executor','all'))
                    elif route == '/api/executors/refresh':
                        service.executor_catalog=executors.catalog()
                        value = service.maintenance_state()
                    elif route == '/api/preferences':
                        value = service.set_preferences(data)
                    elif match := re.fullmatch(r'/api/session/(\d+)/(rename|archive|delete|memory)', route):
                        value = service.mutate_session(int(match[1]), match[2], data)
                    else:
                        raise ApiError('Не найдено', 404)
                elif route == '/api/android/state':
                    value=service.android_builder.state()
                elif route == '/api/model-registry':
                    value={'profiles':model_registry.public_list()}
                elif route == '/api/access/requests':
                    value={'requests':access.requests()}
                elif route == '/api/access':
                    value=access.state()
                elif route == '/api/custom-agents':
                    from orchestrator.services import custom_agents
                    value={'agents':custom_agents.rows(),'catalog':custom_agents.listing()}
                elif route == '/api/bootstrap':
                    self.server.last_seen = time.monotonic()
                    self.server.connected = True
                    self.server.gone_at = None
                    value = service.bootstrap()
                elif route == '/api/executors':
                    value = service.maintenance_state()
                elif route == '/api/resources':
                    value = {'hosts':service.resources.snapshot()}
                elif route == '/api/state':
                    value = service.state(sid)
                elif route in ('/api/files', '/api/file'):
                    value = service.files(sid, query.get('path', [''])[0], route.endswith('/file'))
                elif route == '/api/log':
                    value = service.log(query.get('name', [''])[0])
                else:
                    raise ApiError('Не найдено', 404)
                self.reply(value)
            except ApiError as exc:
                self.reply({'error':str(exc)}, exc.status)
            except (ValueError, TypeError, KeyError) as exc:
                self.reply({'error':str(exc)}, 400)
            except OSError:
                self.reply({'error':'Не удалось прочитать или сохранить файл'}, 500)
            except Exception:
                self.reply({'error':'Ошибка приложения. Перезапустите его и попробуйте снова.'}, 500)

        def do_GET(self):
            self.dispatch()

        def do_POST(self):
            self.dispatch(True)

    server = ThreadingHTTPServer(('127.0.0.1', port), Handler)
    server.daemon_threads = True
    server.last_seen = time.monotonic()
    server.gone_at = None
    server.connected = False
    server.token = token
    return server
