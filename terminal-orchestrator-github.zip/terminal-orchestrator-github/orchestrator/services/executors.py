"""Known local CLI executors. Fixed argv only; no shell command templates."""
import hashlib
import re
import json
import os
import shutil
import threading
import time
import uuid
import urllib.request
from pathlib import Path
from contextlib import contextmanager
from orchestrator.config import SETTINGS
from orchestrator.services.executor import _run, _save_result, ExecutionResult, resolve_project, run_opencode
from orchestrator.services.agent import agent_provider

SPECS={
    'claude-api':('Claude Code · API',True,'Выбранная API-модель через Anthropic Messages: LLM Router или DeepSeek. Авторизация только из профиля.'),
    'harness':('DeepSeek Harness',True,'Исполнитель с выбранной локальной/API моделью; workspace-write в проекте.'),
    'opencode':('OpenCode',True,'Выбранная модель агента; локальная или API.'),
    'hermes':('Hermes Agent',True,'Выбранная модель агента. Память и история отдельно для каждого проекта.'),
    'claude':('Claude Code',False,'Собственные настройки Claude Code и его авторизация.'),
    'codex':('Codex CLI',False,'Собственные настройки Codex и его авторизация; sandbox workspace-write.'),
    'aider':('Aider',True,'Выбранная модель агента; изменения без автоматических коммитов.'),
    'kimi':('Kimi Code',False,'Собственные настройки Kimi Code и его авторизация.'),
    'none':('Без исполнителя',False,'Только разговор с мозгом; выполнение команд отключено.'),
}


def refresh_custom():
    from orchestrator.services import custom_agents
    for key in list(SPECS):
        if key.startswith('custom-'):del SPECS[key]
    for row in custom_agents.rows():SPECS[row['id']]=(row['label'],False,'Пользовательский CLI; собственная авторизация и модель. '+row['instructions'])

refresh_custom()


def runtime():
    return SETTINGS.path('sessions_db').parent/'.runtime'


def executable(kind,include_removed=False):
    from orchestrator.services import custom_agents
    if not include_removed and kind in custom_agents.hidden():return None
    if kind.startswith('custom-'):
        from orchestrator.services import custom_agents
        row=custom_agents.get(kind)
        return custom_agents.executable(row) if row else None
    if kind not in SPECS or kind=='none':
        return None
    if kind=='claude-api':return executable('claude',include_removed=True)
    if kind=='harness':
        from orchestrator.services.harness_brain import executable as harness_executable
        return harness_executable()
    if kind=='hermes':
        managed=Path(SETTINGS.section('executor').get('hermes_executable') or runtime()/'hermes-env314/Scripts/hermes.exe')
        if managed.is_file():
            return str(managed)
    return shutil.which(kind+'.cmd') or shutil.which(kind+'.exe') or shutil.which(kind)


def catalog():
    rows=[]
    from orchestrator.services import custom_agents
    hidden=custom_agents.hidden()
    for kind,(label,shared,note) in SPECS.items():
        if kind in hidden:continue
        command=executable(kind)
        managed_codex=kind=='codex' and command and '/OpenAI/Codex/bin/' in command.replace('\\','/')
        rows.append({'id':kind,'label':label,'available':bool(command) or kind=='none',
                     'shared_model':shared,'note':note,'can_update':bool(command) and not managed_codex and kind not in ('harness','claude-api') and not kind.startswith('custom-'),
                     'update_note':'Обновляется вместе с приложением Codex.' if managed_codex else ''})
    return rows


def project_home(project):
    identity=str(Path(project).resolve()).casefold() if os.name=='nt' else str(Path(project).resolve())
    return runtime()/'hermes-projects'/hashlib.sha256(identity.encode('utf-8')).hexdigest()[:20]


def read_project_memory(project):
    home=project_home(project)/'memories'
    chunks=[]
    for name in ('MEMORY.md','USER.md'):
        try:
            with (home/name).open(encoding='utf-8') as stream:
                content=stream.read(4000)
            if content.strip():
                chunks.append(name+':\n'+content)
        except OSError:
            pass
    return '\n\n'.join(chunks)


@contextmanager
def connection(profile,hermes=False):
    if hermes and profile.get('provider')=='api':
        from orchestrator.services.hermes_connection import api_connection
        with api_connection(profile) as options:
            yield options
        return
    # Reuse the exact CPU/GPU relay and API credentials already used by OpenCode.
    with agent_provider(profile) as raw:
        config=json.loads(raw)
        options=config['provider']['orchestrator-agent']['options']
        yield options['baseURL'],options.get('apiKey','')


def prepare_hermes(project,profile,url,key,memory=True):
    home=project_home(project)
    home.mkdir(parents=True,exist_ok=True)
    config_version=50
    try:
        source=Path(executable('hermes')).resolve().parents[2]/'hermes-source/hermes_cli/config_defaults.py'
        with source.open(encoding='utf-8') as stream:
            match=re.search(r'"_config_version":\s*(\d+)',stream.read(500000))
        if match:
            config_version=int(match.group(1))
    except (OSError,TypeError,IndexError):
        pass
    config={'_config_version':config_version,'model':{'default':profile['model'],'provider':'custom','base_url':url,
                     'api_key':'${OPENAI_API_KEY}','context_length':profile.get('context',64000)},
            'terminal':{'backend':'local','cwd':str(project),'timeout':120},
            'memory':{'memory_enabled':memory,'user_profile_enabled':memory},
            'agent':{'max_turns':12},'fallback_providers':[],
            'compression':{'enabled':True,'threshold_tokens':profile.get('input_budget',48000)},
            'display':{'show_reasoning':False},'security':{'allow_lazy_installs':False}}
    # JSON is valid YAML; generated routing contains no API secrets.
    temporary=home/('config-'+uuid.uuid4().hex+'.tmp')
    temporary.write_text(json.dumps(config,ensure_ascii=False,indent=2),encoding='utf-8')
    temporary.replace(home/'config.yaml')
    env=os.environ.copy()
    env.update(HERMES_HOME=str(home),OPENAI_BASE_URL=url,OPENAI_API_KEY=key or 'local',
               NO_PROXY='*',PYTHONIOENCODING='utf-8',HERMES_TERMUX_PREFETCH_UPDATES='0')
    return env,home


def hermes_profile(profile):
    profile=dict(profile)
    if profile.get('provider')=='api':
        if profile['context']<64000:
            raise ValueError('Hermes требует окно контекста модели не меньше 64 000 токенов. Выберите другую модель или исполнителя.')
        return profile
    request=urllib.request.Request(profile['url'].rstrip('/')+'/api/show',data=json.dumps({'model':profile['model']}).encode('utf-8'),headers={'Content-Type':'application/json'})
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(request,timeout=15) as response:
        info=json.load(response).get('model_info',{})
    windows=[value for name,value in info.items() if name.endswith('.context_length') and type(value) is int]
    if not windows or max(windows)<64000:
        raise ValueError('Hermes требует модель с контекстом от 64 000 токенов; эта локальная модель не подходит. Выберите другую или OpenCode.')
    profile.update(context=64000,input_budget=48000,_hermes_context=64000)
    return profile


def claude_api_environment(profile):
    from urllib.parse import urlsplit
    if profile.get('provider')!='api':raise ValueError('Claude Code требует API с поддержкой Anthropic Messages')
    url=urlsplit(profile.get('url',''))
    if url.scheme!='https' or url.username or url.password or url.query or url.fragment:raise ValueError('Некорректный адрес Claude Code API')
    if url.netloc=='llm-router.org' and url.path.rstrip('/') in ('','/v1'):
        base='https://llm-router.org'
    elif url.netloc=='api.deepseek.com' and url.path.rstrip('/') in ('','/v1','/anthropic'):
        base='https://api.deepseek.com/anthropic'
    else:raise ValueError('Для этого провайдера не настроен Anthropic Messages endpoint. Выберите LLM Router или прямой DeepSeek API.')
    model=profile['model']
    return {'ANTHROPIC_BASE_URL':base,'ANTHROPIC_API_KEY':profile.get('api_key',''),
            'ANTHROPIC_AUTH_TOKEN':'','CLAUDE_CODE_OAUTH_TOKEN':'','ANTHROPIC_MODEL':model,
            'ANTHROPIC_DEFAULT_OPUS_MODEL':model,'ANTHROPIC_DEFAULT_SONNET_MODEL':model,
            'ANTHROPIC_DEFAULT_HAIKU_MODEL':model,'CLAUDE_CODE_SUBAGENT_MODEL':model}


def run_agent(task,project='',cancel_event=None,agent=None,kind='opencode',native_model='',memory=True,timeout=None,planner=False):
    from orchestrator.services import custom_agents
    if kind in custom_agents.hidden():return _save_result(ExecutionResult(error='Агент убран из каталога оркестра'))
    if agent and kind not in agent.get('compatible_kinds',[kind]):
        return _save_result(ExecutionResult(error='Эта модель доступна только с Aider: встроенные вызовы инструментов не поддерживаются'))
    if kind.startswith('custom-'):
        from orchestrator.services import custom_agents
        row=custom_agents.get(kind)
        if not row:return _save_result(ExecutionResult(error='Пользовательский агент удалён'))
        if planner:return _save_result(ExecutionResult(error='Пользовательский CLI доступен как исполнитель, не как планировщик'))
        return custom_agents.run(row,task,project,cancel_event,native_model,timeout)
    if kind=='opencode':
        return run_opencode(task,project,cancel_event,agent=agent,timeout=timeout,memory=memory)
    try:
        if kind not in SPECS or kind=='none':
            raise ValueError('Исполнитель отключён. Выберите агента для выполнения задачи.')
        path=resolve_project(project)
        command=executable(kind)
        if not command:
            raise ValueError(SPECS[kind][0]+' не установлен или не найден в PATH')
        if not isinstance(task,str) or not task.strip():
            raise ValueError('Не указана задача исполнителя')
        if memory and not planner:
            from orchestrator.services.verified_skills import instructions
            task += instructions(path)
        model=native_model.strip()
        if len(model)>200 or any(ord(c)<32 for c in model):
            raise ValueError('Некорректное имя модели исполнителя')
    except (ValueError,OSError) as exc:
        return _save_result(ExecutionResult(error=str(exc)))
    timeout=timeout or (900 if kind=='hermes' else SETTINGS.section('executor')['timeout'])
    env=os.environ.copy()
    env['PYTHONIOENCODING']='utf-8'
    if kind=='harness':
        from orchestrator.services import harness_brain
        if not agent:return _save_result(ExecutionResult(error='Выберите модель Harness'))
        return harness_brain.run(task,str(path),agent,cancel_event,timeout=timeout,direct=not planner)
    if kind in ('hermes','aider'):
        if not agent:
            return _save_result(ExecutionResult(error='Выберите модель агента'))
        if kind=='hermes':
            try:
                agent=hermes_profile(agent)
            except (ValueError,OSError) as exc:
                return _save_result(ExecutionResult(error=str(exc)))
        with connection(agent,hermes=kind=='hermes') as (url,key):
            if kind=='hermes':
                env,home=prepare_hermes(path,agent,url,key,memory)
                prompt=home/('task-'+uuid.uuid4().hex+'.txt')
                cmd=[command,'chat','--query-file',str(prompt),'--quiet','--provider','custom',
                     '--model',agent['model'],'--max-turns','12','--toolsets',
                     ('memory,session_search' if memory else 'session_search') if planner else ('terminal,file,skills,memory,session_search' if memory else 'terminal,file,skills')]
            else:
                home=runtime()/'agent-prompts';home.mkdir(parents=True,exist_ok=True)
                prompt=home/(uuid.uuid4().hex+'.txt')
                env.update(OPENAI_API_BASE=url,OPENAI_API_KEY=key or 'local',NO_PROXY='*')
                cmd=[command,'--model','openai/'+agent['model'],'--message-file',str(prompt),
                     '--yes-always','--no-auto-commits','--no-dirty-commits','--no-check-update','--no-analytics']
            prompt.write_text(task,encoding='utf-8')
            return _run(cmd,timeout,cancel_event,cwd=path,env=env)
    if kind=='claude-api':
        if not agent:return _save_result(ExecutionResult(error='Выберите API-модель Claude Code'))
        try:env.update(claude_api_environment(agent));model=agent['model']
        except ValueError as exc:return _save_result(ExecutionResult(error=str(exc)))
    if kind in ('claude','claude-api') and planner:
        cmd=[command,'-p','--output-format','json' if kind=='claude-api' else 'text','--permission-mode','plan','--permission-prompts','none','--tools','','--strict-mcp-config','--mcp-config','{"mcpServers":{}}','--disable-slash-commands','--no-session-persistence']
        if model:cmd.extend(['--model',model])
        if kind=='claude-api':
            return run_claude_observed(cmd,timeout,cancel_event,path,env,task)
        return _run(cmd,timeout,cancel_event,cwd=path,env=env,input_text=task)
    if kind=='claude-api':
        cmd=[command,'-p','--output-format','json','--permission-mode','acceptEdits','--permission-prompts','none','--no-session-persistence','--model',model]
        return run_claude_observed(cmd,timeout,cancel_event,path,env,task)
    if kind=='claude':
        cmd=[command,'-p',task,'--output-format','text','--permission-mode','acceptEdits','--permission-prompts','none']
    elif kind=='codex':
        from orchestrator.services.access import executor_sandbox
        cmd=[command,'--no-daemon','-a','never','exec','--sandbox',executor_sandbox(),'--skip-git-repo-check','-']
        if model:cmd.extend(['--model',model])
        return _run(cmd,timeout,cancel_event,cwd=path,env=env,input_text=task)
    else:
        cmd=[command,'--prompt',task,'--output-format','text']
    if model:
        cmd.extend(['--model',model])
    return _run(cmd,timeout,cancel_event,cwd=path,env=env)


def update_agent(kind,cancel_event=None):
    row=next((r for r in catalog() if r['id']==kind),None)
    if not row or not row['can_update']:
        return ExecutionResult(error='Исполнитель отсутствует или управляется другим приложением')
    cmd=executable(kind)
    env=os.environ.copy()
    if kind=='hermes' and Path(cmd).parent.parent.name=='hermes-env314':
        installed=Path(cmd).resolve().parents[2]
        source=installed/'hermes-source'
        git=shutil.which('git')
        uv=installed/'hermes-env/Scripts/uv.exe'
        python=installed/'hermes-env314/Scripts/python.exe'
        env.update(UV_CACHE_DIR=str(installed/'uv-cache'),UV_PYTHON_INSTALL_DIR=str(installed/'python-managed'))
        status=_run([git,'status','--porcelain'],30,cancel_event,cwd=source,env=env)
        if not status.ok or status.stdout.strip():
            return ExecutionResult(error='В исходниках Hermes есть изменения. Автообновление пропущено.')
        revision=_run([git,'rev-parse','HEAD'],30,cancel_event,cwd=source,env=env)
        if not revision.ok:
            return revision
        result=_run([git,'-c','http.sslBackend=openssl','pull','--ff-only'],180,cancel_event,cwd=source,env=env)
        if result.ok:
            current=_run([git,'rev-parse','HEAD'],30,cancel_event,cwd=source,env=env)
            if current.ok and current.stdout.strip()==revision.stdout.strip():
                return result
            result=_run([str(uv),'pip','install','--python',str(python),'-e',str(source)],600,cancel_event,cwd=source,env=env)
            if not result.ok:
                rollback=_run([git,'reset','--keep',revision.stdout.strip()],30,cwd=source,env=env)
                if rollback.ok:
                    restored=_run([str(uv),'pip','install','--python',str(python),'-e',str(source)],120,cwd=source,env=env)
                    result.error='Обновление не удалось. '+('Прежняя версия Hermes восстановлена.' if restored.ok else 'Не удалось восстановить зависимости; см. журнал.')
                else:
                    result.error='Обновление не удалось; исходники изменены параллельно, автоматический откат пропущен.'
        return result
    if kind=='aider':
        python=Path(cmd).parent.parent/'python.exe'
        if not python.is_file():
            return ExecutionResult(error='Не найден Python окружения Aider; обновите его вручную')
        args=[str(python),'-m','pip','install','--upgrade','aider-chat']
    else:
        args=[cmd,{'opencode':'upgrade','claude':'update','codex':'update','kimi':'update','hermes':'update'}[kind]]
    return _run(args,600,cancel_event,cwd=SETTINGS.path('sessions_db').parent,env=env)


def run_claude_observed(cmd,timeout,cancel_event,path,env,task):
    from orchestrator.services.anthropic_observer import observe
    from orchestrator.services.claude_result import normalize
    child_env=dict(env)
    with observe(env['ANTHROPIC_BASE_URL'],env['ANTHROPIC_API_KEY']) as (local,records):
        child_env.update(local)
        result=_run(cmd,timeout,cancel_event,cwd=path,env=child_env,input_text=task)
    result.anthropic_diagnostics=records
    result=normalize(result)
    if result.error and not result.stdout.strip() and not result.timed_out and not result.cancelled:
        messages=[r for r in records if r.get('endpoint')=='messages']
        if not messages:detail='запрос Messages до локального relay не дошёл'
        elif any(r.get('transport_error') for r in messages):detail='ошибка транспорта между relay, CLI или шлюзом'
        elif any(r.get('http_status',0)>=400 for r in messages):detail='шлюз вернул ошибку HTTP'
        elif any(r.get('events',{}).get('error') for r in messages):detail='шлюз передал SSE error event'
        elif any(r.get('text_bytes',0)>0 for r in messages):detail='текст от шлюза дошёл до relay, но отсутствует в финальном result CLI'
        elif any(r.get('incomplete_sse') or r.get('parse_errors') for r in messages):detail='поток шлюза неполный или не разобран как Anthropic SSE/JSON'
        else:detail='в полученном ответе шлюза текстовые блоки Anthropic не обнаружены'
        result.error+='; HTTP/SSE: '+detail
    return _save_result(result)
