"""Named API model profiles with Windows-protected secrets.

Registry identifiers are stable across model/label changes. Public responses never
contain ciphertext or plaintext credentials; legacy role profiles remain separate.
"""
import json
import re
import threading
import uuid
from urllib.parse import urlsplit

from orchestrator.config import SETTINGS
from orchestrator.services.connections import protect, validate as validate_connection

_lock = threading.RLock()
MAX_PROFILES = 30
_ID = re.compile(r'[A-Za-z0-9_-]{1,64}')


def path():
    return SETTINGS.path('sessions_db').parent / 'model-registry.json'


def _read():
    try:
        data = json.loads(path().read_text(encoding='utf-8'))
    except FileNotFoundError:
        return []
    if not isinstance(data, list) or len(data) > MAX_PROFILES:
        raise ValueError('Каталог подключений повреждён')
    seen = set()
    for row in data:
        if not isinstance(row, dict) or not isinstance(row.get('id'), str) or not _ID.fullmatch(row['id']) or row['id'] in seen:
            raise ValueError('Каталог подключений повреждён')
        seen.add(row['id'])
    return data


def _public(row):
    fields = ('id', 'label', 'url', 'model', 'context', 'input_budget',
              'max_output_tokens', 'enabled', 'brain_only', 'format')
    from orchestrator.services.connections import effective_input_budget
    value={**{key: row[key] for key in fields},'has_key':bool(row.get('protected_key'))}
    value['input_budget']=effective_input_budget(row)
    value['context_source']=row.get('context_source','configured; provider maximum not verified')
    return value


def public_list():
    with _lock:
        return [_public(row) for row in _read()]


def _validated(data, old):
    if not isinstance(data, dict):
        raise ValueError('Некорректное подключение ИИ')
    ident = data.get('id', '')
    if ident == '':
        ident = uuid.uuid4().hex
    if not isinstance(ident, str) or not _ID.fullmatch(ident):
        raise ValueError('Некорректный идентификатор подключения')
    label = data.get('label', '')
    if not isinstance(label, str) or not 1 <= len(label.strip()) <= 100 or any(ord(c) < 32 for c in label):
        raise ValueError('Название подключения: от 1 до 100 символов')
    for flag in ('enabled', 'brain_only', 'clear_key'):
        if flag in data and type(data[flag]) is not bool:
            raise ValueError('Некорректный переключатель подключения')
    # Disabled profiles must still contain a valid address/model before saving.
    row, key = validate_connection({**data, 'enabled': True})
    parsed = urlsplit(row['url'])
    try:
        parsed.port
    except ValueError:
        raise ValueError('Некорректный порт API') from None
    if parsed.scheme == 'http' and parsed.hostname not in ('localhost', '127.0.0.1', '::1'):
        raise ValueError('Для облачного API требуется HTTPS')
    if any(ord(c) <= 32 for c in row['url']):
        raise ValueError('В URL API недопустимы пробелы и управляющие символы')
    if data.get('clear_key', False):
        key = ''
    elif not key and old.get('protected_key'):
        # Include scheme as well as authority: never carry credentials to an
        # insecure or unrelated destination when a profile is edited.
        previous = urlsplit(old['url'])
        if (previous.scheme, previous.netloc.lower()) != (parsed.scheme, parsed.netloc.lower()):
            raise ValueError('Для нового сервера введите ключ заново или очистите сохранённый ключ')
        key = protect(old['protected_key'], True)
    row.update(id=ident, label=label.strip(), enabled=data.get('enabled', True),
               brain_only=data.get('brain_only', False))
    return row, key


def candidate(data):
    """Validate an unsaved profile and resolve its key for a connection test."""
    with _lock:
        if not isinstance(data, dict):
            raise ValueError('Некорректное подключение ИИ')
        old = next((row for row in _read() if row['id'] == data.get('id')), {})
        row, key = _validated(data, old)
        return {**row, 'api_key': key}


def _write(rows):
    target = path()
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(target.name + '.' + uuid.uuid4().hex + '.tmp')
    temporary.write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding='utf-8')
    temporary.replace(target)


def save_profile(data):
    with _lock:
        if not isinstance(data, dict):
            raise ValueError('Некорректное подключение ИИ')
        rows = _read()
        old = next((row for row in rows if row['id'] == data.get('id')), {})
        if not old and len(rows) >= MAX_PROFILES:
            raise ValueError('Можно сохранить до 30 подключений ИИ')
        row, key = _validated(data, old)
        row['protected_key'] = protect(key) if key else ''
        if old:
            rows[rows.index(old)] = row
        else:
            rows.append(row)
        _write(rows)
        return _public(row)


def delete_profile(ident):
    with _lock:
        if not isinstance(ident, str) or not _ID.fullmatch(ident):
            raise ValueError('Некорректный идентификатор подключения')
        rows = _read()
        remaining = [row for row in rows if row['id'] != ident]
        if len(remaining) == len(rows):
            raise ValueError('Подключение не найдено')
        _write(remaining)
        return {'ok': True, 'id': ident}


def private_profile(ident):
    with _lock:
        row = next((row for row in _read() if row['id'] == ident), None)
        if row is None or not row['enabled']:
            raise ValueError('Подключение отсутствует или отключено')
        return {**_public(row), 'api_key': protect(row['protected_key'], True) if row.get('protected_key') else ''}


def brain_rows():
    return [(row['label'] + ' · API', 'registry', row['id'], row['context'])
            for row in public_list() if row['enabled']]


def agent_rows():
    return [{**row, 'model': 'registry:' + row['id'], 'actual_model': row['model'],
             'registry_id': row['id'], 'provider': 'api'}
            for row in public_list() if row['enabled'] and not row['brain_only']]
