"""Validated configuration shared by source and frozen applications."""
import copy
import os
import sys
import tomllib
from urllib.parse import urlsplit
from pathlib import Path


class ConfigError(ValueError):
    pass


def application_dir():
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parents[1]


class Settings:
    def __init__(self, data, source):
        self.data = data
        self.source = Path(source).resolve()

    def section(self, name):
        return self.data[name]

    def path(self, name):
        path = Path(self.data["paths"][name])
        return path if path.is_absolute() else (self.source.parent / path).resolve()

    def script(self, name):
        path = Path(self.data[name]["script"])
        return path if path.is_absolute() else (self.source.parent / path).resolve()

    def provider(self, name):
        return self.data["llm"][name]

    def models(self):
        rows = self.data["llm"].get("models")
        if rows is not None:
            return [(r["label"], r["provider"], r["model"], r["context"]) for r in rows]
        return [(f"{p.title()}: {self.provider(p)['model']}", p,
                 self.provider(p)["model"], self.provider(p)["context"])
                for p in self.data["llm"]["providers"]]

    def startup_issues(self):
        issues = []
        for name in ("executor", "reviewer"):
            if SETTINGS.section(name).get("enabled", False) and not self.script(name).is_file():
                issues.append(f"Не найден скрипт {name}: {self.script(name)}")
        if not self.path("projects_root").is_dir():
            issues.append(f"Не найден каталог проектов: {self.path('projects_root')}")
        return issues


def load_settings(path=None):
    source = Path(path or os.environ.get("ORCHESTRATOR_CONFIG") or application_dir() / "config.toml").resolve()
    root = source.parent
    defaults = {
        "llm": {"default": "", "providers": [], "models": [],
            "groq": {"api_key_env": "GROQ_API_KEY", "api_key_file": "",
                "model": "qwen/qwen3.8-27b", "url": "https://api.groq.com/openai/v1/chat/completions",
                "proxy": "", "timeout": 120, "context": 131072, "max_output_tokens": 2000, "input_budget": 4000},
            "gemini": {"api_key_env": "GEMINI_API_KEY", "api_key_file": "",
                "model": "gemini-2.5-flash", "url": "https://generativelanguage.googleapis.com/v1beta/models",
                "proxy": "", "timeout": 120, "context": 1048576, "max_output_tokens": 2000},
            "ollama": {"model":"", "url":"http://127.0.0.1:11434", "device":"cpu", "context":8192,
                       "timeout":600, "max_output_tokens":1500}},
        "executor": {"script": str(root.parent / "tools/kimi-to-opencode.py"), "timeout": 300, "grace_timeout": 60, "python": "python"},
        "reviewer": {"script": str(root.parent / "tools/review-groq.py"), "timeout": 180},
        "paths": {"sessions_db": str(root / "sessions.db"), "memory_dir": str(root / "memory"),
                  "projects_root": str(root.parent), "logs_dir": str(root / "logs")},
        "orchestration": {"max_steps": 3, "max_consecutive_errors": 2, "history_messages": 20, "result_chars": 4000, "context_input_tokens": 32000},
    }
    try:
        supplied = tomllib.loads(source.read_text(encoding="utf-8-sig"))
    except (OSError, tomllib.TOMLDecodeError) as exc:
        raise ConfigError(f"Не удалось прочитать настройки {source}: {exc}") from exc
    data = copy.deepcopy(defaults)
    def merge(target, incoming, prefix=""):
        for key, value in incoming.items():
            if key in target and isinstance(target[key], dict):
                if not isinstance(value, dict):
                    raise ConfigError(f"{prefix}{key}: ожидается таблица TOML")
                merge(target[key], value, f"{prefix}{key}.")
            else:
                target[key] = value
    merge(data, supplied)
    def positive(value, name):
        if type(value) is not int or value <= 0:
            raise ConfigError(f"{name}: нужно положительное целое число")
    for section in ("executor", "reviewer"):
        positive(data[section]["timeout"], f"{section}.timeout")
        if not isinstance(data[section]["script"], str) or not data[section]["script"].strip():
            raise ConfigError(f"{section}.script: нужен путь к скрипту")
    positive(data["executor"]["grace_timeout"], "executor.grace_timeout")
    if not isinstance(data["executor"]["python"], str) or not data["executor"]["python"].strip():
        raise ConfigError("executor.python: нужна команда Python")
    for key, value in data["paths"].items():
        if not isinstance(value, str) or not value.strip():
            raise ConfigError(f"paths.{key}: нужен непустой путь")
    for key, value in data["orchestration"].items():
        if key == "cloud_full_context":
            if type(value) is not bool:raise ConfigError("orchestration.cloud_full_context: нужен boolean")
        else:positive(value, f"orchestration.{key}")
    providers = data["llm"]["providers"]
    if not isinstance(providers, list) or any(p not in ("groq", "gemini", "ollama") for p in providers):
        raise ConfigError("llm.providers: допустимы groq, gemini и ollama")
    if providers and data["llm"]["default"] not in providers:
        raise ConfigError("llm.default должен присутствовать в llm.providers")
    for name in ("groq", "gemini"):
        for key in ("model", "url", "api_key_env"):
            if not isinstance(data["llm"][name][key], str) or not data["llm"][name][key].strip():
                raise ConfigError(f"llm.{name}.{key}: нужна непустая строка")
        for key in ("proxy", "api_key_file"):
            if not isinstance(data["llm"][name][key], str):
                raise ConfigError(f"llm.{name}.{key}: нужна строка")
        for key in ("timeout", "context", "max_output_tokens"):
            positive(data["llm"][name][key], f"llm.{name}.{key}")
    positive(data['llm']['groq']['input_budget'], 'llm.groq.input_budget')
    local = data['llm']['ollama']
    if local['device'] not in ('cpu','gpu'):
        raise ConfigError('llm.ollama.device: выберите cpu или gpu')
    for key in ('timeout','context','max_output_tokens'):
        positive(local[key], f'llm.ollama.{key}')
    if local['max_output_tokens'] >= int(local['context']*.75):
        raise ConfigError('llm.ollama.max_output_tokens: слишком велик для заданного контекста')
    def valid_local_url(value):
        try:
            parts = urlsplit(value)
            return parts.scheme in ('http','https') and bool(parts.hostname) and not parts.username and not parts.password and not parts.query and not parts.fragment
        except (ValueError, TypeError):
            return False
    if not valid_local_url(local['url']):
        raise ConfigError('llm.ollama.url: нужен HTTP-адрес Ollama без логина и пароля')
    rows = data["llm"].get("models")
    if rows is not None:
        if not isinstance(rows, list):
            raise ConfigError("llm.models: нужен непустой список моделей")
        for row in rows:
            if not isinstance(row, dict) or any(not isinstance(row.get(k), str) or not row[k].strip() for k in ("label", "provider", "model")):
                raise ConfigError("llm.models: каждой модели нужны label, provider, model")
            if row["provider"] not in providers:
                raise ConfigError("llm.models: провайдер модели не включён")
            positive(row.get("context"), "llm.models.context")
            if row['provider']=='ollama' and local['max_output_tokens'] >= int(min(row['context'],local['context'])*.75):
                raise ConfigError('llm.models.context: слишком мал для лимита ответа Ollama')
            if row['provider']=='ollama' and not valid_local_url(row.get('url', local['url'])):
                raise ConfigError('llm.models.url: некорректный адрес Ollama')
        default = data["llm"]["default"]
        if rows and not any(r["provider"] == default and r["model"] == data["llm"][default]["model"] for r in rows):
            raise ConfigError("Модель провайдера по умолчанию должна быть в llm.models")
    return Settings(data, source)


def read_api_key(provider):
    options = SETTINGS.provider(provider)
    value = os.environ.get(options["api_key_env"], "")
    if value:
        return value
    if not options["api_key_file"]:
        return ""
    path = Path(options["api_key_file"])
    if not path.is_absolute():
        path = SETTINGS.source.parent / path
    try:
        return path.read_text(encoding="utf-8").strip()
    except OSError:
        return ""


try:
    SETTINGS = load_settings()
except ConfigError as exc:
    print(f"Ошибка конфигурации: {exc}", file=sys.stderr)
    raise SystemExit(2) from exc

