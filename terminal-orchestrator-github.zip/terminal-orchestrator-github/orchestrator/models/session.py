import sqlite3
import json
import sys
from contextlib import closing
from pathlib import Path
from datetime import datetime

from orchestrator.config import SETTINGS

DB_PATH = SETTINGS.path("sessions_db")

def get_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with closing(get_db()) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                project TEXT DEFAULT '',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id INTEGER NOT NULL,
                role TEXT NOT NULL,
                text TEXT NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY (session_id) REFERENCES sessions(id)
            )
        """)
        conn.commit()
    # Миграция: колонка archived для архивации сессий
    with closing(get_db()) as conn:
        columns = {row['name'] for row in conn.execute('PRAGMA table_info(sessions)')}
        if 'archived' not in columns:
            conn.execute('ALTER TABLE sessions ADD COLUMN archived INTEGER DEFAULT 0')
            conn.commit()
        for column, declaration in [('context_summary', "TEXT NOT NULL DEFAULT ''"), ('summary_through', 'INTEGER NOT NULL DEFAULT 0')]:
            if column not in columns:
                conn.execute(f'ALTER TABLE sessions ADD COLUMN {column} {declaration}')
        conn.commit()
        message_columns = {row['name'] for row in conn.execute('PRAGMA table_info(messages)')}
        if 'metadata_json' not in message_columns:
            conn.execute("ALTER TABLE messages ADD COLUMN metadata_json TEXT NOT NULL DEFAULT '{}'")
            conn.commit()

class Session:
    @staticmethod
    def save_context(session_id, summary, through):
        with closing(get_db()) as conn:
            conn.execute('UPDATE sessions SET context_summary = ?, summary_through = ? WHERE id = ? AND summary_through <= ?',
                         (summary, through, session_id, through))
            conn.commit()

    @staticmethod
    def create(name, project=""):
        with closing(get_db()) as conn:
            now = datetime.now().isoformat()
            cur = conn.execute(
                "INSERT INTO sessions (name, project, created_at, updated_at) VALUES (?, ?, ?, ?)",
                (name, project, now, now)
            )
            conn.commit()
            session_id = cur.lastrowid
        return session_id

    @staticmethod
    def get_all(include_archived=False):
        with closing(get_db()) as conn:
            if include_archived:
                rows = conn.execute("SELECT * FROM sessions ORDER BY updated_at DESC").fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM sessions WHERE COALESCE(archived, 0) = 0 ORDER BY updated_at DESC"
                ).fetchall()
        return [dict(row) for row in rows]

    @staticmethod
    def get(session_id):
        with closing(get_db()) as conn:
            row = conn.execute("SELECT * FROM sessions WHERE id = ?", (session_id,)).fetchone()
        return dict(row) if row else None

    @staticmethod
    def rename(session_id, name):
        with closing(get_db()) as conn:
            conn.execute("UPDATE sessions SET name = ?, updated_at = ? WHERE id = ?",
                         (name, datetime.now().isoformat(), session_id))
            conn.commit()

    @staticmethod
    def delete(session_id):
        with closing(get_db()) as conn:
            conn.execute("DELETE FROM messages WHERE session_id = ?", (session_id,))
            conn.execute("DELETE FROM sessions WHERE id = ?", (session_id,))
            conn.commit()

    @staticmethod
    def set_archived(session_id, archived):
        with closing(get_db()) as conn:
            conn.execute("UPDATE sessions SET archived = ? WHERE id = ?", (1 if archived else 0, session_id))
            conn.commit()

    @staticmethod
    def touch(session_id):
        with closing(get_db()) as conn:
            now = datetime.now().isoformat()
            conn.execute("UPDATE sessions SET updated_at = ? WHERE id = ?", (now, session_id))
            conn.commit()

class Message:
    @staticmethod
    def create(session_id, role, text, metadata=None):
        with closing(get_db()) as conn:
            now = datetime.now().isoformat()
            cur = conn.execute(
                "INSERT INTO messages (session_id, role, text, created_at, metadata_json) VALUES (?, ?, ?, ?, ?)",
                (session_id, role, text, now, json.dumps(metadata or {}, ensure_ascii=False))
            )
            conn.execute("UPDATE sessions SET updated_at = ? WHERE id = ?", (now, session_id))
            conn.commit()
            return cur.lastrowid

    @staticmethod
    def update(message_id, text, metadata=None):
        with closing(get_db()) as conn:
            conn.execute("UPDATE messages SET text = ?, metadata_json = ? WHERE id = ?",
                         (text, json.dumps(metadata or {}, ensure_ascii=False), message_id))
            conn.execute("UPDATE sessions SET updated_at = ? WHERE id = (SELECT session_id FROM messages WHERE id = ?)",
                         (datetime.now().isoformat(), message_id))
            conn.commit()

    @staticmethod
    def get_by_session(session_id, limit=100):
        with closing(get_db()) as conn:
            rows = conn.execute(
                "SELECT * FROM (SELECT * FROM messages WHERE session_id = ? ORDER BY id DESC LIMIT ?) ORDER BY id ASC",
                (session_id, limit)
            ).fetchall()
        return [dict(row) for row in rows]

try:
    init_db()
except (OSError, sqlite3.Error) as exc:
    print(f"Не удалось открыть базу сессий {DB_PATH}: {exc}", file=sys.stderr)
    raise SystemExit(2) from None
