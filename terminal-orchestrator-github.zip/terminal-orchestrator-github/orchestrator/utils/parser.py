import json
import re
import shlex


def split_files(text):
    if text.lstrip().startswith('['):
        values = json.loads(text)
        if not isinstance(values, list) or not values or any(not isinstance(v, str) or not v.strip() for v in values):
            raise ValueError('REVIEW: нужен непустой список файлов')
        return values
    # posix=False preserves Windows backslashes and quotes around paths with spaces.
    values = [v[1:-1] if len(v) > 1 and v[0] == v[-1] and v[0] in ('"', "'") else v
              for v in shlex.split(text, posix=False)]
    if not values:
        raise ValueError('REVIEW: не указаны файлы')
    return values


def parse_command(text):
    """Prefer one structured command; accept legacy markers during migration."""
    stripped = text.strip()
    fenced = re.findall(r'```json\s*\n(.*?)```', stripped, flags=re.DOTALL | re.IGNORECASE)
    payload = None
    if stripped.startswith('{'):
        payload = stripped
    elif fenced:
        if len(fenced) != 1:
            raise ValueError('Ответ содержит несколько JSON-команд')
        payload = fenced[0]
    if payload is not None:
        try:
            value = json.loads(payload)
        except json.JSONDecodeError as exc:
            raise ValueError(f'Модель вернула некорректную JSON-команду: строка {exc.lineno}, столбец {exc.colno}. Команда не выполнялась; проверьте синтаксис и двойное экранирование кавычек.') from exc
        if not isinstance(value, dict) or 'action' not in value:
            return None
        action = value['action']
        project = value.get('project', '')
        if not isinstance(project, str):
            raise ValueError('project должен быть строкой')
        if action == 'agent_help':
            from orchestrator.services.agent_guides import GUIDES
            agent=value.get('agent')
            if not isinstance(agent,str) or agent not in GUIDES or project:raise ValueError('Укажите известный ID агента без пути проекта')
            return action,agent,''
        if action == 'finish':
            status=value.get('status');summary=value.get('summary','')
            if status not in ('completed','incomplete') or not isinstance(summary,str):raise ValueError('Некорректный итог задачи')
            return action,json.dumps({'status':status,'summary':summary},ensure_ascii=False),project.strip()
        if action == 'delegate':
            task=value.get('task')
            profile=value.get('profile','')
            category=value.get('category','general')
            if not isinstance(task,str) or not task.strip() or not isinstance(profile,str) or category not in ('simple','complex','review','general'):
                raise ValueError('Некорректная команда распределения')
            return action,json.dumps({'task':task.strip(),'profile':profile,'category':category, 'expected_artifacts':value.get('expected_artifacts',[])},ensure_ascii=False),project.strip()
        if action == 'opencode':
            task = value.get('task')
            if not isinstance(task, str) or not task.strip():
                raise ValueError('Команда OpenCode не содержит задачи')
            return action, task.strip(), project.strip()
        if action == 'review':
            files = value.get('files')
            if not isinstance(files, list) or not files or any(not isinstance(v, str) or not v.strip() for v in files):
                raise ValueError('REVIEW: нужен непустой список файлов')
            encoded = json.dumps(files, ensure_ascii=False)
            split_files(encoded)
            return action, encoded, project.strip()
        raise ValueError(f'Неизвестный тип команды: {action}')
    lines = stripped.splitlines()
    commands = [(i, line.strip()) for i, line in enumerate(lines)
                if line.strip().startswith(('OPENCODE:', 'REVIEW:'))]
    if not commands:
        return None
    if len(commands) != 1:
        raise ValueError('В ответе допустима только одна команда')
    index, line = commands[0]
    kind, data = line.split(':', 1)
    data = data.strip()
    if not data:
        raise ValueError('Команда не содержит задачи или файлов')
    project = ''
    if index + 1 < len(lines) and lines[index + 1].strip().startswith('PROJECT:'):
        project = lines[index + 1].strip().split(':', 1)[1].strip()
    if kind == 'REVIEW':
        split_files(data)
    return kind.lower(), data, project

