"""Desktop window using the installed Edge/Chrome app mode; no extra runtime."""
import argparse
import os
import subprocess
import sys
import threading
import time
import webbrowser
import traceback
import json
import re
import hashlib
from urllib.request import Request,build_opener,ProxyHandler
from pathlib import Path

def application_dir():
    return Path(sys.executable).resolve().parent if getattr(sys, 'frozen', False) else Path(__file__).resolve().parent


def report_startup_error(exc):
    detail = ''.join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    log_path = application_dir()/'.runtime/desktop-error.log'
    try:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with log_path.open('a', encoding='utf-8') as output:
            output.write(time.strftime('%Y-%m-%d %H:%M:%S') + '\n' + detail + '\n')
        location = f'Подробности: {log_path}'
    except OSError:
        location = 'Не удалось записать диагностический журнал.'
    reason = str(exc.__cause__ or exc)
    message = f'Не удалось запустить Оркестратор.\n\n{reason}\n\n{location}'
    if getattr(sys, 'frozen', False) and os.name == 'nt':
        import ctypes
        ctypes.windll.user32.MessageBoxW(None, message, 'Оркестратор — ошибка запуска', 0x10)
    elif sys.stderr:
        print(message, file=sys.stderr)


def window_closed(server, now, no_open=False):
    if server.gone_at is not None and now-server.gone_at > 7:
        return True
    if no_open:
        return False
    # A crashed window cannot send /gone. Allow five minutes for suspended tabs.
    return now-server.last_seen > (300 if server.connected else 180)


def asset_dir():
    if getattr(sys, 'frozen', False):
        return Path(sys._MEIPASS) / 'web'
    return Path(__file__).resolve().parent / 'web'


def owner_endpoint():
    return Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / ('OrchestratorPublic/'+hashlib.sha256(str(application_dir()).encode()).hexdigest()[:16]+'/owner.json')


def focus_window():
    if os.name != 'nt':
        return False
    import ctypes
    from ctypes import wintypes
    api = ctypes.WinDLL('user32', use_last_error=True)
    callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    api.EnumWindows.argtypes = [callback_type, wintypes.LPARAM]
    api.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    api.IsWindowVisible.argtypes = [wintypes.HWND]
    api.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
    api.SetForegroundWindow.argtypes = [wintypes.HWND]
    found = []
    @callback_type
    def visit(hwnd, unused):
        title = ctypes.create_unicode_buffer(512)
        api.GetWindowTextW(hwnd, title, len(title))
        if api.IsWindowVisible(hwnd) and title.value.startswith(('Оркестратор', 'Оркестр ·')):
            api.ShowWindow(hwnd, 9)
            api.SetForegroundWindow(hwnd)
            found.append(hwnd)
            return False
        return True
    api.EnumWindows(visit, 0)
    return bool(found)


def open_window(url):
    if focus_window():
        return
    candidates = [Path(os.environ.get('PROGRAMFILES(X86)', 'C:/Program Files (x86)'))/'Microsoft/Edge/Application/msedge.exe',
                  Path(os.environ.get('PROGRAMFILES', 'C:/Program Files'))/'Microsoft/Edge/Application/msedge.exe',
                  Path(os.environ.get('PROGRAMFILES', 'C:/Program Files'))/'Google/Chrome/Application/chrome.exe']
    for browser in candidates:
        if browser.is_file():
            profile = application_dir()/'.runtime/desktop-profile'
            profile.mkdir(parents=True, exist_ok=True)
            subprocess.Popen([str(browser), f'--app={url}', f'--user-data-dir={profile}',
                              '--no-first-run', '--no-default-browser-check', '--window-size=1440,960'])
            return
    if not webbrowser.open(url):
        raise RuntimeError("Не найден браузер для открытия оболочки.")

def remote_lock(endpoint, no_open):
    """One background owner on this Windows machine, independent of config path."""
    if os.name!='nt':return None
    import ctypes
    api=ctypes.WinDLL('kernel32',use_last_error=True)
    api.CreateMutexW.argtypes=[ctypes.c_void_p,ctypes.c_bool,ctypes.c_wchar_p];api.CreateMutexW.restype=ctypes.c_void_p
    api.WaitForSingleObject.argtypes=[ctypes.c_void_p,ctypes.c_uint32]
    api.CloseHandle.argtypes=[ctypes.c_void_p]
    name='Local\\OrchestratorPublic.'+hashlib.sha256(str(application_dir()).encode()).hexdigest()[:16]
    handle=api.CreateMutexW(None,False,name)
    if not handle:raise RuntimeError('Не удалось создать блокировку фонового терминала')
    if api.WaitForSingleObject(handle,0) in (0,128):return handle
    try:
        for _ in range(100):
            try:
                discovery = Path(owner_endpoint().read_text(encoding='utf-8')) if owner_endpoint().exists() else endpoint
                value=json.loads(discovery.read_text(encoding='utf-8'))
                base,token=value['url'],value['token']
                if not re.fullmatch(r'http://127\.0\.0\.1:\d{1,5}',base) or not re.fullmatch(r'[A-Za-z0-9_-]{32,128}',token):raise ValueError()
                with build_opener(ProxyHandler({})).open(Request(base+'/api/bootstrap',headers={'Authorization':'Bearer '+token}),timeout=2) as response:
                    if response.status==200:
                        if not no_open:open_window(base+'/#token='+token)
                        return False
            except (OSError,ValueError,KeyError):pass
            time.sleep(.15)
        raise RuntimeError('Фоновый терминал запускается. Повторите открытие окна позже.')
    finally:api.CloseHandle(handle)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--browser', action='store_true', help='Открыть в обычном браузере')
    parser.add_argument('--no-open', action='store_true', help='Запустить только локальный сервер')
    parser.add_argument('--port', type=int, default=0)
    parser.add_argument('--keep-running',action='store_true',help='Оставлять общий сервер для Android после закрытия окна')
    parser.add_argument('--config')
    parser.add_argument('--wait-pid',type=int)
    parser.add_argument('--pick-folder-output')
    args = parser.parse_args()
    if args.config:os.environ['ORCHESTRATOR_CONFIG']=args.config
    if args.pick_folder_output:
        import tkinter as tk
        from tkinter.filedialog import askdirectory
        window=tk.Tk();window.withdraw()
        chosen=askdirectory(title='Разрешённая папка проекта',parent=window)
        target=Path(args.pick_folder_output);target.parent.mkdir(parents=True,exist_ok=True);target.write_text(chosen,encoding='utf-8');window.destroy();return
    if args.wait_pid:
        import ctypes
        kernel=ctypes.WinDLL('kernel32');kernel.OpenProcess.restype=ctypes.c_void_p
        handle=kernel.OpenProcess(0x100000,False,args.wait_pid)
        if handle:
            kernel.WaitForSingleObject.argtypes=[ctypes.c_void_p,ctypes.c_ulong]
            result=kernel.WaitForSingleObject(handle,60000)
            kernel.CloseHandle.argtypes=[ctypes.c_void_p];kernel.CloseHandle(handle)
            if result!=0:raise RuntimeError('Предыдущий терминал не завершился')
    from orchestrator.config import SETTINGS
    endpoint=SETTINGS.path('sessions_db').parent/'.runtime/desktop-endpoint.json'
    remote_mutex=remote_lock(endpoint,args.no_open)
    if remote_mutex is False:return
    from orchestrator.services.desktop import DesktopService, make_server
    service = DesktopService()
    server = make_server(service, asset_dir(), args.port)
    endpoint.parent.mkdir(parents=True,exist_ok=True)
    # Purpose-made local pairing file, never browser sessions or credentials.
    if endpoint.exists() and os.name!='nt':endpoint.chmod(0o600)
    fd=os.open(endpoint,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
    with os.fdopen(fd,'w',encoding='utf-8') as output:
        json.dump({'url':f'http://127.0.0.1:{server.server_port}','token':server.token,'pid':os.getpid()},output)
    if os.name=='nt':
        owner=os.environ.get('USERDOMAIN','')+'\\'+os.environ['USERNAME']
        acl=subprocess.run(['icacls.exe',str(endpoint),'/inheritance:r','/grant:r',owner+':(F)','*S-1-5-18:(F)'],capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW)
        if acl.returncode:
            endpoint.unlink(missing_ok=True)
            raise RuntimeError('Не удалось защитить локальный файл подключения')
    # Shared discovery has no token: read the owner's ACL-protected endpoint.
    owner = owner_endpoint()
    owner.parent.mkdir(parents=True, exist_ok=True)
    owner.write_text(str(endpoint.resolve()), encoding='utf-8')
    url = f'http://127.0.0.1:{server.server_port}/#token={server.token}'
    stopped = threading.Event()
    def watchdog():
        while not stopped.wait(1):
            now = time.monotonic()
            if not args.keep_running and window_closed(server, now, args.no_open):
                service.close()
                server.shutdown()
                return
    threading.Thread(target=watchdog, daemon=True).start()
    try:
        if not args.no_open:
            if args.browser:
                if not webbrowser.open(url):
                    raise RuntimeError("Не удалось открыть браузер. Проверьте установленный Edge/Chrome.")
            else:
                open_window(url)
        if sys.stdout:
            print(url, flush=True)
        server.serve_forever(poll_interval=0.3)
    except KeyboardInterrupt:
        pass
    finally:
        stopped.set()
        try:
            if json.loads(endpoint.read_text(encoding='utf-8')).get('pid')==os.getpid():
                endpoint.unlink()
                owner_endpoint().unlink(missing_ok=True)
        except (OSError,ValueError):pass
        service.close()
        server.server_close()
        if service.thread:
            service.thread.join(timeout=8)


if __name__ == '__main__':
    try:
        main()
    except (Exception, SystemExit) as exc:
        if isinstance(exc, SystemExit) and exc.code in (None, 0):
            raise
        report_startup_error(exc)
        raise SystemExit(1)
